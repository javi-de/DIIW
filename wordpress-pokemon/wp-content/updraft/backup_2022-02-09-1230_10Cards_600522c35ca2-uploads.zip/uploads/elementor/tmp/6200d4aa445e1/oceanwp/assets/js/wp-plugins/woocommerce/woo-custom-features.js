(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DOMString = exports.DOM = exports.options = void 0;
var options = oceanwpLocalize;
exports.options = options;
var DOM = {
  html: document.querySelector("html"),
  body: document.body,
  WPAdminbar: document.querySelector("#wpadminbar"),
  wrap: document.querySelector("#wrap"),
  main: document.querySelector("#main"),
  selectTags: document.querySelectorAll(options.customSelects),
  floatingBar: document.querySelector(".owp-floating-bar"),
  header: {
    site: document.querySelector("#site-header"),
    vertical: document.querySelector("#site-header.vertical-header #site-header-inner"),
    fullScreen: document.querySelector("#site-header.full_screen-header"),
    topbar: document.querySelector("#top-bar"),
    topbarWrapper: document.querySelector("#top-bar-wrap"),
    topLeftSide: document.querySelector("#site-header.top-header .header-top .left"),
    topRightSide: document.querySelector("#site-header.top-header .header-top .right")
  },
  menu: {
    nav: document.querySelector("#site-header.header-replace #site-navigation"),
    main: document.querySelector(".main-menu"),
    fullScreen: {
      menu: document.querySelector("#site-header.full_screen-header #full-screen-menu"),
      toggleMenuBtn: document.querySelector("#site-header.full_screen-header .menu-bar"),
      logo: document.querySelector("#site-logo.has-full-screen-logo")
    },
    mega: {
      menuItems: document.querySelectorAll("#site-navigation .megamenu-li.full-mega"),
      topbarMenuItems: document.querySelectorAll("#top-bar-nav .megamenu-li.full-mega"),
      menuContents: document.querySelectorAll(".navigation .megamenu-li.auto-mega .megamenu")
    },
    vertical: {
      toggleMenuBtn: document.querySelector("a.vertical-toggle")
    }
  },
  mobileMenu: {
    nav: document.querySelector("#mobile-dropdown > nav"),
    navWrapper: document.querySelector("#mobile-dropdown"),
    toggleMenuBtn: document.querySelector(".mobile-menu"),
    hamburgerBtn: document.querySelector(".mobile-menu > .hamburger"),
    menuItemsHasChildren: document.querySelectorAll("#mobile-dropdown .menu-item-has-children"),
    fullScreen: document.querySelector("#mobile-fullscreen")
  },
  search: {
    forms: document.querySelectorAll("form.header-searchform"),
    dropDown: {
      toggleSearchBtn: document.querySelector("a.search-dropdown-toggle"),
      form: document.querySelector("#searchform-dropdown")
    },
    headerReplace: {
      toggleSearchBtn: document.querySelector("a.search-header-replace-toggle"),
      closeBtn: document.querySelector("#searchform-header-replace-close"),
      form: document.querySelector("#searchform-header-replace")
    },
    overlay: {
      toggleSearchBtn: document.querySelector("a.search-overlay-toggle"),
      closeBtn: document.querySelector("#searchform-overlay a.search-overlay-close"),
      form: document.querySelector("#searchform-overlay")
    }
  },
  footer: {
    siteFooter: document.querySelector("#footer"),
    calloutFooter: document.querySelector("#footer-callout-wrap"),
    footerBar: document.querySelector("#footer-bar"),
    parallax: document.querySelector(".parallax-footer")
  },
  scroll: {
    scrollTop: document.querySelector("#scroll-top"),
    goTop: document.querySelector('a[href="#go-top"]'),
    goTopSlash: document.querySelector('body.home a[href="/#go-top"]'),
    infiniteScrollNav: document.querySelector(".infinite-scroll-nav"),
    infiniteScrollWrapper: document.querySelector(".infinite-scroll-wrap")
  },
  blog: {
    masonryGrids: document.querySelectorAll(".blog-masonry-grid")
  },
  edd: {
    carts: document.querySelectorAll(".edd-menu-icon"),
    overlayCart: document.querySelector(".owp-cart-overlay"),
    totalPrices: document.querySelectorAll(".eddmenucart-details.total"),
    quickViewModal: document.querySelector("#owp-qv-wrap"),
    quickViewContent: document.querySelector("#owp-qv-content")
  },
  woo: {
    resetVariations: document.querySelector(".reset_variations"),
    product: document.querySelector(".woocommerce div.product"),
    allProducts: document.querySelectorAll(".woocommerce ul.products"),
    categories: document.querySelectorAll(".woo-dropdown-cat .product-categories"),
    verticalThumbs: document.querySelectorAll(".owp-thumbs-layout-vertical"),
    thumbsVerticalLayout: document.querySelector(".owp-thumbs-layout-vertical"),
    grid: document.querySelector(".oceanwp-grid-list #oceanwp-grid"),
    list: document.querySelector(".oceanwp-grid-list #oceanwp-list"),
    productTabs: document.querySelector(".woocommerce div.product .woocommerce-tabs"),
    productCarts: document.querySelectorAll(".woocommerce div.product .cart"),
    productCustomerReviewLink: document.querySelector(".woocommerce div.product .woocommerce-review-link"),
    quantity: document.querySelector('input[name="quantity"]'),
    checkoutForm: document.querySelector("form.woocommerce-checkout"),
    checkoutLogin: document.querySelector("#checkout_login"),
    checkoutCoupon: document.querySelector("#checkout_coupon"),
    checkoutTimeline: document.querySelector("#owp-checkout-timeline"),
    customerBillingDetails: document.querySelector("#customer_billing_details"),
    customerShippingDetails: document.querySelector("#customer_shipping_details"),
    orderReview: document.querySelector("#order_review"),
    orderCheckoutPayment: document.querySelector("#order_checkout_payment"),
    placeOrder: document.querySelector("#place_order"),
    formActions: document.querySelector("#form_actions"),
    overlayCart: document.querySelector(".owp-cart-overlay"),
    guestAccountPageNav: document.querySelector(".owp-account-links"),
    guestAccountPageBox: document.querySelector("#customer_login"),
    quantityInputs: document.querySelectorAll(".quantity:not(.buttons_added) .qty"),
    quickView: {
      modal: document.querySelector("#owp-qv-wrap"),
      content: document.querySelector("#owp-qv-content")
    }
  }
};
exports.DOM = DOM;
var DOMString = {};
exports.DOMString = DOMString;

},{}],2:[function(require,module,exports){
"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.isSelectorValid = exports.isElement = exports.getSiblings = exports.visible = exports.offset = exports.fadeToggle = exports.fadeOut = exports.fadeIn = exports.slideToggle = exports.slideUp = exports.slideDown = exports.wrap = void 0;

var _typeof2 = _interopRequireDefault(require("@babel/runtime/helpers/typeof"));

var wrap = function wrap(element) {
  var wrapper = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : document.createElement("div");

  if (element.nextSibling) {
    element.parentNode.insertBefore(wrapper, element.nextSibling);
  } else {
    element.parentNode.appendChild(wrapper);
  }

  return wrapper.appendChild(element);
};

exports.wrap = wrap;

var slideDown = function slideDown(element) {
  var duration = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 300;
  var display = window.getComputedStyle(element).display;

  if (display === "none") {
    display = "block";
  }

  element.style.transitionProperty = "height";
  element.style.transitionDuration = "".concat(duration, "ms");
  element.style.opacity = 0;
  element.style.display = display;
  var height = element.offsetHeight;
  element.style.height = 0;
  element.style.opacity = 1;
  element.style.overflow = "hidden";
  setTimeout(function () {
    element.style.height = "".concat(height, "px");
  }, 5);
  window.setTimeout(function () {
    element.style.removeProperty("height");
    element.style.removeProperty("overflow");
    element.style.removeProperty("transition-duration");
    element.style.removeProperty("transition-property");
    element.style.removeProperty("opacity");
  }, duration + 50);
};

exports.slideDown = slideDown;

var slideUp = function slideUp(element) {
  var duration = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 300;
  element.style.boxSizing = "border-box";
  element.style.transitionProperty = "height, margin";
  element.style.transitionDuration = "".concat(duration, "ms");
  element.style.height = "".concat(element.offsetHeight, "px");
  element.style.marginTop = 0;
  element.style.marginBottom = 0;
  element.style.overflow = "hidden";
  setTimeout(function () {
    element.style.height = 0;
  }, 5);
  window.setTimeout(function () {
    element.style.display = "none";
    element.style.removeProperty("height");
    element.style.removeProperty("margin-top");
    element.style.removeProperty("margin-bottom");
    element.style.removeProperty("overflow");
    element.style.removeProperty("transition-duration");
    element.style.removeProperty("transition-property");
  }, duration + 50);
};

exports.slideUp = slideUp;

var slideToggle = function slideToggle(element, duration) {
  window.getComputedStyle(element).display === "none" ? slideDown(element, duration) : slideUp(element, duration);
};

exports.slideToggle = slideToggle;

var fadeIn = function fadeIn(element) {
  var _options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  var options = {
    duration: 300,
    display: null,
    opacity: 1,
    callback: null
  };
  Object.assign(options, _options);
  element.style.opacity = 0;
  element.style.display = options.display || "block";
  setTimeout(function () {
    element.style.transition = "".concat(options.duration, "ms opacity ease");
    element.style.opacity = options.opacity;
  }, 5);
  setTimeout(function () {
    element.style.removeProperty("transition");
    !!options.callback && options.callback();
  }, options.duration + 50);
};

exports.fadeIn = fadeIn;

var fadeOut = function fadeOut(element) {
  var _options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  if (element.style.display === "none") {
    return;
  }

  var options = {
    duration: 300,
    display: null,
    opacity: 0,
    callback: null
  };
  Object.assign(options, _options);
  element.style.opacity = 1;
  element.style.display = options.display || "block";
  setTimeout(function () {
    element.style.transition = "".concat(options.duration, "ms opacity ease");
    element.style.opacity = options.opacity;
  }, 5);
  setTimeout(function () {
    element.style.display = "none";
    element.style.removeProperty("transition");
    !!options.callback && options.callback();
  }, options.duration + 50);
};

exports.fadeOut = fadeOut;

var fadeToggle = function fadeToggle(element, options) {
  window.getComputedStyle(element).display === "none" ? fadeIn(element, options) : fadeOut(element, options);
};

exports.fadeToggle = fadeToggle;

var offset = function offset(element) {
  if (!element.getClientRects().length) {
    return {
      top: 0,
      left: 0
    };
  } // Get document-relative position by adding viewport scroll to viewport-relative gBCR


  var rect = element.getBoundingClientRect();
  var win = element.ownerDocument.defaultView;
  return {
    top: rect.top + win.pageYOffset,
    left: rect.left + win.pageXOffset
  };
};

exports.offset = offset;

var visible = function visible(element) {
  if (!element) {
    return false;
  }

  return !!(element.offsetWidth || element.offsetHeight || element.getClientRects().length);
};

exports.visible = visible;

var getSiblings = function getSiblings(e) {
  // for collecting siblings
  var siblings = []; // if no parent, return no sibling

  if (!e.parentNode) {
    return siblings;
  } // first child of the parent node


  var sibling = e.parentNode.firstChild; // collecting siblings

  while (sibling) {
    if (sibling.nodeType === 1 && sibling !== e) {
      siblings.push(sibling);
    }

    sibling = sibling.nextSibling;
  }

  return siblings;
}; // Returns true if it is a DOM element


exports.getSiblings = getSiblings;

var isElement = function isElement(o) {
  return (typeof HTMLElement === "undefined" ? "undefined" : (0, _typeof2["default"])(HTMLElement)) === "object" ? o instanceof HTMLElement // DOM2
  : o && (0, _typeof2["default"])(o) === "object" && o !== null && o.nodeType === 1 && typeof o.nodeName === "string";
};

exports.isElement = isElement;

var isSelectorValid = function (dummyElement) {
  return function (selector) {
    try {
      dummyElement.querySelector(selector);
    } catch (_unused) {
      return false;
    }

    return true;
  };
}(document.createDocumentFragment());

exports.isSelectorValid = isSelectorValid;

},{"@babel/runtime/helpers/interopRequireDefault":17,"@babel/runtime/helpers/typeof":18}],3:[function(require,module,exports){
"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _classPrivateFieldGet2 = _interopRequireDefault(require("@babel/runtime/helpers/classPrivateFieldGet"));

var _start = /*#__PURE__*/new WeakMap();

var WooRemoveCategoriesCountParenthesis = function WooRemoveCategoriesCountParenthesis() {
  (0, _classCallCheck2["default"])(this, WooRemoveCategoriesCountParenthesis);

  _start.set(this, {
    writable: true,
    value: function value() {
      document.querySelectorAll(".widget_layered_nav span.count, .widget_product_categories span.count").forEach(function (item) {
        var count = item.innerHTML;
        item.innerHTML = count.substring(1, count.length - 1);
      });
    }
  });

  (0, _classPrivateFieldGet2["default"])(this, _start).call(this);
};

var _default = WooRemoveCategoriesCountParenthesis;
exports["default"] = _default;

},{"@babel/runtime/helpers/classCallCheck":12,"@babel/runtime/helpers/classPrivateFieldGet":14,"@babel/runtime/helpers/interopRequireDefault":17}],4:[function(require,module,exports){
"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _classPrivateFieldGet2 = _interopRequireDefault(require("@babel/runtime/helpers/classPrivateFieldGet"));

var _constants = require("../../../constants");

var _setupEventListeners = /*#__PURE__*/new WeakMap();

var WooResetVariations = function WooResetVariations() {
  (0, _classCallCheck2["default"])(this, WooResetVariations);

  _setupEventListeners.set(this, {
    writable: true,
    value: function value() {
      _constants.DOM.woo.resetVariations.addEventListener("click", function (event) {
        var resetVariations = event.currentTarget;
        resetVariations.closest(".variations").querySelectorAll("select").forEach(function (select) {
          setTimeout(function () {
            select.nextSibling.innerHTML = select.options[select.selectedIndex].text;
          }, 100);
        });
      });
    }
  });

  if (!!_constants.DOM.woo.resetVariations) {
    (0, _classPrivateFieldGet2["default"])(this, _setupEventListeners).call(this);
  }
};

var _default = WooResetVariations;
exports["default"] = _default;

},{"../../../constants":1,"@babel/runtime/helpers/classCallCheck":12,"@babel/runtime/helpers/classPrivateFieldGet":14,"@babel/runtime/helpers/interopRequireDefault":17}],5:[function(require,module,exports){
"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _classPrivateFieldGet2 = _interopRequireDefault(require("@babel/runtime/helpers/classPrivateFieldGet"));

var _jsCookie = _interopRequireDefault(require("js-cookie"));

var _constants = require("../../../constants");

var _utils = require("../../../lib/utils");

var _start = /*#__PURE__*/new WeakMap();

var _setupEventListeners = /*#__PURE__*/new WeakMap();

var _onGridClick = /*#__PURE__*/new WeakMap();

var _onListClick = /*#__PURE__*/new WeakMap();

var _productCarousel = /*#__PURE__*/new WeakMap();

var WooGridList = function WooGridList() {
  var _this = this;

  (0, _classCallCheck2["default"])(this, WooGridList);

  _start.set(this, {
    writable: true,
    value: function value() {
      if (!(_constants.DOM.woo.grid || _constants.DOM.woo.list)) {
        return;
      }

      if (_jsCookie["default"].get("gridcookie") === "grid") {
        var _DOM$woo$grid, _DOM$woo$list, _DOM$woo$allProducts;

        (_DOM$woo$grid = _constants.DOM.woo.grid) === null || _DOM$woo$grid === void 0 ? void 0 : _DOM$woo$grid.classList.add("active");
        (_DOM$woo$list = _constants.DOM.woo.list) === null || _DOM$woo$list === void 0 ? void 0 : _DOM$woo$list.classList.remove("active");
        (_DOM$woo$allProducts = _constants.DOM.woo.allProducts) === null || _DOM$woo$allProducts === void 0 ? void 0 : _DOM$woo$allProducts.forEach(function (products) {
          products.classList.add("grid");
          products.classList.remove("list");
        });
      }

      if (_jsCookie["default"].get("gridcookie") === "list") {
        var _DOM$woo$grid2, _DOM$woo$list2, _DOM$woo$allProducts2;

        (_DOM$woo$grid2 = _constants.DOM.woo.grid) === null || _DOM$woo$grid2 === void 0 ? void 0 : _DOM$woo$grid2.classList.remove("active");
        (_DOM$woo$list2 = _constants.DOM.woo.list) === null || _DOM$woo$list2 === void 0 ? void 0 : _DOM$woo$list2.classList.add("active");
        (_DOM$woo$allProducts2 = _constants.DOM.woo.allProducts) === null || _DOM$woo$allProducts2 === void 0 ? void 0 : _DOM$woo$allProducts2.forEach(function (products) {
          products.classList.add("list");
          products.classList.remove("grid");
        });
        (0, _classPrivateFieldGet2["default"])(_this, _productCarousel).call(_this);
      }
    }
  });

  _setupEventListeners.set(this, {
    writable: true,
    value: function value() {
      var _DOM$woo$grid3, _DOM$woo$list3;

      (_DOM$woo$grid3 = _constants.DOM.woo.grid) === null || _DOM$woo$grid3 === void 0 ? void 0 : _DOM$woo$grid3.addEventListener("click", (0, _classPrivateFieldGet2["default"])(_this, _onGridClick));
      (_DOM$woo$list3 = _constants.DOM.woo.list) === null || _DOM$woo$list3 === void 0 ? void 0 : _DOM$woo$list3.addEventListener("click", (0, _classPrivateFieldGet2["default"])(_this, _onListClick));
    }
  });

  _onGridClick.set(this, {
    writable: true,
    value: function value(event) {
      event.preventDefault();
      event.stopPropagation();

      _constants.DOM.woo.grid.classList.add("active");

      _constants.DOM.woo.list.classList.remove("active");

      _jsCookie["default"].set("gridcookie", "grid", {
        path: ""
      });

      _constants.DOM.woo.allProducts.forEach(function (products) {
        (0, _utils.fadeOut)(products, {
          callback: function callback() {
            products.classList.add("grid");
            products.classList.remove("list");
            (0, _utils.fadeIn)(products);
          }
        });
      });

      setTimeout(function () {
        (0, _classPrivateFieldGet2["default"])(_this, _productCarousel).call(_this);
      }, 301);
    }
  });

  _onListClick.set(this, {
    writable: true,
    value: function value(event) {
      event.preventDefault();
      event.stopPropagation();

      _constants.DOM.woo.grid.classList.remove("active");

      _constants.DOM.woo.list.classList.add("active");

      _jsCookie["default"].set("gridcookie", "list", {
        path: ""
      });

      _constants.DOM.woo.allProducts.forEach(function (products) {
        (0, _utils.fadeOut)(products, {
          callback: function callback() {
            products.classList.add("list");
            products.classList.remove("grid");
            (0, _utils.fadeIn)(products);
          }
        });
      });

      setTimeout(function () {
        (0, _classPrivateFieldGet2["default"])(_this, _productCarousel).call(_this);
      }, 301);
    }
  });

  _productCarousel.set(this, {
    writable: true,
    value: function value() {
      if (!_constants.DOM.body.classList.contains("no-carousel") && !!document.querySelector(".woo-entry-image.product-entry-slider")) {
        var _oceanwp$theme$owSlid;

        (_oceanwp$theme$owSlid = oceanwp.theme.owSlider.flickity) === null || _oceanwp$theme$owSlid === void 0 ? void 0 : _oceanwp$theme$owSlid.forEach(function (flickity) {
          flickity.destroy();
        });
      }

      oceanwp.theme.owSlider.start();
    }
  });

  if (_constants.DOM.body.classList.contains("has-grid-list")) {
    (0, _classPrivateFieldGet2["default"])(this, _start).call(this);
    (0, _classPrivateFieldGet2["default"])(this, _setupEventListeners).call(this);
  } else {
    _jsCookie["default"].remove("gridcookie", {
      path: ""
    });
  }
};

var _default = WooGridList;
exports["default"] = _default;

},{"../../../constants":1,"../../../lib/utils":2,"@babel/runtime/helpers/classCallCheck":12,"@babel/runtime/helpers/classPrivateFieldGet":14,"@babel/runtime/helpers/interopRequireDefault":17,"js-cookie":21}],6:[function(require,module,exports){
"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _classPrivateFieldSet2 = _interopRequireDefault(require("@babel/runtime/helpers/classPrivateFieldSet"));

var _classPrivateFieldGet4 = _interopRequireDefault(require("@babel/runtime/helpers/classPrivateFieldGet"));

var _constants = require("../../../constants");

var _utils = require("../../../lib/utils");

var _loginBtn = /*#__PURE__*/new WeakMap();

var _registerBtn = /*#__PURE__*/new WeakMap();

var _loginBox = /*#__PURE__*/new WeakMap();

var _registerBox = /*#__PURE__*/new WeakMap();

var _start = /*#__PURE__*/new WeakMap();

var _setupEventListeners = /*#__PURE__*/new WeakMap();

var _onLoginBtnClick = /*#__PURE__*/new WeakMap();

var _onRegisterBtnClick = /*#__PURE__*/new WeakMap();

var WooGuestAccountPage = function WooGuestAccountPage() {
  var _this = this,
      _DOM$woo$guestAccount5;

  (0, _classCallCheck2["default"])(this, WooGuestAccountPage);

  _loginBtn.set(this, {
    writable: true,
    value: void 0
  });

  _registerBtn.set(this, {
    writable: true,
    value: void 0
  });

  _loginBox.set(this, {
    writable: true,
    value: void 0
  });

  _registerBox.set(this, {
    writable: true,
    value: void 0
  });

  _start.set(this, {
    writable: true,
    value: function value() {
      var _DOM$woo$guestAccount, _DOM$woo$guestAccount2, _DOM$woo$guestAccount3, _DOM$woo$guestAccount4;

      (0, _classPrivateFieldSet2["default"])(_this, _loginBtn, (_DOM$woo$guestAccount = _constants.DOM.woo.guestAccountPageNav) === null || _DOM$woo$guestAccount === void 0 ? void 0 : _DOM$woo$guestAccount.querySelector(".login a"));
      (0, _classPrivateFieldSet2["default"])(_this, _registerBtn, (_DOM$woo$guestAccount2 = _constants.DOM.woo.guestAccountPageNav) === null || _DOM$woo$guestAccount2 === void 0 ? void 0 : _DOM$woo$guestAccount2.querySelector(".register a"));
      (0, _classPrivateFieldSet2["default"])(_this, _loginBox, (_DOM$woo$guestAccount3 = _constants.DOM.woo.guestAccountPageBox) === null || _DOM$woo$guestAccount3 === void 0 ? void 0 : _DOM$woo$guestAccount3.querySelector(".col-1"));
      (0, _classPrivateFieldSet2["default"])(_this, _registerBox, (_DOM$woo$guestAccount4 = _constants.DOM.woo.guestAccountPageBox) === null || _DOM$woo$guestAccount4 === void 0 ? void 0 : _DOM$woo$guestAccount4.querySelector(".col-2"));
    }
  });

  _setupEventListeners.set(this, {
    writable: true,
    value: function value() {
      var _classPrivateFieldGet2, _classPrivateFieldGet3;

      (_classPrivateFieldGet2 = (0, _classPrivateFieldGet4["default"])(_this, _loginBtn)) === null || _classPrivateFieldGet2 === void 0 ? void 0 : _classPrivateFieldGet2.addEventListener("click", (0, _classPrivateFieldGet4["default"])(_this, _onLoginBtnClick));
      (_classPrivateFieldGet3 = (0, _classPrivateFieldGet4["default"])(_this, _registerBtn)) === null || _classPrivateFieldGet3 === void 0 ? void 0 : _classPrivateFieldGet3.addEventListener("click", (0, _classPrivateFieldGet4["default"])(_this, _onRegisterBtnClick));
    }
  });

  _onLoginBtnClick.set(this, {
    writable: true,
    value: function value(event) {
      event.preventDefault();
      event.stopPropagation();
      (0, _classPrivateFieldGet4["default"])(_this, _loginBtn).classList.add("current");
      (0, _classPrivateFieldGet4["default"])(_this, _registerBtn).classList.remove("current");
      (0, _utils.fadeOut)((0, _classPrivateFieldGet4["default"])(_this, _registerBox), {
        callback: function callback() {
          (0, _utils.fadeIn)((0, _classPrivateFieldGet4["default"])(_this, _loginBox));
        }
      });
    }
  });

  _onRegisterBtnClick.set(this, {
    writable: true,
    value: function value(event) {
      event.preventDefault();
      event.stopPropagation();
      (0, _classPrivateFieldGet4["default"])(_this, _registerBtn).classList.add("current");
      (0, _classPrivateFieldGet4["default"])(_this, _loginBtn).classList.remove("current");
      (0, _utils.fadeOut)((0, _classPrivateFieldGet4["default"])(_this, _loginBox), {
        callback: function callback() {
          (0, _utils.fadeIn)((0, _classPrivateFieldGet4["default"])(_this, _registerBox));
        }
      });
    }
  });

  // Return if registration disabled
  if ((_DOM$woo$guestAccount5 = _constants.DOM.woo.guestAccountPageNav) !== null && _DOM$woo$guestAccount5 !== void 0 && _DOM$woo$guestAccount5.classList.contains("registration-disabled")) {
    return;
  }

  (0, _classPrivateFieldGet4["default"])(this, _start).call(this);
  (0, _classPrivateFieldGet4["default"])(this, _setupEventListeners).call(this);
};

var _default = WooGuestAccountPage;
exports["default"] = _default;

},{"../../../constants":1,"../../../lib/utils":2,"@babel/runtime/helpers/classCallCheck":12,"@babel/runtime/helpers/classPrivateFieldGet":14,"@babel/runtime/helpers/classPrivateFieldSet":15,"@babel/runtime/helpers/interopRequireDefault":17}],7:[function(require,module,exports){
"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _classPrivateFieldGet2 = _interopRequireDefault(require("@babel/runtime/helpers/classPrivateFieldGet"));

var _classPrivateFieldSet2 = _interopRequireDefault(require("@babel/runtime/helpers/classPrivateFieldSet"));

var _delegate = _interopRequireDefault(require("delegate"));

var _constants = require("../../../constants");

var _changeEvent = /*#__PURE__*/new WeakMap();

var _firstTimeRunning = /*#__PURE__*/new WeakMap();

var _setupEventListeners = /*#__PURE__*/new WeakMap();

var _onQuantityInputKeyup = /*#__PURE__*/new WeakMap();

var _onQuantityBtnClick = /*#__PURE__*/new WeakMap();

var WooQuantityButtons = function WooQuantityButtons() {
  var _this = this;

  (0, _classCallCheck2["default"])(this, WooQuantityButtons);

  _changeEvent.set(this, {
    writable: true,
    value: void 0
  });

  _firstTimeRunning.set(this, {
    writable: true,
    value: void 0
  });

  (0, _defineProperty2["default"])(this, "start", function () {
    var quantityInputs = document.querySelectorAll(".quantity:not(.buttons_added) .qty");

    if (!!quantityInputs) {
      quantityInputs.forEach(function (quantityInput) {
        var inputType = quantityInput.getAttribute("type");

        if (!(inputType === "date" || inputType === "hidden")) {
          var _quantityInput$previo, _quantityInput$nextEl;

          // Add minus icon
          if (!((_quantityInput$previo = quantityInput.previousElementSibling) !== null && _quantityInput$previo !== void 0 && _quantityInput$previo.classList.contains("minus"))) {
            quantityInput.insertAdjacentHTML("beforebegin", '<a href="javascript:void(0)" class="minus">-</a>');
          } // Add plus icon


          if (!((_quantityInput$nextEl = quantityInput.nextElementSibling) !== null && _quantityInput$nextEl !== void 0 && _quantityInput$nextEl.classList.contains("plus"))) {
            quantityInput.insertAdjacentHTML("afterend", '<a href="javascript:void(0)" class="plus">+</a>');
          }
        }
      }); // Check quantity bigger than min

      document.querySelectorAll("input.qty:not(.product-quantity input.qty)").forEach(function (quantityInput) {
        var min = parseFloat(quantityInput.getAttribute("min"));
        var currentValue = parseFloat(quantityInput.value);

        if (min && min > 0 && currentValue < min) {
          quantityInput.value = min;
        }
      });

      if ((0, _classPrivateFieldGet2["default"])(_this, _firstTimeRunning)) {
        // Create a new 'change' event
        (0, _classPrivateFieldSet2["default"])(_this, _changeEvent, new Event("change", {
          bubbles: true
        }));
      }
    }
  });

  _setupEventListeners.set(this, {
    writable: true,
    value: function value() {
      var quantityInputs = document.querySelectorAll(".quantity:not(.buttons_added) .qty"); // Update floating bar quantity

      if (!!quantityInputs) {
        if (_constants.DOM.body.classList.contains("single-product") && _constants.options.floating_bar === "on" && !Array.from(_constants.DOM.woo.productCarts).some(function (_ref) {
          var classList = _ref.classList;
          return classList.contains("grouped_form") || classList.contains("cart_group");
        })) {
          quantityInputs.forEach(function (quantityInput) {
            quantityInput.addEventListener("keyup", (0, _classPrivateFieldGet2["default"])(_this, _onQuantityInputKeyup));
            quantityInput.addEventListener("change", (0, _classPrivateFieldGet2["default"])(_this, _onQuantityInputKeyup));
          });
        }
      }

      (0, _delegate["default"])(_constants.DOM.body, ".cart .minus, .cart .plus, .tinv-wishlist .minus, .tinv-wishlist .plus, .quantity .minus, .quantity .plus", "click", (0, _classPrivateFieldGet2["default"])(_this, _onQuantityBtnClick));
    }
  });

  _onQuantityInputKeyup.set(this, {
    writable: true,
    value: function value(event) {
      var currentQuantityInput = event.target;
      var inputType = currentQuantityInput.getAttribute("type");
      var quantityInputs = document.querySelectorAll(".quantity:not(.buttons_added) .qty");

      if (!(inputType === "date" || inputType === "hidden")) {
        quantityInputs.forEach(function (quantityInput) {
          quantityInput.value = currentQuantityInput.value;
        });
      }
    }
  });

  _onQuantityBtnClick.set(this, {
    writable: true,
    value: function value(event) {
      var _quantityBtn$closest, _quantityBtn$closest2;

      event.preventDefault();
      event.stopPropagation();
      var quantityBtn = event.delegateTarget;
      var quantityInput = quantityBtn.closest(".quantity").querySelector(".qty");
      var currentValue = parseFloat(quantityInput.value);
      var min = parseFloat(quantityInput.getAttribute("min"));
      var max = parseFloat(quantityInput.getAttribute("max"));
      var step = quantityInput.getAttribute("step"); // Fallback default values

      if (!currentValue || currentValue === "" || Number.isNaN(currentValue)) {
        currentValue = 0;
      }

      if (max === "" || Number.isNaN(max)) {
        max = "";
      }

      if (min === "" || Number.isNaN(min)) {
        min = 0;
      }

      if (step === undefined || step === "" || step === "any" || Number.isNaN(parseFloat(step))) {
        step = 1;
      } // Plus button


      if (quantityBtn.classList.contains("plus")) {
        if (max && (currentValue === max || currentValue > max)) {
          quantityInput.value = max;
        } else {
          quantityInput.value = currentValue + parseFloat(step);
        } // Minus button

      } else {
        if (min && (currentValue === min || currentValue < min)) {
          quantityInput.value = min;
        } else if (currentValue > 0) {
          quantityInput.value = currentValue - parseFloat(step);
        }
      }

      if (!!((_quantityBtn$closest = quantityBtn.closest("form")) !== null && _quantityBtn$closest !== void 0 && _quantityBtn$closest.querySelector(".add_to_cart_button"))) {
        quantityBtn.closest("form").querySelector(".add_to_cart_button").dataset.quantity = quantityInput.value;
      }

      if (!!((_quantityBtn$closest2 = quantityBtn.closest(".cart")) !== null && _quantityBtn$closest2 !== void 0 && _quantityBtn$closest2.querySelector(".add_to_cart_button"))) {
        quantityBtn.closest(".cart").querySelector(".add_to_cart_button").dataset.quantity = quantityInput.value;
      } // Trigger change event


      quantityInput.dispatchEvent((0, _classPrivateFieldGet2["default"])(_this, _changeEvent));
    }
  });

  (0, _classPrivateFieldSet2["default"])(this, _firstTimeRunning, true);
  this.start();
  (0, _classPrivateFieldGet2["default"])(this, _setupEventListeners).call(this);
};

var _default = WooQuantityButtons;
exports["default"] = _default;

},{"../../../constants":1,"@babel/runtime/helpers/classCallCheck":12,"@babel/runtime/helpers/classPrivateFieldGet":14,"@babel/runtime/helpers/classPrivateFieldSet":15,"@babel/runtime/helpers/defineProperty":16,"@babel/runtime/helpers/interopRequireDefault":17,"delegate":20}],8:[function(require,module,exports){
"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _classPrivateFieldGet2 = _interopRequireDefault(require("@babel/runtime/helpers/classPrivateFieldGet"));

var _constants = require("../../../constants");

var _utils = require("../../../lib/utils");

var _setupEventListeners = /*#__PURE__*/new WeakMap();

var _onCustomerReviewLinkClick = /*#__PURE__*/new WeakMap();

var WooScrollToReviewTab = function WooScrollToReviewTab() {
  var _this = this;

  (0, _classCallCheck2["default"])(this, WooScrollToReviewTab);

  _setupEventListeners.set(this, {
    writable: true,
    value: function value() {
      _constants.DOM.woo.productCustomerReviewLink.addEventListener("click", (0, _classPrivateFieldGet2["default"])(_this, _onCustomerReviewLinkClick));
    }
  });

  _onCustomerReviewLinkClick.set(this, {
    writable: true,
    value: function value(event) {
      event.preventDefault();
      event.stopPropagation();

      if (!!_constants.DOM.woo.productTabs.querySelector(".description_tab")) {
        _constants.DOM.woo.productTabs.querySelector(".description_tab").classList.remove("active");

        _constants.DOM.woo.productTabs.querySelector("#tab-description").style.display = "none";
      }

      if (_constants.DOM.woo.productTabs.querySelector(".additional_information_tab")) {
        _constants.DOM.woo.productTabs.querySelector(".additional_information_tab").classList.remove("active");

        _constants.DOM.woo.productTabs.querySelector("#tab-additional_information").style.display = "none";
      }

      _constants.DOM.woo.productTabs.querySelector(".reviews_tab").classList.add("active");

      _constants.DOM.woo.productTabs.querySelector("#tab-reviews").style.display = "block";
      var reviewTabPositionTop = (0, _utils.offset)(document.querySelector(event.currentTarget.hash)).top;

      _constants.DOM.html.scrollTo({
        top: reviewTabPositionTop - 120,
        behavior: "smooth"
      });
    }
  });

  if (!!_constants.DOM.woo.productCustomerReviewLink) {
    (0, _classPrivateFieldGet2["default"])(this, _setupEventListeners).call(this);
  }
};

var _default = WooScrollToReviewTab;
exports["default"] = _default;

},{"../../../constants":1,"../../../lib/utils":2,"@babel/runtime/helpers/classCallCheck":12,"@babel/runtime/helpers/classPrivateFieldGet":14,"@babel/runtime/helpers/interopRequireDefault":17}],9:[function(require,module,exports){
"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _resetVariations = _interopRequireDefault(require("./custom-features/reset-variations"));

var _wooGridList = _interopRequireDefault(require("./custom-features/woo-grid-list"));

var _wooGuestAccountPage = _interopRequireDefault(require("./custom-features/woo-guest-account-page"));

var _wooQuantityButtons = _interopRequireDefault(require("./custom-features/woo-quantity-buttons"));

var _wooScrollToReviewTab = _interopRequireDefault(require("./custom-features/woo-scroll-to-review-tab"));

var _removeCategoriesCountParenthesis = _interopRequireDefault(require("./custom-features/remove-categories-count-parenthesis"));

var WooCustomFeatures = function WooCustomFeatures() {
  var _this = this;

  (0, _classCallCheck2["default"])(this, WooCustomFeatures);
  (0, _defineProperty2["default"])(this, "start", function () {
    _this.resetVariations = new _resetVariations["default"]();
    _this.gridList = new _wooGridList["default"]();
    _this.guestAccountPage = new _wooGuestAccountPage["default"]();
    _this.quantityButtons = new _wooQuantityButtons["default"]();
    _this.reviewScroll = new _wooScrollToReviewTab["default"]();
    _this.widgets = new _removeCategoriesCountParenthesis["default"]();
    /**
     * Because Woocommerce plugin uses jQuery custom event,
     * We also have to use jQuery to customize this event.
     */

    jQuery("body").on("updated_cart_totals", function () {
      _this.quantityButtons.start();
    });
    jQuery(document).on("append.infiniteScroll", function () {
      _this.quantityButtons.start();
    });
  });
};

window.oceanwpWooCustomFeatures = new WooCustomFeatures();
oceanwpWooCustomFeatures.start();

},{"./custom-features/remove-categories-count-parenthesis":3,"./custom-features/reset-variations":4,"./custom-features/woo-grid-list":5,"./custom-features/woo-guest-account-page":6,"./custom-features/woo-quantity-buttons":7,"./custom-features/woo-scroll-to-review-tab":8,"@babel/runtime/helpers/classCallCheck":12,"@babel/runtime/helpers/defineProperty":16,"@babel/runtime/helpers/interopRequireDefault":17}],10:[function(require,module,exports){
function _classApplyDescriptorGet(receiver, descriptor) {
  if (descriptor.get) {
    return descriptor.get.call(receiver);
  }

  return descriptor.value;
}

module.exports = _classApplyDescriptorGet;
module.exports["default"] = module.exports, module.exports.__esModule = true;
},{}],11:[function(require,module,exports){
function _classApplyDescriptorSet(receiver, descriptor, value) {
  if (descriptor.set) {
    descriptor.set.call(receiver, value);
  } else {
    if (!descriptor.writable) {
      throw new TypeError("attempted to set read only private field");
    }

    descriptor.value = value;
  }
}

module.exports = _classApplyDescriptorSet;
module.exports["default"] = module.exports, module.exports.__esModule = true;
},{}],12:[function(require,module,exports){
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

module.exports = _classCallCheck;
module.exports["default"] = module.exports, module.exports.__esModule = true;
},{}],13:[function(require,module,exports){
function _classExtractFieldDescriptor(receiver, privateMap, action) {
  if (!privateMap.has(receiver)) {
    throw new TypeError("attempted to " + action + " private field on non-instance");
  }

  return privateMap.get(receiver);
}

module.exports = _classExtractFieldDescriptor;
module.exports["default"] = module.exports, module.exports.__esModule = true;
},{}],14:[function(require,module,exports){
var classApplyDescriptorGet = require("./classApplyDescriptorGet.js");

var classExtractFieldDescriptor = require("./classExtractFieldDescriptor.js");

function _classPrivateFieldGet(receiver, privateMap) {
  var descriptor = classExtractFieldDescriptor(receiver, privateMap, "get");
  return classApplyDescriptorGet(receiver, descriptor);
}

module.exports = _classPrivateFieldGet;
module.exports["default"] = module.exports, module.exports.__esModule = true;
},{"./classApplyDescriptorGet.js":10,"./classExtractFieldDescriptor.js":13}],15:[function(require,module,exports){
var classApplyDescriptorSet = require("./classApplyDescriptorSet.js");

var classExtractFieldDescriptor = require("./classExtractFieldDescriptor.js");

function _classPrivateFieldSet(receiver, privateMap, value) {
  var descriptor = classExtractFieldDescriptor(receiver, privateMap, "set");
  classApplyDescriptorSet(receiver, descriptor, value);
  return value;
}

module.exports = _classPrivateFieldSet;
module.exports["default"] = module.exports, module.exports.__esModule = true;
},{"./classApplyDescriptorSet.js":11,"./classExtractFieldDescriptor.js":13}],16:[function(require,module,exports){
function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

module.exports = _defineProperty;
module.exports["default"] = module.exports, module.exports.__esModule = true;
},{}],17:[function(require,module,exports){
function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;
module.exports["default"] = module.exports, module.exports.__esModule = true;
},{}],18:[function(require,module,exports){
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return typeof obj;
    };

    module.exports["default"] = module.exports, module.exports.__esModule = true;
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };

    module.exports["default"] = module.exports, module.exports.__esModule = true;
  }

  return _typeof(obj);
}

module.exports = _typeof;
module.exports["default"] = module.exports, module.exports.__esModule = true;
},{}],19:[function(require,module,exports){
var DOCUMENT_NODE_TYPE = 9;

/**
 * A polyfill for Element.matches()
 */
if (typeof Element !== 'undefined' && !Element.prototype.matches) {
    var proto = Element.prototype;

    proto.matches = proto.matchesSelector ||
                    proto.mozMatchesSelector ||
                    proto.msMatchesSelector ||
                    proto.oMatchesSelector ||
                    proto.webkitMatchesSelector;
}

/**
 * Finds the closest parent that matches a selector.
 *
 * @param {Element} element
 * @param {String} selector
 * @return {Function}
 */
function closest (element, selector) {
    while (element && element.nodeType !== DOCUMENT_NODE_TYPE) {
        if (typeof element.matches === 'function' &&
            element.matches(selector)) {
          return element;
        }
        element = element.parentNode;
    }
}

module.exports = closest;

},{}],20:[function(require,module,exports){
var closest = require('./closest');

/**
 * Delegates event to a selector.
 *
 * @param {Element} element
 * @param {String} selector
 * @param {String} type
 * @param {Function} callback
 * @param {Boolean} useCapture
 * @return {Object}
 */
function _delegate(element, selector, type, callback, useCapture) {
    var listenerFn = listener.apply(this, arguments);

    element.addEventListener(type, listenerFn, useCapture);

    return {
        destroy: function() {
            element.removeEventListener(type, listenerFn, useCapture);
        }
    }
}

/**
 * Delegates event to a selector.
 *
 * @param {Element|String|Array} [elements]
 * @param {String} selector
 * @param {String} type
 * @param {Function} callback
 * @param {Boolean} useCapture
 * @return {Object}
 */
function delegate(elements, selector, type, callback, useCapture) {
    // Handle the regular Element usage
    if (typeof elements.addEventListener === 'function') {
        return _delegate.apply(null, arguments);
    }

    // Handle Element-less usage, it defaults to global delegation
    if (typeof type === 'function') {
        // Use `document` as the first parameter, then apply arguments
        // This is a short way to .unshift `arguments` without running into deoptimizations
        return _delegate.bind(null, document).apply(null, arguments);
    }

    // Handle Selector-based usage
    if (typeof elements === 'string') {
        elements = document.querySelectorAll(elements);
    }

    // Handle Array-like based usage
    return Array.prototype.map.call(elements, function (element) {
        return _delegate(element, selector, type, callback, useCapture);
    });
}

/**
 * Finds closest match and invokes callback.
 *
 * @param {Element} element
 * @param {String} selector
 * @param {String} type
 * @param {Function} callback
 * @return {Function}
 */
function listener(element, selector, type, callback) {
    return function(e) {
        e.delegateTarget = closest(e.target, selector);

        if (e.delegateTarget) {
            callback.call(element, e);
        }
    }
}

module.exports = delegate;

},{"./closest":19}],21:[function(require,module,exports){
/*!
 * JavaScript Cookie v2.2.1
 * https://github.com/js-cookie/js-cookie
 *
 * Copyright 2006, 2015 Klaus Hartl & Fagner Brack
 * Released under the MIT license
 */
;(function (factory) {
	var registeredInModuleLoader;
	if (typeof define === 'function' && define.amd) {
		define(factory);
		registeredInModuleLoader = true;
	}
	if (typeof exports === 'object') {
		module.exports = factory();
		registeredInModuleLoader = true;
	}
	if (!registeredInModuleLoader) {
		var OldCookies = window.Cookies;
		var api = window.Cookies = factory();
		api.noConflict = function () {
			window.Cookies = OldCookies;
			return api;
		};
	}
}(function () {
	function extend () {
		var i = 0;
		var result = {};
		for (; i < arguments.length; i++) {
			var attributes = arguments[ i ];
			for (var key in attributes) {
				result[key] = attributes[key];
			}
		}
		return result;
	}

	function decode (s) {
		return s.replace(/(%[0-9A-Z]{2})+/g, decodeURIComponent);
	}

	function init (converter) {
		function api() {}

		function set (key, value, attributes) {
			if (typeof document === 'undefined') {
				return;
			}

			attributes = extend({
				path: '/'
			}, api.defaults, attributes);

			if (typeof attributes.expires === 'number') {
				attributes.expires = new Date(new Date() * 1 + attributes.expires * 864e+5);
			}

			// We're using "expires" because "max-age" is not supported by IE
			attributes.expires = attributes.expires ? attributes.expires.toUTCString() : '';

			try {
				var result = JSON.stringify(value);
				if (/^[\{\[]/.test(result)) {
					value = result;
				}
			} catch (e) {}

			value = converter.write ?
				converter.write(value, key) :
				encodeURIComponent(String(value))
					.replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g, decodeURIComponent);

			key = encodeURIComponent(String(key))
				.replace(/%(23|24|26|2B|5E|60|7C)/g, decodeURIComponent)
				.replace(/[\(\)]/g, escape);

			var stringifiedAttributes = '';
			for (var attributeName in attributes) {
				if (!attributes[attributeName]) {
					continue;
				}
				stringifiedAttributes += '; ' + attributeName;
				if (attributes[attributeName] === true) {
					continue;
				}

				// Considers RFC 6265 section 5.2:
				// ...
				// 3.  If the remaining unparsed-attributes contains a %x3B (";")
				//     character:
				// Consume the characters of the unparsed-attributes up to,
				// not including, the first %x3B (";") character.
				// ...
				stringifiedAttributes += '=' + attributes[attributeName].split(';')[0];
			}

			return (document.cookie = key + '=' + value + stringifiedAttributes);
		}

		function get (key, json) {
			if (typeof document === 'undefined') {
				return;
			}

			var jar = {};
			// To prevent the for loop in the first place assign an empty array
			// in case there are no cookies at all.
			var cookies = document.cookie ? document.cookie.split('; ') : [];
			var i = 0;

			for (; i < cookies.length; i++) {
				var parts = cookies[i].split('=');
				var cookie = parts.slice(1).join('=');

				if (!json && cookie.charAt(0) === '"') {
					cookie = cookie.slice(1, -1);
				}

				try {
					var name = decode(parts[0]);
					cookie = (converter.read || converter)(cookie, name) ||
						decode(cookie);

					if (json) {
						try {
							cookie = JSON.parse(cookie);
						} catch (e) {}
					}

					jar[name] = cookie;

					if (key === name) {
						break;
					}
				} catch (e) {}
			}

			return key ? jar[key] : jar;
		}

		api.set = set;
		api.get = function (key) {
			return get(key, false /* read as raw */);
		};
		api.getJSON = function (key) {
			return get(key, true /* read as json */);
		};
		api.remove = function (key, attributes) {
			set(key, '', extend(attributes, {
				expires: -1
			}));
		};

		api.defaults = {};

		api.withConverter = init;

		return api;
	}

	return init(function () {});
}));

},{}]},{},[9])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJhc3NldHMvc3JjL2pzL2NvbnN0YW50cy5qcyIsImFzc2V0cy9zcmMvanMvbGliL3V0aWxzLmpzIiwiYXNzZXRzL3NyYy9qcy93cC1wbHVnaW5zL3dvb2NvbW1lcmNlL2N1c3RvbS1mZWF0dXJlcy9yZW1vdmUtY2F0ZWdvcmllcy1jb3VudC1wYXJlbnRoZXNpcy5qcyIsImFzc2V0cy9zcmMvanMvd3AtcGx1Z2lucy93b29jb21tZXJjZS9jdXN0b20tZmVhdHVyZXMvcmVzZXQtdmFyaWF0aW9ucy5qcyIsImFzc2V0cy9zcmMvanMvd3AtcGx1Z2lucy93b29jb21tZXJjZS9jdXN0b20tZmVhdHVyZXMvd29vLWdyaWQtbGlzdC5qcyIsImFzc2V0cy9zcmMvanMvd3AtcGx1Z2lucy93b29jb21tZXJjZS9jdXN0b20tZmVhdHVyZXMvd29vLWd1ZXN0LWFjY291bnQtcGFnZS5qcyIsImFzc2V0cy9zcmMvanMvd3AtcGx1Z2lucy93b29jb21tZXJjZS9jdXN0b20tZmVhdHVyZXMvd29vLXF1YW50aXR5LWJ1dHRvbnMuanMiLCJhc3NldHMvc3JjL2pzL3dwLXBsdWdpbnMvd29vY29tbWVyY2UvY3VzdG9tLWZlYXR1cmVzL3dvby1zY3JvbGwtdG8tcmV2aWV3LXRhYi5qcyIsImFzc2V0cy9zcmMvanMvd3AtcGx1Z2lucy93b29jb21tZXJjZS93b28tY3VzdG9tLWZlYXR1cmVzLmpzIiwibm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvY2xhc3NBcHBseURlc2NyaXB0b3JHZXQuanMiLCJub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy9jbGFzc0FwcGx5RGVzY3JpcHRvclNldC5qcyIsIm5vZGVfbW9kdWxlcy9AYmFiZWwvcnVudGltZS9oZWxwZXJzL2NsYXNzQ2FsbENoZWNrLmpzIiwibm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvY2xhc3NFeHRyYWN0RmllbGREZXNjcmlwdG9yLmpzIiwibm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvY2xhc3NQcml2YXRlRmllbGRHZXQuanMiLCJub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy9jbGFzc1ByaXZhdGVGaWVsZFNldC5qcyIsIm5vZGVfbW9kdWxlcy9AYmFiZWwvcnVudGltZS9oZWxwZXJzL2RlZmluZVByb3BlcnR5LmpzIiwibm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvaW50ZXJvcFJlcXVpcmVEZWZhdWx0LmpzIiwibm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvdHlwZW9mLmpzIiwibm9kZV9tb2R1bGVzL2RlbGVnYXRlL3NyYy9jbG9zZXN0LmpzIiwibm9kZV9tb2R1bGVzL2RlbGVnYXRlL3NyYy9kZWxlZ2F0ZS5qcyIsIm5vZGVfbW9kdWxlcy9qcy1jb29raWUvc3JjL2pzLmNvb2tpZS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7OztBQ0FPLElBQU0sT0FBTyxHQUFHLGVBQWhCOztBQUVBLElBQU0sR0FBRyxHQUFHO0FBQ2YsRUFBQSxJQUFJLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsTUFBdkIsQ0FEUztBQUVmLEVBQUEsSUFBSSxFQUFFLFFBQVEsQ0FBQyxJQUZBO0FBR2YsRUFBQSxVQUFVLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsYUFBdkIsQ0FIRztBQUlmLEVBQUEsSUFBSSxFQUFFLFFBQVEsQ0FBQyxhQUFULENBQXVCLE9BQXZCLENBSlM7QUFLZixFQUFBLElBQUksRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1QixPQUF2QixDQUxTO0FBTWYsRUFBQSxVQUFVLEVBQUUsUUFBUSxDQUFDLGdCQUFULENBQTBCLE9BQU8sQ0FBQyxhQUFsQyxDQU5HO0FBT2YsRUFBQSxXQUFXLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsbUJBQXZCLENBUEU7QUFRZixFQUFBLE1BQU0sRUFBRTtBQUNKLElBQUEsSUFBSSxFQUFFLFFBQVEsQ0FBQyxhQUFULENBQXVCLGNBQXZCLENBREY7QUFFSixJQUFBLFFBQVEsRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1QixpREFBdkIsQ0FGTjtBQUdKLElBQUEsVUFBVSxFQUFFLFFBQVEsQ0FBQyxhQUFULENBQXVCLGlDQUF2QixDQUhSO0FBSUosSUFBQSxNQUFNLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsVUFBdkIsQ0FKSjtBQUtKLElBQUEsYUFBYSxFQUFFLFFBQVEsQ0FBQyxhQUFULENBQXVCLGVBQXZCLENBTFg7QUFNSixJQUFBLFdBQVcsRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1QiwyQ0FBdkIsQ0FOVDtBQU9KLElBQUEsWUFBWSxFQUFFLFFBQVEsQ0FBQyxhQUFULENBQXVCLDRDQUF2QjtBQVBWLEdBUk87QUFpQmYsRUFBQSxJQUFJLEVBQUU7QUFDRixJQUFBLEdBQUcsRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1Qiw4Q0FBdkIsQ0FESDtBQUVGLElBQUEsSUFBSSxFQUFFLFFBQVEsQ0FBQyxhQUFULENBQXVCLFlBQXZCLENBRko7QUFHRixJQUFBLFVBQVUsRUFBRTtBQUNSLE1BQUEsSUFBSSxFQUFFLFFBQVEsQ0FBQyxhQUFULENBQXVCLG1EQUF2QixDQURFO0FBRVIsTUFBQSxhQUFhLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsMkNBQXZCLENBRlA7QUFHUixNQUFBLElBQUksRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1QixpQ0FBdkI7QUFIRSxLQUhWO0FBUUYsSUFBQSxJQUFJLEVBQUU7QUFDRixNQUFBLFNBQVMsRUFBRSxRQUFRLENBQUMsZ0JBQVQsQ0FBMEIseUNBQTFCLENBRFQ7QUFFRixNQUFBLGVBQWUsRUFBRSxRQUFRLENBQUMsZ0JBQVQsQ0FBMEIscUNBQTFCLENBRmY7QUFHRixNQUFBLFlBQVksRUFBRSxRQUFRLENBQUMsZ0JBQVQsQ0FBMEIsOENBQTFCO0FBSFosS0FSSjtBQWFGLElBQUEsUUFBUSxFQUFFO0FBQ04sTUFBQSxhQUFhLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsbUJBQXZCO0FBRFQ7QUFiUixHQWpCUztBQWtDZixFQUFBLFVBQVUsRUFBRTtBQUNSLElBQUEsR0FBRyxFQUFFLFFBQVEsQ0FBQyxhQUFULENBQXVCLHdCQUF2QixDQURHO0FBRVIsSUFBQSxVQUFVLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsa0JBQXZCLENBRko7QUFHUixJQUFBLGFBQWEsRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1QixjQUF2QixDQUhQO0FBSVIsSUFBQSxZQUFZLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsMkJBQXZCLENBSk47QUFLUixJQUFBLG9CQUFvQixFQUFFLFFBQVEsQ0FBQyxnQkFBVCxDQUEwQiwwQ0FBMUIsQ0FMZDtBQU1SLElBQUEsVUFBVSxFQUFFLFFBQVEsQ0FBQyxhQUFULENBQXVCLG9CQUF2QjtBQU5KLEdBbENHO0FBMENmLEVBQUEsTUFBTSxFQUFFO0FBQ0osSUFBQSxLQUFLLEVBQUUsUUFBUSxDQUFDLGdCQUFULENBQTBCLHdCQUExQixDQURIO0FBRUosSUFBQSxRQUFRLEVBQUU7QUFDTixNQUFBLGVBQWUsRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1QiwwQkFBdkIsQ0FEWDtBQUVOLE1BQUEsSUFBSSxFQUFFLFFBQVEsQ0FBQyxhQUFULENBQXVCLHNCQUF2QjtBQUZBLEtBRk47QUFNSixJQUFBLGFBQWEsRUFBRTtBQUNYLE1BQUEsZUFBZSxFQUFFLFFBQVEsQ0FBQyxhQUFULENBQXVCLGdDQUF2QixDQUROO0FBRVgsTUFBQSxRQUFRLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsa0NBQXZCLENBRkM7QUFHWCxNQUFBLElBQUksRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1Qiw0QkFBdkI7QUFISyxLQU5YO0FBV0osSUFBQSxPQUFPLEVBQUU7QUFDTCxNQUFBLGVBQWUsRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1Qix5QkFBdkIsQ0FEWjtBQUVMLE1BQUEsUUFBUSxFQUFFLFFBQVEsQ0FBQyxhQUFULENBQXVCLDRDQUF2QixDQUZMO0FBR0wsTUFBQSxJQUFJLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIscUJBQXZCO0FBSEQ7QUFYTCxHQTFDTztBQTJEZixFQUFBLE1BQU0sRUFBRTtBQUNKLElBQUEsVUFBVSxFQUFFLFFBQVEsQ0FBQyxhQUFULENBQXVCLFNBQXZCLENBRFI7QUFFSixJQUFBLGFBQWEsRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1QixzQkFBdkIsQ0FGWDtBQUdKLElBQUEsU0FBUyxFQUFFLFFBQVEsQ0FBQyxhQUFULENBQXVCLGFBQXZCLENBSFA7QUFJSixJQUFBLFFBQVEsRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1QixrQkFBdkI7QUFKTixHQTNETztBQWlFZixFQUFBLE1BQU0sRUFBRTtBQUNKLElBQUEsU0FBUyxFQUFFLFFBQVEsQ0FBQyxhQUFULENBQXVCLGFBQXZCLENBRFA7QUFFSixJQUFBLEtBQUssRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1QixtQkFBdkIsQ0FGSDtBQUdKLElBQUEsVUFBVSxFQUFFLFFBQVEsQ0FBQyxhQUFULENBQXVCLDhCQUF2QixDQUhSO0FBSUosSUFBQSxpQkFBaUIsRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1QixzQkFBdkIsQ0FKZjtBQUtKLElBQUEscUJBQXFCLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsdUJBQXZCO0FBTG5CLEdBakVPO0FBd0VmLEVBQUEsSUFBSSxFQUFFO0FBQ0YsSUFBQSxZQUFZLEVBQUUsUUFBUSxDQUFDLGdCQUFULENBQTBCLG9CQUExQjtBQURaLEdBeEVTO0FBMkVmLEVBQUEsR0FBRyxFQUFFO0FBQ0QsSUFBQSxLQUFLLEVBQUUsUUFBUSxDQUFDLGdCQUFULENBQTBCLGdCQUExQixDQUROO0FBRUQsSUFBQSxXQUFXLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsbUJBQXZCLENBRlo7QUFHRCxJQUFBLFdBQVcsRUFBRSxRQUFRLENBQUMsZ0JBQVQsQ0FBMEIsNEJBQTFCLENBSFo7QUFJRCxJQUFBLGNBQWMsRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1QixjQUF2QixDQUpmO0FBS0QsSUFBQSxnQkFBZ0IsRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1QixpQkFBdkI7QUFMakIsR0EzRVU7QUFrRmYsRUFBQSxHQUFHLEVBQUU7QUFDRCxJQUFBLGVBQWUsRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1QixtQkFBdkIsQ0FEaEI7QUFFRCxJQUFBLE9BQU8sRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1QiwwQkFBdkIsQ0FGUjtBQUdELElBQUEsV0FBVyxFQUFFLFFBQVEsQ0FBQyxnQkFBVCxDQUEwQiwwQkFBMUIsQ0FIWjtBQUlELElBQUEsVUFBVSxFQUFFLFFBQVEsQ0FBQyxnQkFBVCxDQUEwQix1Q0FBMUIsQ0FKWDtBQUtELElBQUEsY0FBYyxFQUFFLFFBQVEsQ0FBQyxnQkFBVCxDQUEwQiw2QkFBMUIsQ0FMZjtBQU1ELElBQUEsb0JBQW9CLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsNkJBQXZCLENBTnJCO0FBT0QsSUFBQSxJQUFJLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsa0NBQXZCLENBUEw7QUFRRCxJQUFBLElBQUksRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1QixrQ0FBdkIsQ0FSTDtBQVNELElBQUEsV0FBVyxFQUFFLFFBQVEsQ0FBQyxhQUFULENBQXVCLDRDQUF2QixDQVRaO0FBVUQsSUFBQSxZQUFZLEVBQUUsUUFBUSxDQUFDLGdCQUFULENBQTBCLGdDQUExQixDQVZiO0FBV0QsSUFBQSx5QkFBeUIsRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1QixtREFBdkIsQ0FYMUI7QUFZRCxJQUFBLFFBQVEsRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1Qix3QkFBdkIsQ0FaVDtBQWFELElBQUEsWUFBWSxFQUFFLFFBQVEsQ0FBQyxhQUFULENBQXVCLDJCQUF2QixDQWJiO0FBY0QsSUFBQSxhQUFhLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsaUJBQXZCLENBZGQ7QUFlRCxJQUFBLGNBQWMsRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1QixrQkFBdkIsQ0FmZjtBQWdCRCxJQUFBLGdCQUFnQixFQUFFLFFBQVEsQ0FBQyxhQUFULENBQXVCLHdCQUF2QixDQWhCakI7QUFpQkQsSUFBQSxzQkFBc0IsRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1QiwyQkFBdkIsQ0FqQnZCO0FBa0JELElBQUEsdUJBQXVCLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsNEJBQXZCLENBbEJ4QjtBQW1CRCxJQUFBLFdBQVcsRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1QixlQUF2QixDQW5CWjtBQW9CRCxJQUFBLG9CQUFvQixFQUFFLFFBQVEsQ0FBQyxhQUFULENBQXVCLHlCQUF2QixDQXBCckI7QUFxQkQsSUFBQSxVQUFVLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsY0FBdkIsQ0FyQlg7QUFzQkQsSUFBQSxXQUFXLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsZUFBdkIsQ0F0Qlo7QUF1QkQsSUFBQSxXQUFXLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsbUJBQXZCLENBdkJaO0FBd0JELElBQUEsbUJBQW1CLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsb0JBQXZCLENBeEJwQjtBQXlCRCxJQUFBLG1CQUFtQixFQUFFLFFBQVEsQ0FBQyxhQUFULENBQXVCLGlCQUF2QixDQXpCcEI7QUEwQkQsSUFBQSxjQUFjLEVBQUUsUUFBUSxDQUFDLGdCQUFULENBQTBCLG9DQUExQixDQTFCZjtBQTJCRCxJQUFBLFNBQVMsRUFBRTtBQUNQLE1BQUEsS0FBSyxFQUFFLFFBQVEsQ0FBQyxhQUFULENBQXVCLGNBQXZCLENBREE7QUFFUCxNQUFBLE9BQU8sRUFBRSxRQUFRLENBQUMsYUFBVCxDQUF1QixpQkFBdkI7QUFGRjtBQTNCVjtBQWxGVSxDQUFaOztBQW9IQSxJQUFNLFNBQVMsR0FBRyxFQUFsQjs7Ozs7Ozs7Ozs7Ozs7O0FDdEhBLElBQU0sSUFBSSxHQUFHLFNBQVAsSUFBTyxDQUFDLE9BQUQsRUFBc0Q7QUFBQSxNQUE1QyxPQUE0Qyx1RUFBbEMsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBa0M7O0FBQ3RFLE1BQUksT0FBTyxDQUFDLFdBQVosRUFBeUI7QUFDckIsSUFBQSxPQUFPLENBQUMsVUFBUixDQUFtQixZQUFuQixDQUFnQyxPQUFoQyxFQUF5QyxPQUFPLENBQUMsV0FBakQ7QUFDSCxHQUZELE1BRU87QUFDSCxJQUFBLE9BQU8sQ0FBQyxVQUFSLENBQW1CLFdBQW5CLENBQStCLE9BQS9CO0FBQ0g7O0FBRUQsU0FBTyxPQUFPLENBQUMsV0FBUixDQUFvQixPQUFwQixDQUFQO0FBQ0gsQ0FSTTs7OztBQVVBLElBQU0sU0FBUyxHQUFHLFNBQVosU0FBWSxDQUFDLE9BQUQsRUFBNkI7QUFBQSxNQUFuQixRQUFtQix1RUFBUixHQUFRO0FBQ2xELE1BQUksT0FBTyxHQUFHLE1BQU0sQ0FBQyxnQkFBUCxDQUF3QixPQUF4QixFQUFpQyxPQUEvQzs7QUFFQSxNQUFJLE9BQU8sS0FBSyxNQUFoQixFQUF3QjtBQUNwQixJQUFBLE9BQU8sR0FBRyxPQUFWO0FBQ0g7O0FBRUQsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLGtCQUFkLEdBQW1DLFFBQW5DO0FBQ0EsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLGtCQUFkLGFBQXNDLFFBQXRDO0FBRUEsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLE9BQWQsR0FBd0IsQ0FBeEI7QUFDQSxFQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsT0FBZCxHQUF3QixPQUF4QjtBQUNBLE1BQUksTUFBTSxHQUFHLE9BQU8sQ0FBQyxZQUFyQjtBQUVBLEVBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxNQUFkLEdBQXVCLENBQXZCO0FBQ0EsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLE9BQWQsR0FBd0IsQ0FBeEI7QUFDQSxFQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsUUFBZCxHQUF5QixRQUF6QjtBQUVBLEVBQUEsVUFBVSxDQUFDLFlBQU07QUFDYixJQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsTUFBZCxhQUEwQixNQUExQjtBQUNILEdBRlMsRUFFUCxDQUZPLENBQVY7QUFJQSxFQUFBLE1BQU0sQ0FBQyxVQUFQLENBQWtCLFlBQU07QUFDcEIsSUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLGNBQWQsQ0FBNkIsUUFBN0I7QUFDQSxJQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsY0FBZCxDQUE2QixVQUE3QjtBQUNBLElBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxjQUFkLENBQTZCLHFCQUE3QjtBQUNBLElBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxjQUFkLENBQTZCLHFCQUE3QjtBQUNBLElBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxjQUFkLENBQTZCLFNBQTdCO0FBQ0gsR0FORCxFQU1HLFFBQVEsR0FBRyxFQU5kO0FBT0gsQ0E3Qk07Ozs7QUErQkEsSUFBTSxPQUFPLEdBQUcsU0FBVixPQUFVLENBQUMsT0FBRCxFQUE2QjtBQUFBLE1BQW5CLFFBQW1CLHVFQUFSLEdBQVE7QUFDaEQsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLFNBQWQsR0FBMEIsWUFBMUI7QUFDQSxFQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsa0JBQWQsR0FBbUMsZ0JBQW5DO0FBQ0EsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLGtCQUFkLGFBQXNDLFFBQXRDO0FBQ0EsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLE1BQWQsYUFBMEIsT0FBTyxDQUFDLFlBQWxDO0FBQ0EsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLFNBQWQsR0FBMEIsQ0FBMUI7QUFDQSxFQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsWUFBZCxHQUE2QixDQUE3QjtBQUNBLEVBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxRQUFkLEdBQXlCLFFBQXpCO0FBRUEsRUFBQSxVQUFVLENBQUMsWUFBTTtBQUNiLElBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxNQUFkLEdBQXVCLENBQXZCO0FBQ0gsR0FGUyxFQUVQLENBRk8sQ0FBVjtBQUlBLEVBQUEsTUFBTSxDQUFDLFVBQVAsQ0FBa0IsWUFBTTtBQUNwQixJQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsT0FBZCxHQUF3QixNQUF4QjtBQUNBLElBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxjQUFkLENBQTZCLFFBQTdCO0FBQ0EsSUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLGNBQWQsQ0FBNkIsWUFBN0I7QUFDQSxJQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsY0FBZCxDQUE2QixlQUE3QjtBQUNBLElBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxjQUFkLENBQTZCLFVBQTdCO0FBQ0EsSUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLGNBQWQsQ0FBNkIscUJBQTdCO0FBQ0EsSUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLGNBQWQsQ0FBNkIscUJBQTdCO0FBQ0gsR0FSRCxFQVFHLFFBQVEsR0FBRyxFQVJkO0FBU0gsQ0F0Qk07Ozs7QUF3QkEsSUFBTSxXQUFXLEdBQUcsU0FBZCxXQUFjLENBQUMsT0FBRCxFQUFVLFFBQVYsRUFBdUI7QUFDOUMsRUFBQSxNQUFNLENBQUMsZ0JBQVAsQ0FBd0IsT0FBeEIsRUFBaUMsT0FBakMsS0FBNkMsTUFBN0MsR0FDTSxTQUFTLENBQUMsT0FBRCxFQUFVLFFBQVYsQ0FEZixHQUVNLE9BQU8sQ0FBQyxPQUFELEVBQVUsUUFBVixDQUZiO0FBR0gsQ0FKTTs7OztBQU1BLElBQU0sTUFBTSxHQUFHLFNBQVQsTUFBUyxDQUFDLE9BQUQsRUFBNEI7QUFBQSxNQUFsQixRQUFrQix1RUFBUCxFQUFPOztBQUM5QyxNQUFNLE9BQU8sR0FBRztBQUNaLElBQUEsUUFBUSxFQUFFLEdBREU7QUFFWixJQUFBLE9BQU8sRUFBRSxJQUZHO0FBR1osSUFBQSxPQUFPLEVBQUUsQ0FIRztBQUlaLElBQUEsUUFBUSxFQUFFO0FBSkUsR0FBaEI7QUFPQSxFQUFBLE1BQU0sQ0FBQyxNQUFQLENBQWMsT0FBZCxFQUF1QixRQUF2QjtBQUVBLEVBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxPQUFkLEdBQXdCLENBQXhCO0FBQ0EsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLE9BQWQsR0FBd0IsT0FBTyxDQUFDLE9BQVIsSUFBbUIsT0FBM0M7QUFFQSxFQUFBLFVBQVUsQ0FBQyxZQUFNO0FBQ2IsSUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLFVBQWQsYUFBOEIsT0FBTyxDQUFDLFFBQXRDO0FBQ0EsSUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLE9BQWQsR0FBd0IsT0FBTyxDQUFDLE9BQWhDO0FBQ0gsR0FIUyxFQUdQLENBSE8sQ0FBVjtBQUtBLEVBQUEsVUFBVSxDQUFDLFlBQU07QUFDYixJQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsY0FBZCxDQUE2QixZQUE3QjtBQUNBLEtBQUMsQ0FBQyxPQUFPLENBQUMsUUFBVixJQUFzQixPQUFPLENBQUMsUUFBUixFQUF0QjtBQUNILEdBSFMsRUFHUCxPQUFPLENBQUMsUUFBUixHQUFtQixFQUhaLENBQVY7QUFJSCxDQXRCTTs7OztBQXdCQSxJQUFNLE9BQU8sR0FBRyxTQUFWLE9BQVUsQ0FBQyxPQUFELEVBQTRCO0FBQUEsTUFBbEIsUUFBa0IsdUVBQVAsRUFBTzs7QUFDL0MsTUFBSSxPQUFPLENBQUMsS0FBUixDQUFjLE9BQWQsS0FBMEIsTUFBOUIsRUFBc0M7QUFDbEM7QUFDSDs7QUFFRCxNQUFNLE9BQU8sR0FBRztBQUNaLElBQUEsUUFBUSxFQUFFLEdBREU7QUFFWixJQUFBLE9BQU8sRUFBRSxJQUZHO0FBR1osSUFBQSxPQUFPLEVBQUUsQ0FIRztBQUlaLElBQUEsUUFBUSxFQUFFO0FBSkUsR0FBaEI7QUFPQSxFQUFBLE1BQU0sQ0FBQyxNQUFQLENBQWMsT0FBZCxFQUF1QixRQUF2QjtBQUVBLEVBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxPQUFkLEdBQXdCLENBQXhCO0FBQ0EsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLE9BQWQsR0FBd0IsT0FBTyxDQUFDLE9BQVIsSUFBbUIsT0FBM0M7QUFFQSxFQUFBLFVBQVUsQ0FBQyxZQUFNO0FBQ2IsSUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLFVBQWQsYUFBOEIsT0FBTyxDQUFDLFFBQXRDO0FBQ0EsSUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLE9BQWQsR0FBd0IsT0FBTyxDQUFDLE9BQWhDO0FBQ0gsR0FIUyxFQUdQLENBSE8sQ0FBVjtBQUtBLEVBQUEsVUFBVSxDQUFDLFlBQU07QUFDYixJQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsT0FBZCxHQUF3QixNQUF4QjtBQUNBLElBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxjQUFkLENBQTZCLFlBQTdCO0FBQ0EsS0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFWLElBQXNCLE9BQU8sQ0FBQyxRQUFSLEVBQXRCO0FBQ0gsR0FKUyxFQUlQLE9BQU8sQ0FBQyxRQUFSLEdBQW1CLEVBSlosQ0FBVjtBQUtILENBM0JNOzs7O0FBNkJBLElBQU0sVUFBVSxHQUFHLFNBQWIsVUFBYSxDQUFDLE9BQUQsRUFBVSxPQUFWLEVBQXNCO0FBQzVDLEVBQUEsTUFBTSxDQUFDLGdCQUFQLENBQXdCLE9BQXhCLEVBQWlDLE9BQWpDLEtBQTZDLE1BQTdDLEdBQ00sTUFBTSxDQUFDLE9BQUQsRUFBVSxPQUFWLENBRFosR0FFTSxPQUFPLENBQUMsT0FBRCxFQUFVLE9BQVYsQ0FGYjtBQUdILENBSk07Ozs7QUFNQSxJQUFNLE1BQU0sR0FBRyxTQUFULE1BQVMsQ0FBQSxPQUFPLEVBQUk7QUFDN0IsTUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFSLEdBQXlCLE1BQTlCLEVBQXNDO0FBQ2xDLFdBQU87QUFBRSxNQUFBLEdBQUcsRUFBRSxDQUFQO0FBQVUsTUFBQSxJQUFJLEVBQUU7QUFBaEIsS0FBUDtBQUNILEdBSDRCLENBSzdCOzs7QUFDQSxNQUFNLElBQUksR0FBRyxPQUFPLENBQUMscUJBQVIsRUFBYjtBQUNBLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxhQUFSLENBQXNCLFdBQWxDO0FBQ0EsU0FBTztBQUNILElBQUEsR0FBRyxFQUFFLElBQUksQ0FBQyxHQUFMLEdBQVcsR0FBRyxDQUFDLFdBRGpCO0FBRUgsSUFBQSxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUwsR0FBWSxHQUFHLENBQUM7QUFGbkIsR0FBUDtBQUlILENBWk07Ozs7QUFjQSxJQUFNLE9BQU8sR0FBRyxTQUFWLE9BQVUsQ0FBQSxPQUFPLEVBQUk7QUFDOUIsTUFBSSxDQUFDLE9BQUwsRUFBYztBQUNWLFdBQU8sS0FBUDtBQUNIOztBQUVELFNBQU8sQ0FBQyxFQUNKLE9BQU8sQ0FBQyxXQUFSLElBQ0EsT0FBTyxDQUFDLFlBRFIsSUFFQSxPQUFPLENBQUMsY0FBUixHQUF5QixNQUhyQixDQUFSO0FBS0gsQ0FWTTs7OztBQVlBLElBQU0sV0FBVyxHQUFHLFNBQWQsV0FBYyxDQUFBLENBQUMsRUFBSTtBQUM1QjtBQUNBLE1BQU0sUUFBUSxHQUFHLEVBQWpCLENBRjRCLENBSTVCOztBQUNBLE1BQUksQ0FBQyxDQUFDLENBQUMsVUFBUCxFQUFtQjtBQUNmLFdBQU8sUUFBUDtBQUNILEdBUDJCLENBUzVCOzs7QUFDQSxNQUFJLE9BQU8sR0FBRyxDQUFDLENBQUMsVUFBRixDQUFhLFVBQTNCLENBVjRCLENBWTVCOztBQUNBLFNBQU8sT0FBUCxFQUFnQjtBQUNaLFFBQUksT0FBTyxDQUFDLFFBQVIsS0FBcUIsQ0FBckIsSUFBMEIsT0FBTyxLQUFLLENBQTFDLEVBQTZDO0FBQ3pDLE1BQUEsUUFBUSxDQUFDLElBQVQsQ0FBYyxPQUFkO0FBQ0g7O0FBRUQsSUFBQSxPQUFPLEdBQUcsT0FBTyxDQUFDLFdBQWxCO0FBQ0g7O0FBRUQsU0FBTyxRQUFQO0FBQ0gsQ0F0Qk0sQyxDQXdCUDs7Ozs7QUFDTyxJQUFNLFNBQVMsR0FBRyxTQUFaLFNBQVksQ0FBQSxDQUFDLEVBQUk7QUFDMUIsU0FBTyxRQUFPLFdBQVAsMERBQU8sV0FBUCxPQUF1QixRQUF2QixHQUNELENBQUMsWUFBWSxXQURaLENBQ3dCO0FBRHhCLElBRUQsQ0FBQyxJQUNHLHlCQUFPLENBQVAsTUFBYSxRQURqQixJQUVJLENBQUMsS0FBSyxJQUZWLElBR0ksQ0FBQyxDQUFDLFFBQUYsS0FBZSxDQUhuQixJQUlJLE9BQU8sQ0FBQyxDQUFDLFFBQVQsS0FBc0IsUUFOaEM7QUFPSCxDQVJNOzs7O0FBVUEsSUFBTSxlQUFlLEdBQUksVUFBQSxZQUFZO0FBQUEsU0FBSSxVQUFBLFFBQVEsRUFBSTtBQUN4RCxRQUFJO0FBQ0EsTUFBQSxZQUFZLENBQUMsYUFBYixDQUEyQixRQUEzQjtBQUNILEtBRkQsQ0FFRSxnQkFBTTtBQUNKLGFBQU8sS0FBUDtBQUNIOztBQUNELFdBQU8sSUFBUDtBQUNILEdBUDJDO0FBQUEsQ0FBYixDQU81QixRQUFRLENBQUMsc0JBQVQsRUFQNEIsQ0FBeEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0lDL0xELG1DLEdBQ0YsK0NBQWM7QUFBQTs7QUFBQTtBQUFBO0FBQUEsV0FJTCxpQkFBTTtBQUNYLE1BQUEsUUFBUSxDQUNILGdCQURMLENBQ3NCLHVFQUR0QixFQUVLLE9BRkwsQ0FFYSxVQUFDLElBQUQsRUFBVTtBQUNmLFlBQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFuQjtBQUNBLFFBQUEsSUFBSSxDQUFDLFNBQUwsR0FBaUIsS0FBSyxDQUFDLFNBQU4sQ0FBZ0IsQ0FBaEIsRUFBbUIsS0FBSyxDQUFDLE1BQU4sR0FBZSxDQUFsQyxDQUFqQjtBQUNILE9BTEw7QUFNSDtBQVhhOztBQUNWO0FBQ0gsQzs7ZUFZVSxtQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNmZjs7OztJQUVNLGtCLEdBQ0YsOEJBQWM7QUFBQTs7QUFBQTtBQUFBO0FBQUEsV0FNUyxpQkFBTTtBQUN6QixxQkFBSSxHQUFKLENBQVEsZUFBUixDQUF3QixnQkFBeEIsQ0FBeUMsT0FBekMsRUFBa0QsVUFBQyxLQUFELEVBQVc7QUFDekQsWUFBTSxlQUFlLEdBQUcsS0FBSyxDQUFDLGFBQTlCO0FBRUEsUUFBQSxlQUFlLENBQ1YsT0FETCxDQUNhLGFBRGIsRUFFSyxnQkFGTCxDQUVzQixRQUZ0QixFQUdLLE9BSEwsQ0FHYSxVQUFDLE1BQUQsRUFBWTtBQUNqQixVQUFBLFVBQVUsQ0FBQyxZQUFNO0FBQ2IsWUFBQSxNQUFNLENBQUMsV0FBUCxDQUFtQixTQUFuQixHQUErQixNQUFNLENBQUMsT0FBUCxDQUFlLE1BQU0sQ0FBQyxhQUF0QixFQUFxQyxJQUFwRTtBQUNILFdBRlMsRUFFUCxHQUZPLENBQVY7QUFHSCxTQVBMO0FBUUgsT0FYRDtBQVlIO0FBbkJhOztBQUNWLE1BQUksQ0FBQyxDQUFDLGVBQUksR0FBSixDQUFRLGVBQWQsRUFBK0I7QUFDM0I7QUFDSDtBQUNKLEM7O2VBa0JVLGtCOzs7Ozs7Ozs7Ozs7Ozs7OztBQ3pCZjs7QUFDQTs7QUFDQTs7Ozs7Ozs7Ozs7O0lBRU0sVyxHQUNGLHVCQUFjO0FBQUE7O0FBQUE7O0FBQUE7QUFBQTtBQUFBLFdBU0wsaUJBQU07QUFDWCxVQUFJLEVBQUUsZUFBSSxHQUFKLENBQVEsSUFBUixJQUFnQixlQUFJLEdBQUosQ0FBUSxJQUExQixDQUFKLEVBQXFDO0FBQ2pDO0FBQ0g7O0FBRUQsVUFBSSxxQkFBUSxHQUFSLENBQVksWUFBWixNQUE4QixNQUFsQyxFQUEwQztBQUFBOztBQUN0Qyx3Q0FBSSxHQUFKLENBQVEsSUFBUixnRUFBYyxTQUFkLENBQXdCLEdBQXhCLENBQTRCLFFBQTVCO0FBQ0Esd0NBQUksR0FBSixDQUFRLElBQVIsZ0VBQWMsU0FBZCxDQUF3QixNQUF4QixDQUErQixRQUEvQjtBQUVBLCtDQUFJLEdBQUosQ0FBUSxXQUFSLDhFQUFxQixPQUFyQixDQUE2QixVQUFDLFFBQUQsRUFBYztBQUN2QyxVQUFBLFFBQVEsQ0FBQyxTQUFULENBQW1CLEdBQW5CLENBQXVCLE1BQXZCO0FBQ0EsVUFBQSxRQUFRLENBQUMsU0FBVCxDQUFtQixNQUFuQixDQUEwQixNQUExQjtBQUNILFNBSEQ7QUFJSDs7QUFFRCxVQUFJLHFCQUFRLEdBQVIsQ0FBWSxZQUFaLE1BQThCLE1BQWxDLEVBQTBDO0FBQUE7O0FBQ3RDLHlDQUFJLEdBQUosQ0FBUSxJQUFSLGtFQUFjLFNBQWQsQ0FBd0IsTUFBeEIsQ0FBK0IsUUFBL0I7QUFDQSx5Q0FBSSxHQUFKLENBQVEsSUFBUixrRUFBYyxTQUFkLENBQXdCLEdBQXhCLENBQTRCLFFBQTVCO0FBRUEsZ0RBQUksR0FBSixDQUFRLFdBQVIsZ0ZBQXFCLE9BQXJCLENBQTZCLFVBQUMsUUFBRCxFQUFjO0FBQ3ZDLFVBQUEsUUFBUSxDQUFDLFNBQVQsQ0FBbUIsR0FBbkIsQ0FBdUIsTUFBdkI7QUFDQSxVQUFBLFFBQVEsQ0FBQyxTQUFULENBQW1CLE1BQW5CLENBQTBCLE1BQTFCO0FBQ0gsU0FIRDtBQUtBLCtDQUFBLEtBQUksbUJBQUosTUFBQSxLQUFJO0FBQ1A7QUFDSjtBQW5DYTs7QUFBQTtBQUFBO0FBQUEsV0FxQ1MsaUJBQU07QUFBQTs7QUFDekIsdUNBQUksR0FBSixDQUFRLElBQVIsa0VBQWMsZ0JBQWQsQ0FBK0IsT0FBL0IseUNBQXdDLEtBQXhDO0FBQ0EsdUNBQUksR0FBSixDQUFRLElBQVIsa0VBQWMsZ0JBQWQsQ0FBK0IsT0FBL0IseUNBQXdDLEtBQXhDO0FBQ0g7QUF4Q2E7O0FBQUE7QUFBQTtBQUFBLFdBMENDLGVBQUMsS0FBRCxFQUFXO0FBQ3RCLE1BQUEsS0FBSyxDQUFDLGNBQU47QUFDQSxNQUFBLEtBQUssQ0FBQyxlQUFOOztBQUVBLHFCQUFJLEdBQUosQ0FBUSxJQUFSLENBQWEsU0FBYixDQUF1QixHQUF2QixDQUEyQixRQUEzQjs7QUFDQSxxQkFBSSxHQUFKLENBQVEsSUFBUixDQUFhLFNBQWIsQ0FBdUIsTUFBdkIsQ0FBOEIsUUFBOUI7O0FBRUEsMkJBQVEsR0FBUixDQUFZLFlBQVosRUFBMEIsTUFBMUIsRUFBa0M7QUFBRSxRQUFBLElBQUksRUFBRTtBQUFSLE9BQWxDOztBQUVBLHFCQUFJLEdBQUosQ0FBUSxXQUFSLENBQW9CLE9BQXBCLENBQTRCLFVBQUMsUUFBRCxFQUFjO0FBQ3RDLDRCQUFRLFFBQVIsRUFBa0I7QUFDZCxVQUFBLFFBQVEsRUFBRSxvQkFBTTtBQUNaLFlBQUEsUUFBUSxDQUFDLFNBQVQsQ0FBbUIsR0FBbkIsQ0FBdUIsTUFBdkI7QUFDQSxZQUFBLFFBQVEsQ0FBQyxTQUFULENBQW1CLE1BQW5CLENBQTBCLE1BQTFCO0FBRUEsK0JBQU8sUUFBUDtBQUNIO0FBTmEsU0FBbEI7QUFRSCxPQVREOztBQVdBLE1BQUEsVUFBVSxDQUFDLFlBQU07QUFDYiwrQ0FBQSxLQUFJLG1CQUFKLE1BQUEsS0FBSTtBQUNQLE9BRlMsRUFFUCxHQUZPLENBQVY7QUFHSDtBQWpFYTs7QUFBQTtBQUFBO0FBQUEsV0FtRUMsZUFBQyxLQUFELEVBQVc7QUFDdEIsTUFBQSxLQUFLLENBQUMsY0FBTjtBQUNBLE1BQUEsS0FBSyxDQUFDLGVBQU47O0FBRUEscUJBQUksR0FBSixDQUFRLElBQVIsQ0FBYSxTQUFiLENBQXVCLE1BQXZCLENBQThCLFFBQTlCOztBQUNBLHFCQUFJLEdBQUosQ0FBUSxJQUFSLENBQWEsU0FBYixDQUF1QixHQUF2QixDQUEyQixRQUEzQjs7QUFFQSwyQkFBUSxHQUFSLENBQVksWUFBWixFQUEwQixNQUExQixFQUFrQztBQUFFLFFBQUEsSUFBSSxFQUFFO0FBQVIsT0FBbEM7O0FBRUEscUJBQUksR0FBSixDQUFRLFdBQVIsQ0FBb0IsT0FBcEIsQ0FBNEIsVUFBQyxRQUFELEVBQWM7QUFDdEMsNEJBQVEsUUFBUixFQUFrQjtBQUNkLFVBQUEsUUFBUSxFQUFFLG9CQUFNO0FBQ1osWUFBQSxRQUFRLENBQUMsU0FBVCxDQUFtQixHQUFuQixDQUF1QixNQUF2QjtBQUNBLFlBQUEsUUFBUSxDQUFDLFNBQVQsQ0FBbUIsTUFBbkIsQ0FBMEIsTUFBMUI7QUFFQSwrQkFBTyxRQUFQO0FBQ0g7QUFOYSxTQUFsQjtBQVFILE9BVEQ7O0FBV0EsTUFBQSxVQUFVLENBQUMsWUFBTTtBQUNiLCtDQUFBLEtBQUksbUJBQUosTUFBQSxLQUFJO0FBQ1AsT0FGUyxFQUVQLEdBRk8sQ0FBVjtBQUdIO0FBMUZhOztBQUFBO0FBQUE7QUFBQSxXQTRGSyxpQkFBTTtBQUNyQixVQUNJLENBQUMsZUFBSSxJQUFKLENBQVMsU0FBVCxDQUFtQixRQUFuQixDQUE0QixhQUE1QixDQUFELElBQ0EsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxhQUFULENBQXVCLHVDQUF2QixDQUZOLEVBR0U7QUFBQTs7QUFDRSxpQ0FBQSxPQUFPLENBQUMsS0FBUixDQUFjLFFBQWQsQ0FBdUIsUUFBdkIsZ0ZBQWlDLE9BQWpDLENBQXlDLFVBQUMsUUFBRCxFQUFjO0FBQ25ELFVBQUEsUUFBUSxDQUFDLE9BQVQ7QUFDSCxTQUZEO0FBR0g7O0FBRUQsTUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLFFBQWQsQ0FBdUIsS0FBdkI7QUFDSDtBQXZHYTs7QUFDVixNQUFJLGVBQUksSUFBSixDQUFTLFNBQVQsQ0FBbUIsUUFBbkIsQ0FBNEIsZUFBNUIsQ0FBSixFQUFrRDtBQUM5QztBQUNBO0FBQ0gsR0FIRCxNQUdPO0FBQ0gseUJBQVEsTUFBUixDQUFlLFlBQWYsRUFBNkI7QUFBRSxNQUFBLElBQUksRUFBRTtBQUFSLEtBQTdCO0FBQ0g7QUFDSixDOztlQW1HVSxXOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL0dmOztBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7SUFFTSxtQixHQU1GLCtCQUFjO0FBQUE7QUFBQTs7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsV0FVTCxpQkFBTTtBQUFBOztBQUNYLDZDQUFBLEtBQUksc0NBQWEsZUFBSSxHQUFKLENBQVEsbUJBQXJCLDBEQUFhLHNCQUE2QixhQUE3QixDQUEyQyxVQUEzQyxDQUFiLENBQUo7QUFDQSw2Q0FBQSxLQUFJLDBDQUFnQixlQUFJLEdBQUosQ0FBUSxtQkFBeEIsMkRBQWdCLHVCQUE2QixhQUE3QixDQUEyQyxhQUEzQyxDQUFoQixDQUFKO0FBQ0EsNkNBQUEsS0FBSSx1Q0FBYSxlQUFJLEdBQUosQ0FBUSxtQkFBckIsMkRBQWEsdUJBQTZCLGFBQTdCLENBQTJDLFFBQTNDLENBQWIsQ0FBSjtBQUNBLDZDQUFBLEtBQUksMENBQWdCLGVBQUksR0FBSixDQUFRLG1CQUF4QiwyREFBZ0IsdUJBQTZCLGFBQTdCLENBQTJDLFFBQTNDLENBQWhCLENBQUo7QUFDSDtBQWZhOztBQUFBO0FBQUE7QUFBQSxXQWlCUyxpQkFBTTtBQUFBOztBQUN6Qix1RUFBQSxLQUFJLFlBQUosa0ZBQWdCLGdCQUFoQixDQUFpQyxPQUFqQyx5Q0FBMEMsS0FBMUM7QUFDQSx1RUFBQSxLQUFJLGVBQUosa0ZBQW1CLGdCQUFuQixDQUFvQyxPQUFwQyx5Q0FBNkMsS0FBN0M7QUFDSDtBQXBCYTs7QUFBQTtBQUFBO0FBQUEsV0FzQkssZUFBQyxLQUFELEVBQVc7QUFDMUIsTUFBQSxLQUFLLENBQUMsY0FBTjtBQUNBLE1BQUEsS0FBSyxDQUFDLGVBQU47QUFFQSw2Q0FBQSxLQUFJLFlBQUosQ0FBZSxTQUFmLENBQXlCLEdBQXpCLENBQTZCLFNBQTdCO0FBQ0EsNkNBQUEsS0FBSSxlQUFKLENBQWtCLFNBQWxCLENBQTRCLE1BQTVCLENBQW1DLFNBQW5DO0FBRUEsaUVBQVEsS0FBUixpQkFBMkI7QUFDdkIsUUFBQSxRQUFRLEVBQUUsb0JBQU07QUFDWixvRUFBTyxLQUFQO0FBQ0g7QUFIc0IsT0FBM0I7QUFLSDtBQWxDYTs7QUFBQTtBQUFBO0FBQUEsV0FvQ1EsZUFBQyxLQUFELEVBQVc7QUFDN0IsTUFBQSxLQUFLLENBQUMsY0FBTjtBQUNBLE1BQUEsS0FBSyxDQUFDLGVBQU47QUFFQSw2Q0FBQSxLQUFJLGVBQUosQ0FBa0IsU0FBbEIsQ0FBNEIsR0FBNUIsQ0FBZ0MsU0FBaEM7QUFDQSw2Q0FBQSxLQUFJLFlBQUosQ0FBZSxTQUFmLENBQXlCLE1BQXpCLENBQWdDLFNBQWhDO0FBRUEsaUVBQVEsS0FBUixjQUF3QjtBQUNwQixRQUFBLFFBQVEsRUFBRSxvQkFBTTtBQUNaLG9FQUFPLEtBQVA7QUFDSDtBQUhtQixPQUF4QjtBQUtIO0FBaERhOztBQUNWO0FBQ0EsZ0NBQUksZUFBSSxHQUFKLENBQVEsbUJBQVosbURBQUksdUJBQTZCLFNBQTdCLENBQXVDLFFBQXZDLENBQWdELHVCQUFoRCxDQUFKLEVBQThFO0FBQzFFO0FBQ0g7O0FBRUQ7QUFDQTtBQUNILEM7O2VBMkNVLG1COzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1RGY7O0FBQ0E7Ozs7Ozs7Ozs7OztJQUVNLGtCLEdBSUYsOEJBQWM7QUFBQTs7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQSxrREFPTixZQUFNO0FBQ1YsUUFBTSxjQUFjLEdBQUcsUUFBUSxDQUFDLGdCQUFULENBQ25CLG9DQURtQixDQUF2Qjs7QUFJQSxRQUFJLENBQUMsQ0FBQyxjQUFOLEVBQXNCO0FBQ2xCLE1BQUEsY0FBYyxDQUFDLE9BQWYsQ0FBdUIsVUFBQSxhQUFhLEVBQUk7QUFDcEMsWUFBTSxTQUFTLEdBQUcsYUFBYSxDQUFDLFlBQWQsQ0FBMkIsTUFBM0IsQ0FBbEI7O0FBRUEsWUFBSSxFQUFFLFNBQVMsS0FBSyxNQUFkLElBQXdCLFNBQVMsS0FBSyxRQUF4QyxDQUFKLEVBQXVEO0FBQUE7O0FBQ25EO0FBQ0EsY0FDSSwyQkFBQyxhQUFhLENBQUMsc0JBQWYsa0RBQUMsc0JBQXNDLFNBQXRDLENBQWdELFFBQWhELENBQ0csT0FESCxDQUFELENBREosRUFJRTtBQUNFLFlBQUEsYUFBYSxDQUFDLGtCQUFkLENBQ0ksYUFESixFQUVJLGtEQUZKO0FBSUgsV0FYa0QsQ0FhbkQ7OztBQUNBLGNBQ0ksMkJBQUMsYUFBYSxDQUFDLGtCQUFmLGtEQUFDLHNCQUFrQyxTQUFsQyxDQUE0QyxRQUE1QyxDQUNHLE1BREgsQ0FBRCxDQURKLEVBSUU7QUFDRSxZQUFBLGFBQWEsQ0FBQyxrQkFBZCxDQUNJLFVBREosRUFFSSxpREFGSjtBQUlIO0FBQ0o7QUFDSixPQTVCRCxFQURrQixDQStCbEI7O0FBQ0EsTUFBQSxRQUFRLENBQ0gsZ0JBREwsQ0FDc0IsNENBRHRCLEVBRUssT0FGTCxDQUVhLFVBQUEsYUFBYSxFQUFJO0FBQ3RCLFlBQU0sR0FBRyxHQUFHLFVBQVUsQ0FBQyxhQUFhLENBQUMsWUFBZCxDQUEyQixLQUEzQixDQUFELENBQXRCO0FBQ0EsWUFBTSxZQUFZLEdBQUcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxLQUFmLENBQS9COztBQUVBLFlBQUksR0FBRyxJQUFJLEdBQUcsR0FBRyxDQUFiLElBQWtCLFlBQVksR0FBRyxHQUFyQyxFQUEwQztBQUN0QyxVQUFBLGFBQWEsQ0FBQyxLQUFkLEdBQXNCLEdBQXRCO0FBQ0g7QUFDSixPQVRMOztBQVdBLGlEQUFJLEtBQUosc0JBQTRCO0FBQ3hCO0FBQ0EsK0NBQUEsS0FBSSxnQkFBZ0IsSUFBSSxLQUFKLENBQVUsUUFBVixFQUFvQjtBQUFFLFVBQUEsT0FBTyxFQUFFO0FBQVgsU0FBcEIsQ0FBaEIsQ0FBSjtBQUNIO0FBQ0o7QUFDSixHQTVEYTs7QUFBQTtBQUFBO0FBQUEsV0E4RFMsaUJBQU07QUFDekIsVUFBTSxjQUFjLEdBQUcsUUFBUSxDQUFDLGdCQUFULENBQ25CLG9DQURtQixDQUF2QixDQUR5QixDQUt6Qjs7QUFDQSxVQUFJLENBQUMsQ0FBQyxjQUFOLEVBQXNCO0FBQ2xCLFlBQ0ksZUFBSSxJQUFKLENBQVMsU0FBVCxDQUFtQixRQUFuQixDQUE0QixnQkFBNUIsS0FDQSxtQkFBUSxZQUFSLEtBQXlCLElBRHpCLElBRUEsQ0FBQyxLQUFLLENBQUMsSUFBTixDQUFXLGVBQUksR0FBSixDQUFRLFlBQW5CLEVBQWlDLElBQWpDLENBQ0c7QUFBQSxjQUFHLFNBQUgsUUFBRyxTQUFIO0FBQUEsaUJBQ0ksU0FBUyxDQUFDLFFBQVYsQ0FBbUIsY0FBbkIsS0FDQSxTQUFTLENBQUMsUUFBVixDQUFtQixZQUFuQixDQUZKO0FBQUEsU0FESCxDQUhMLEVBUUU7QUFDRSxVQUFBLGNBQWMsQ0FBQyxPQUFmLENBQXVCLFVBQUEsYUFBYSxFQUFJO0FBQ3BDLFlBQUEsYUFBYSxDQUFDLGdCQUFkLENBQ0ksT0FESix5Q0FFSSxLQUZKO0FBSUEsWUFBQSxhQUFhLENBQUMsZ0JBQWQsQ0FDSSxRQURKLHlDQUVJLEtBRko7QUFJSCxXQVREO0FBVUg7QUFDSjs7QUFFRCxnQ0FDSSxlQUFJLElBRFIsRUFFSSwyR0FGSixFQUdJLE9BSEoseUNBSUksS0FKSjtBQU1IO0FBakdhOztBQUFBO0FBQUE7QUFBQSxXQW1HVSxlQUFBLEtBQUssRUFBSTtBQUM3QixVQUFNLG9CQUFvQixHQUFHLEtBQUssQ0FBQyxNQUFuQztBQUVBLFVBQU0sU0FBUyxHQUFHLG9CQUFvQixDQUFDLFlBQXJCLENBQWtDLE1BQWxDLENBQWxCO0FBQ0EsVUFBTSxjQUFjLEdBQUcsUUFBUSxDQUFDLGdCQUFULENBQ25CLG9DQURtQixDQUF2Qjs7QUFJQSxVQUFJLEVBQUUsU0FBUyxLQUFLLE1BQWQsSUFBd0IsU0FBUyxLQUFLLFFBQXhDLENBQUosRUFBdUQ7QUFDbkQsUUFBQSxjQUFjLENBQUMsT0FBZixDQUF1QixVQUFBLGFBQWEsRUFBSTtBQUNwQyxVQUFBLGFBQWEsQ0FBQyxLQUFkLEdBQXNCLG9CQUFvQixDQUFDLEtBQTNDO0FBQ0gsU0FGRDtBQUdIO0FBQ0o7QUFoSGE7O0FBQUE7QUFBQTtBQUFBLFdBa0hRLGVBQUEsS0FBSyxFQUFJO0FBQUE7O0FBQzNCLE1BQUEsS0FBSyxDQUFDLGNBQU47QUFDQSxNQUFBLEtBQUssQ0FBQyxlQUFOO0FBRUEsVUFBTSxXQUFXLEdBQUcsS0FBSyxDQUFDLGNBQTFCO0FBQ0EsVUFBTSxhQUFhLEdBQUcsV0FBVyxDQUM1QixPQURpQixDQUNULFdBRFMsRUFFakIsYUFGaUIsQ0FFSCxNQUZHLENBQXRCO0FBSUEsVUFBSSxZQUFZLEdBQUcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxLQUFmLENBQTdCO0FBQ0EsVUFBSSxHQUFHLEdBQUcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxZQUFkLENBQTJCLEtBQTNCLENBQUQsQ0FBcEI7QUFDQSxVQUFJLEdBQUcsR0FBRyxVQUFVLENBQUMsYUFBYSxDQUFDLFlBQWQsQ0FBMkIsS0FBM0IsQ0FBRCxDQUFwQjtBQUNBLFVBQUksSUFBSSxHQUFHLGFBQWEsQ0FBQyxZQUFkLENBQTJCLE1BQTNCLENBQVgsQ0FaMkIsQ0FjM0I7O0FBQ0EsVUFDSSxDQUFDLFlBQUQsSUFDQSxZQUFZLEtBQUssRUFEakIsSUFFQSxNQUFNLENBQUMsS0FBUCxDQUFhLFlBQWIsQ0FISixFQUlFO0FBQ0UsUUFBQSxZQUFZLEdBQUcsQ0FBZjtBQUNIOztBQUVELFVBQUksR0FBRyxLQUFLLEVBQVIsSUFBYyxNQUFNLENBQUMsS0FBUCxDQUFhLEdBQWIsQ0FBbEIsRUFBcUM7QUFDakMsUUFBQSxHQUFHLEdBQUcsRUFBTjtBQUNIOztBQUVELFVBQUksR0FBRyxLQUFLLEVBQVIsSUFBYyxNQUFNLENBQUMsS0FBUCxDQUFhLEdBQWIsQ0FBbEIsRUFBcUM7QUFDakMsUUFBQSxHQUFHLEdBQUcsQ0FBTjtBQUNIOztBQUVELFVBQ0ksSUFBSSxLQUFLLFNBQVQsSUFDQSxJQUFJLEtBQUssRUFEVCxJQUVBLElBQUksS0FBSyxLQUZULElBR0EsTUFBTSxDQUFDLEtBQVAsQ0FBYSxVQUFVLENBQUMsSUFBRCxDQUF2QixDQUpKLEVBS0U7QUFDRSxRQUFBLElBQUksR0FBRyxDQUFQO0FBQ0gsT0F0QzBCLENBd0MzQjs7O0FBQ0EsVUFBSSxXQUFXLENBQUMsU0FBWixDQUFzQixRQUF0QixDQUErQixNQUEvQixDQUFKLEVBQTRDO0FBQ3hDLFlBQUksR0FBRyxLQUFLLFlBQVksS0FBSyxHQUFqQixJQUF3QixZQUFZLEdBQUcsR0FBNUMsQ0FBUCxFQUF5RDtBQUNyRCxVQUFBLGFBQWEsQ0FBQyxLQUFkLEdBQXNCLEdBQXRCO0FBQ0gsU0FGRCxNQUVPO0FBQ0gsVUFBQSxhQUFhLENBQUMsS0FBZCxHQUFzQixZQUFZLEdBQUcsVUFBVSxDQUFDLElBQUQsQ0FBL0M7QUFDSCxTQUx1QyxDQU94Qzs7QUFDSCxPQVJELE1BUU87QUFDSCxZQUFJLEdBQUcsS0FBSyxZQUFZLEtBQUssR0FBakIsSUFBd0IsWUFBWSxHQUFHLEdBQTVDLENBQVAsRUFBeUQ7QUFDckQsVUFBQSxhQUFhLENBQUMsS0FBZCxHQUFzQixHQUF0QjtBQUNILFNBRkQsTUFFTyxJQUFJLFlBQVksR0FBRyxDQUFuQixFQUFzQjtBQUN6QixVQUFBLGFBQWEsQ0FBQyxLQUFkLEdBQXNCLFlBQVksR0FBRyxVQUFVLENBQUMsSUFBRCxDQUEvQztBQUNIO0FBQ0o7O0FBRUQsVUFDSSxDQUFDLDBCQUFDLFdBQVcsQ0FBQyxPQUFaLENBQW9CLE1BQXBCLENBQUQsaURBQUMscUJBQTZCLGFBQTdCLENBQTJDLHFCQUEzQyxDQUFELENBREwsRUFFRTtBQUNFLFFBQUEsV0FBVyxDQUNOLE9BREwsQ0FDYSxNQURiLEVBRUssYUFGTCxDQUVtQixxQkFGbkIsRUFFMEMsT0FGMUMsQ0FFa0QsUUFGbEQsR0FHSSxhQUFhLENBQUMsS0FIbEI7QUFJSDs7QUFFRCxVQUNJLENBQUMsMkJBQUMsV0FBVyxDQUFDLE9BQVosQ0FBb0IsT0FBcEIsQ0FBRCxrREFBQyxzQkFBOEIsYUFBOUIsQ0FBNEMscUJBQTVDLENBQUQsQ0FETCxFQUVFO0FBQ0UsUUFBQSxXQUFXLENBQ04sT0FETCxDQUNhLE9BRGIsRUFFSyxhQUZMLENBRW1CLHFCQUZuQixFQUUwQyxPQUYxQyxDQUVrRCxRQUZsRCxHQUdJLGFBQWEsQ0FBQyxLQUhsQjtBQUlILE9BekUwQixDQTJFM0I7OztBQUNBLE1BQUEsYUFBYSxDQUFDLGFBQWQsd0NBQTRCLEtBQTVCO0FBQ0g7QUEvTGE7O0FBQ1Ysa0VBQXlCLElBQXpCO0FBRUEsT0FBSyxLQUFMO0FBQ0E7QUFDSCxDOztlQTZMVSxrQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6TWY7O0FBQ0E7Ozs7OztJQUVNLG9CLEdBQ0YsZ0NBQWM7QUFBQTs7QUFBQTs7QUFBQTtBQUFBO0FBQUEsV0FNUyxpQkFBTTtBQUN6QixxQkFBSSxHQUFKLENBQVEseUJBQVIsQ0FBa0MsZ0JBQWxDLENBQW1ELE9BQW5ELHlDQUE0RCxLQUE1RDtBQUNIO0FBUmE7O0FBQUE7QUFBQTtBQUFBLFdBVWUsZUFBQyxLQUFELEVBQVc7QUFDcEMsTUFBQSxLQUFLLENBQUMsY0FBTjtBQUNBLE1BQUEsS0FBSyxDQUFDLGVBQU47O0FBRUEsVUFBSSxDQUFDLENBQUMsZUFBSSxHQUFKLENBQVEsV0FBUixDQUFvQixhQUFwQixDQUFrQyxrQkFBbEMsQ0FBTixFQUE2RDtBQUN6RCx1QkFBSSxHQUFKLENBQVEsV0FBUixDQUFvQixhQUFwQixDQUFrQyxrQkFBbEMsRUFBc0QsU0FBdEQsQ0FBZ0UsTUFBaEUsQ0FBdUUsUUFBdkU7O0FBQ0EsdUJBQUksR0FBSixDQUFRLFdBQVIsQ0FBb0IsYUFBcEIsQ0FBa0Msa0JBQWxDLEVBQXNELEtBQXRELENBQTRELE9BQTVELEdBQXNFLE1BQXRFO0FBQ0g7O0FBRUQsVUFBSSxlQUFJLEdBQUosQ0FBUSxXQUFSLENBQW9CLGFBQXBCLENBQWtDLDZCQUFsQyxDQUFKLEVBQXNFO0FBQ2xFLHVCQUFJLEdBQUosQ0FBUSxXQUFSLENBQW9CLGFBQXBCLENBQWtDLDZCQUFsQyxFQUFpRSxTQUFqRSxDQUEyRSxNQUEzRSxDQUFrRixRQUFsRjs7QUFDQSx1QkFBSSxHQUFKLENBQVEsV0FBUixDQUFvQixhQUFwQixDQUFrQyw2QkFBbEMsRUFBaUUsS0FBakUsQ0FBdUUsT0FBdkUsR0FBaUYsTUFBakY7QUFDSDs7QUFFRCxxQkFBSSxHQUFKLENBQVEsV0FBUixDQUFvQixhQUFwQixDQUFrQyxjQUFsQyxFQUFrRCxTQUFsRCxDQUE0RCxHQUE1RCxDQUFnRSxRQUFoRTs7QUFDQSxxQkFBSSxHQUFKLENBQVEsV0FBUixDQUFvQixhQUFwQixDQUFrQyxjQUFsQyxFQUFrRCxLQUFsRCxDQUF3RCxPQUF4RCxHQUFrRSxPQUFsRTtBQUVBLFVBQU0sb0JBQW9CLEdBQUcsbUJBQU8sUUFBUSxDQUFDLGFBQVQsQ0FBdUIsS0FBSyxDQUFDLGFBQU4sQ0FBb0IsSUFBM0MsQ0FBUCxFQUF5RCxHQUF0Rjs7QUFFQSxxQkFBSSxJQUFKLENBQVMsUUFBVCxDQUFrQjtBQUNkLFFBQUEsR0FBRyxFQUFFLG9CQUFvQixHQUFHLEdBRGQ7QUFFZCxRQUFBLFFBQVEsRUFBRTtBQUZJLE9BQWxCO0FBSUg7QUFqQ2E7O0FBQ1YsTUFBSSxDQUFDLENBQUMsZUFBSSxHQUFKLENBQVEseUJBQWQsRUFBeUM7QUFDckM7QUFDSDtBQUNKLEM7O2VBZ0NVLG9COzs7Ozs7Ozs7Ozs7QUN4Q2Y7O0FBQ0E7O0FBQ0E7O0FBQ0E7O0FBQ0E7O0FBQ0E7O0lBRU0saUI7Ozs7a0RBQ00sWUFBTTtBQUNWLElBQUEsS0FBSSxDQUFDLGVBQUwsR0FBdUIsSUFBSSwyQkFBSixFQUF2QjtBQUNBLElBQUEsS0FBSSxDQUFDLFFBQUwsR0FBZ0IsSUFBSSx1QkFBSixFQUFoQjtBQUNBLElBQUEsS0FBSSxDQUFDLGdCQUFMLEdBQXdCLElBQUksK0JBQUosRUFBeEI7QUFDQSxJQUFBLEtBQUksQ0FBQyxlQUFMLEdBQXVCLElBQUksOEJBQUosRUFBdkI7QUFDQSxJQUFBLEtBQUksQ0FBQyxZQUFMLEdBQW9CLElBQUksZ0NBQUosRUFBcEI7QUFDQSxJQUFBLEtBQUksQ0FBQyxPQUFMLEdBQWUsSUFBSSw0Q0FBSixFQUFmO0FBRUE7QUFDUjtBQUNBO0FBQ0E7O0FBQ1EsSUFBQSxNQUFNLENBQUMsTUFBRCxDQUFOLENBQWUsRUFBZixDQUFrQixxQkFBbEIsRUFBeUMsWUFBTTtBQUMzQyxNQUFBLEtBQUksQ0FBQyxlQUFMLENBQXFCLEtBQXJCO0FBQ0gsS0FGRDtBQUlBLElBQUEsTUFBTSxDQUFFLFFBQUYsQ0FBTixDQUFtQixFQUFuQixDQUFzQix1QkFBdEIsRUFBK0MsWUFBTTtBQUNqRCxNQUFBLEtBQUksQ0FBQyxlQUFMLENBQXFCLEtBQXJCO0FBQ0gsS0FGRDtBQUdILEc7OztBQUdMLE1BQU0sQ0FBQyx3QkFBUCxHQUFrQyxJQUFJLGlCQUFKLEVBQWxDO0FBQ0Esd0JBQXdCLENBQUMsS0FBekI7OztBQy9CQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNUQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDUEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDVEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNWQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDWEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNoQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNQQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNyQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDakNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzlFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwiZmlsZSI6ImdlbmVyYXRlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24oKXtmdW5jdGlvbiByKGUsbix0KXtmdW5jdGlvbiBvKGksZil7aWYoIW5baV0pe2lmKCFlW2ldKXt2YXIgYz1cImZ1bmN0aW9uXCI9PXR5cGVvZiByZXF1aXJlJiZyZXF1aXJlO2lmKCFmJiZjKXJldHVybiBjKGksITApO2lmKHUpcmV0dXJuIHUoaSwhMCk7dmFyIGE9bmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitpK1wiJ1wiKTt0aHJvdyBhLmNvZGU9XCJNT0RVTEVfTk9UX0ZPVU5EXCIsYX12YXIgcD1uW2ldPXtleHBvcnRzOnt9fTtlW2ldWzBdLmNhbGwocC5leHBvcnRzLGZ1bmN0aW9uKHIpe3ZhciBuPWVbaV1bMV1bcl07cmV0dXJuIG8obnx8cil9LHAscC5leHBvcnRzLHIsZSxuLHQpfXJldHVybiBuW2ldLmV4cG9ydHN9Zm9yKHZhciB1PVwiZnVuY3Rpb25cIj09dHlwZW9mIHJlcXVpcmUmJnJlcXVpcmUsaT0wO2k8dC5sZW5ndGg7aSsrKW8odFtpXSk7cmV0dXJuIG99cmV0dXJuIHJ9KSgpIiwiZXhwb3J0IGNvbnN0IG9wdGlvbnMgPSBvY2VhbndwTG9jYWxpemU7XHJcblxyXG5leHBvcnQgY29uc3QgRE9NID0ge1xyXG4gICAgaHRtbDogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcImh0bWxcIiksXHJcbiAgICBib2R5OiBkb2N1bWVudC5ib2R5LFxyXG4gICAgV1BBZG1pbmJhcjogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiN3cGFkbWluYmFyXCIpLFxyXG4gICAgd3JhcDogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiN3cmFwXCIpLFxyXG4gICAgbWFpbjogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNtYWluXCIpLFxyXG4gICAgc2VsZWN0VGFnczogZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChvcHRpb25zLmN1c3RvbVNlbGVjdHMpLFxyXG4gICAgZmxvYXRpbmdCYXI6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIub3dwLWZsb2F0aW5nLWJhclwiKSxcclxuICAgIGhlYWRlcjoge1xyXG4gICAgICAgIHNpdGU6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjc2l0ZS1oZWFkZXJcIiksXHJcbiAgICAgICAgdmVydGljYWw6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjc2l0ZS1oZWFkZXIudmVydGljYWwtaGVhZGVyICNzaXRlLWhlYWRlci1pbm5lclwiKSxcclxuICAgICAgICBmdWxsU2NyZWVuOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI3NpdGUtaGVhZGVyLmZ1bGxfc2NyZWVuLWhlYWRlclwiKSxcclxuICAgICAgICB0b3BiYXI6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjdG9wLWJhclwiKSxcclxuICAgICAgICB0b3BiYXJXcmFwcGVyOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI3RvcC1iYXItd3JhcFwiKSxcclxuICAgICAgICB0b3BMZWZ0U2lkZTogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNzaXRlLWhlYWRlci50b3AtaGVhZGVyIC5oZWFkZXItdG9wIC5sZWZ0XCIpLFxyXG4gICAgICAgIHRvcFJpZ2h0U2lkZTogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNzaXRlLWhlYWRlci50b3AtaGVhZGVyIC5oZWFkZXItdG9wIC5yaWdodFwiKSxcclxuICAgIH0sXHJcbiAgICBtZW51OiB7XHJcbiAgICAgICAgbmF2OiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI3NpdGUtaGVhZGVyLmhlYWRlci1yZXBsYWNlICNzaXRlLW5hdmlnYXRpb25cIiksXHJcbiAgICAgICAgbWFpbjogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5tYWluLW1lbnVcIiksXHJcbiAgICAgICAgZnVsbFNjcmVlbjoge1xyXG4gICAgICAgICAgICBtZW51OiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI3NpdGUtaGVhZGVyLmZ1bGxfc2NyZWVuLWhlYWRlciAjZnVsbC1zY3JlZW4tbWVudVwiKSxcclxuICAgICAgICAgICAgdG9nZ2xlTWVudUJ0bjogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNzaXRlLWhlYWRlci5mdWxsX3NjcmVlbi1oZWFkZXIgLm1lbnUtYmFyXCIpLFxyXG4gICAgICAgICAgICBsb2dvOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI3NpdGUtbG9nby5oYXMtZnVsbC1zY3JlZW4tbG9nb1wiKSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIG1lZ2E6IHtcclxuICAgICAgICAgICAgbWVudUl0ZW1zOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiI3NpdGUtbmF2aWdhdGlvbiAubWVnYW1lbnUtbGkuZnVsbC1tZWdhXCIpLFxyXG4gICAgICAgICAgICB0b3BiYXJNZW51SXRlbXM6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCIjdG9wLWJhci1uYXYgLm1lZ2FtZW51LWxpLmZ1bGwtbWVnYVwiKSxcclxuICAgICAgICAgICAgbWVudUNvbnRlbnRzOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLm5hdmlnYXRpb24gLm1lZ2FtZW51LWxpLmF1dG8tbWVnYSAubWVnYW1lbnVcIiksXHJcbiAgICAgICAgfSxcclxuICAgICAgICB2ZXJ0aWNhbDoge1xyXG4gICAgICAgICAgICB0b2dnbGVNZW51QnRuOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiYS52ZXJ0aWNhbC10b2dnbGVcIiksXHJcbiAgICAgICAgfSxcclxuICAgIH0sXHJcbiAgICBtb2JpbGVNZW51OiB7XHJcbiAgICAgICAgbmF2OiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI21vYmlsZS1kcm9wZG93biA+IG5hdlwiKSxcclxuICAgICAgICBuYXZXcmFwcGVyOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI21vYmlsZS1kcm9wZG93blwiKSxcclxuICAgICAgICB0b2dnbGVNZW51QnRuOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLm1vYmlsZS1tZW51XCIpLFxyXG4gICAgICAgIGhhbWJ1cmdlckJ0bjogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5tb2JpbGUtbWVudSA+IC5oYW1idXJnZXJcIiksXHJcbiAgICAgICAgbWVudUl0ZW1zSGFzQ2hpbGRyZW46IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCIjbW9iaWxlLWRyb3Bkb3duIC5tZW51LWl0ZW0taGFzLWNoaWxkcmVuXCIpLFxyXG4gICAgICAgIGZ1bGxTY3JlZW46IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjbW9iaWxlLWZ1bGxzY3JlZW5cIiksXHJcbiAgICB9LFxyXG4gICAgc2VhcmNoOiB7XHJcbiAgICAgICAgZm9ybXM6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCJmb3JtLmhlYWRlci1zZWFyY2hmb3JtXCIpLFxyXG4gICAgICAgIGRyb3BEb3duOiB7XHJcbiAgICAgICAgICAgIHRvZ2dsZVNlYXJjaEJ0bjogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcImEuc2VhcmNoLWRyb3Bkb3duLXRvZ2dsZVwiKSxcclxuICAgICAgICAgICAgZm9ybTogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNzZWFyY2hmb3JtLWRyb3Bkb3duXCIpLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgaGVhZGVyUmVwbGFjZToge1xyXG4gICAgICAgICAgICB0b2dnbGVTZWFyY2hCdG46IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCJhLnNlYXJjaC1oZWFkZXItcmVwbGFjZS10b2dnbGVcIiksXHJcbiAgICAgICAgICAgIGNsb3NlQnRuOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI3NlYXJjaGZvcm0taGVhZGVyLXJlcGxhY2UtY2xvc2VcIiksXHJcbiAgICAgICAgICAgIGZvcm06IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjc2VhcmNoZm9ybS1oZWFkZXItcmVwbGFjZVwiKSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIG92ZXJsYXk6IHtcclxuICAgICAgICAgICAgdG9nZ2xlU2VhcmNoQnRuOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiYS5zZWFyY2gtb3ZlcmxheS10b2dnbGVcIiksXHJcbiAgICAgICAgICAgIGNsb3NlQnRuOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI3NlYXJjaGZvcm0tb3ZlcmxheSBhLnNlYXJjaC1vdmVybGF5LWNsb3NlXCIpLFxyXG4gICAgICAgICAgICBmb3JtOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI3NlYXJjaGZvcm0tb3ZlcmxheVwiKSxcclxuICAgICAgICB9LFxyXG4gICAgfSxcclxuICAgIGZvb3Rlcjoge1xyXG4gICAgICAgIHNpdGVGb290ZXI6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjZm9vdGVyXCIpLFxyXG4gICAgICAgIGNhbGxvdXRGb290ZXI6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjZm9vdGVyLWNhbGxvdXQtd3JhcFwiKSxcclxuICAgICAgICBmb290ZXJCYXI6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjZm9vdGVyLWJhclwiKSxcclxuICAgICAgICBwYXJhbGxheDogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5wYXJhbGxheC1mb290ZXJcIiksXHJcbiAgICB9LFxyXG4gICAgc2Nyb2xsOiB7XHJcbiAgICAgICAgc2Nyb2xsVG9wOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI3Njcm9sbC10b3BcIiksXHJcbiAgICAgICAgZ29Ub3A6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2FbaHJlZj1cIiNnby10b3BcIl0nKSxcclxuICAgICAgICBnb1RvcFNsYXNoOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdib2R5LmhvbWUgYVtocmVmPVwiLyNnby10b3BcIl0nKSxcclxuICAgICAgICBpbmZpbml0ZVNjcm9sbE5hdjogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5pbmZpbml0ZS1zY3JvbGwtbmF2XCIpLFxyXG4gICAgICAgIGluZmluaXRlU2Nyb2xsV3JhcHBlcjogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5pbmZpbml0ZS1zY3JvbGwtd3JhcFwiKSxcclxuICAgIH0sXHJcbiAgICBibG9nOiB7XHJcbiAgICAgICAgbWFzb25yeUdyaWRzOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLmJsb2ctbWFzb25yeS1ncmlkXCIpLFxyXG4gICAgfSxcclxuICAgIGVkZDoge1xyXG4gICAgICAgIGNhcnRzOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLmVkZC1tZW51LWljb25cIiksXHJcbiAgICAgICAgb3ZlcmxheUNhcnQ6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIub3dwLWNhcnQtb3ZlcmxheVwiKSxcclxuICAgICAgICB0b3RhbFByaWNlczogZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIi5lZGRtZW51Y2FydC1kZXRhaWxzLnRvdGFsXCIpLFxyXG4gICAgICAgIHF1aWNrVmlld01vZGFsOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI293cC1xdi13cmFwXCIpLFxyXG4gICAgICAgIHF1aWNrVmlld0NvbnRlbnQ6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjb3dwLXF2LWNvbnRlbnRcIiksXHJcbiAgICB9LFxyXG4gICAgd29vOiB7XHJcbiAgICAgICAgcmVzZXRWYXJpYXRpb25zOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLnJlc2V0X3ZhcmlhdGlvbnNcIiksXHJcbiAgICAgICAgcHJvZHVjdDogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi53b29jb21tZXJjZSBkaXYucHJvZHVjdFwiKSxcclxuICAgICAgICBhbGxQcm9kdWN0czogZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIi53b29jb21tZXJjZSB1bC5wcm9kdWN0c1wiKSxcclxuICAgICAgICBjYXRlZ29yaWVzOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLndvby1kcm9wZG93bi1jYXQgLnByb2R1Y3QtY2F0ZWdvcmllc1wiKSxcclxuICAgICAgICB2ZXJ0aWNhbFRodW1iczogZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIi5vd3AtdGh1bWJzLWxheW91dC12ZXJ0aWNhbFwiKSxcclxuICAgICAgICB0aHVtYnNWZXJ0aWNhbExheW91dDogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5vd3AtdGh1bWJzLWxheW91dC12ZXJ0aWNhbFwiKSxcclxuICAgICAgICBncmlkOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLm9jZWFud3AtZ3JpZC1saXN0ICNvY2VhbndwLWdyaWRcIiksXHJcbiAgICAgICAgbGlzdDogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5vY2VhbndwLWdyaWQtbGlzdCAjb2NlYW53cC1saXN0XCIpLFxyXG4gICAgICAgIHByb2R1Y3RUYWJzOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLndvb2NvbW1lcmNlIGRpdi5wcm9kdWN0IC53b29jb21tZXJjZS10YWJzXCIpLFxyXG4gICAgICAgIHByb2R1Y3RDYXJ0czogZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIi53b29jb21tZXJjZSBkaXYucHJvZHVjdCAuY2FydFwiKSxcclxuICAgICAgICBwcm9kdWN0Q3VzdG9tZXJSZXZpZXdMaW5rOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLndvb2NvbW1lcmNlIGRpdi5wcm9kdWN0IC53b29jb21tZXJjZS1yZXZpZXctbGlua1wiKSxcclxuICAgICAgICBxdWFudGl0eTogZG9jdW1lbnQucXVlcnlTZWxlY3RvcignaW5wdXRbbmFtZT1cInF1YW50aXR5XCJdJyksXHJcbiAgICAgICAgY2hlY2tvdXRGb3JtOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiZm9ybS53b29jb21tZXJjZS1jaGVja291dFwiKSxcclxuICAgICAgICBjaGVja291dExvZ2luOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI2NoZWNrb3V0X2xvZ2luXCIpLFxyXG4gICAgICAgIGNoZWNrb3V0Q291cG9uOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI2NoZWNrb3V0X2NvdXBvblwiKSxcclxuICAgICAgICBjaGVja291dFRpbWVsaW5lOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI293cC1jaGVja291dC10aW1lbGluZVwiKSxcclxuICAgICAgICBjdXN0b21lckJpbGxpbmdEZXRhaWxzOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI2N1c3RvbWVyX2JpbGxpbmdfZGV0YWlsc1wiKSxcclxuICAgICAgICBjdXN0b21lclNoaXBwaW5nRGV0YWlsczogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNjdXN0b21lcl9zaGlwcGluZ19kZXRhaWxzXCIpLFxyXG4gICAgICAgIG9yZGVyUmV2aWV3OiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI29yZGVyX3Jldmlld1wiKSxcclxuICAgICAgICBvcmRlckNoZWNrb3V0UGF5bWVudDogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNvcmRlcl9jaGVja291dF9wYXltZW50XCIpLFxyXG4gICAgICAgIHBsYWNlT3JkZXI6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjcGxhY2Vfb3JkZXJcIiksXHJcbiAgICAgICAgZm9ybUFjdGlvbnM6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjZm9ybV9hY3Rpb25zXCIpLFxyXG4gICAgICAgIG92ZXJsYXlDYXJ0OiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLm93cC1jYXJ0LW92ZXJsYXlcIiksXHJcbiAgICAgICAgZ3Vlc3RBY2NvdW50UGFnZU5hdjogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5vd3AtYWNjb3VudC1saW5rc1wiKSxcclxuICAgICAgICBndWVzdEFjY291bnRQYWdlQm94OiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI2N1c3RvbWVyX2xvZ2luXCIpLFxyXG4gICAgICAgIHF1YW50aXR5SW5wdXRzOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLnF1YW50aXR5Om5vdCguYnV0dG9uc19hZGRlZCkgLnF0eVwiKSxcclxuICAgICAgICBxdWlja1ZpZXc6IHtcclxuICAgICAgICAgICAgbW9kYWw6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjb3dwLXF2LXdyYXBcIiksXHJcbiAgICAgICAgICAgIGNvbnRlbnQ6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjb3dwLXF2LWNvbnRlbnRcIiksXHJcbiAgICAgICAgfSxcclxuICAgIH0sXHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgRE9NU3RyaW5nID0ge307XHJcbiIsImV4cG9ydCBjb25zdCB3cmFwID0gKGVsZW1lbnQsIHdyYXBwZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpKSA9PiB7XHJcbiAgICBpZiAoZWxlbWVudC5uZXh0U2libGluZykge1xyXG4gICAgICAgIGVsZW1lbnQucGFyZW50Tm9kZS5pbnNlcnRCZWZvcmUod3JhcHBlciwgZWxlbWVudC5uZXh0U2libGluZyk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIGVsZW1lbnQucGFyZW50Tm9kZS5hcHBlbmRDaGlsZCh3cmFwcGVyKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gd3JhcHBlci5hcHBlbmRDaGlsZChlbGVtZW50KTtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBzbGlkZURvd24gPSAoZWxlbWVudCwgZHVyYXRpb24gPSAzMDApID0+IHtcclxuICAgIGxldCBkaXNwbGF5ID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUoZWxlbWVudCkuZGlzcGxheTtcclxuXHJcbiAgICBpZiAoZGlzcGxheSA9PT0gXCJub25lXCIpIHtcclxuICAgICAgICBkaXNwbGF5ID0gXCJibG9ja1wiO1xyXG4gICAgfVxyXG5cclxuICAgIGVsZW1lbnQuc3R5bGUudHJhbnNpdGlvblByb3BlcnR5ID0gXCJoZWlnaHRcIjtcclxuICAgIGVsZW1lbnQuc3R5bGUudHJhbnNpdGlvbkR1cmF0aW9uID0gYCR7ZHVyYXRpb259bXNgO1xyXG5cclxuICAgIGVsZW1lbnQuc3R5bGUub3BhY2l0eSA9IDA7XHJcbiAgICBlbGVtZW50LnN0eWxlLmRpc3BsYXkgPSBkaXNwbGF5O1xyXG4gICAgbGV0IGhlaWdodCA9IGVsZW1lbnQub2Zmc2V0SGVpZ2h0O1xyXG5cclxuICAgIGVsZW1lbnQuc3R5bGUuaGVpZ2h0ID0gMDtcclxuICAgIGVsZW1lbnQuc3R5bGUub3BhY2l0eSA9IDE7XHJcbiAgICBlbGVtZW50LnN0eWxlLm92ZXJmbG93ID0gXCJoaWRkZW5cIjtcclxuXHJcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICBlbGVtZW50LnN0eWxlLmhlaWdodCA9IGAke2hlaWdodH1weGA7XHJcbiAgICB9LCA1KTtcclxuXHJcbiAgICB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgZWxlbWVudC5zdHlsZS5yZW1vdmVQcm9wZXJ0eShcImhlaWdodFwiKTtcclxuICAgICAgICBlbGVtZW50LnN0eWxlLnJlbW92ZVByb3BlcnR5KFwib3ZlcmZsb3dcIik7XHJcbiAgICAgICAgZWxlbWVudC5zdHlsZS5yZW1vdmVQcm9wZXJ0eShcInRyYW5zaXRpb24tZHVyYXRpb25cIik7XHJcbiAgICAgICAgZWxlbWVudC5zdHlsZS5yZW1vdmVQcm9wZXJ0eShcInRyYW5zaXRpb24tcHJvcGVydHlcIik7XHJcbiAgICAgICAgZWxlbWVudC5zdHlsZS5yZW1vdmVQcm9wZXJ0eShcIm9wYWNpdHlcIik7XHJcbiAgICB9LCBkdXJhdGlvbiArIDUwKTtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBzbGlkZVVwID0gKGVsZW1lbnQsIGR1cmF0aW9uID0gMzAwKSA9PiB7XHJcbiAgICBlbGVtZW50LnN0eWxlLmJveFNpemluZyA9IFwiYm9yZGVyLWJveFwiO1xyXG4gICAgZWxlbWVudC5zdHlsZS50cmFuc2l0aW9uUHJvcGVydHkgPSBcImhlaWdodCwgbWFyZ2luXCI7XHJcbiAgICBlbGVtZW50LnN0eWxlLnRyYW5zaXRpb25EdXJhdGlvbiA9IGAke2R1cmF0aW9ufW1zYDtcclxuICAgIGVsZW1lbnQuc3R5bGUuaGVpZ2h0ID0gYCR7ZWxlbWVudC5vZmZzZXRIZWlnaHR9cHhgO1xyXG4gICAgZWxlbWVudC5zdHlsZS5tYXJnaW5Ub3AgPSAwO1xyXG4gICAgZWxlbWVudC5zdHlsZS5tYXJnaW5Cb3R0b20gPSAwO1xyXG4gICAgZWxlbWVudC5zdHlsZS5vdmVyZmxvdyA9IFwiaGlkZGVuXCI7XHJcblxyXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgZWxlbWVudC5zdHlsZS5oZWlnaHQgPSAwO1xyXG4gICAgfSwgNSk7XHJcblxyXG4gICAgd2luZG93LnNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIGVsZW1lbnQuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xyXG4gICAgICAgIGVsZW1lbnQuc3R5bGUucmVtb3ZlUHJvcGVydHkoXCJoZWlnaHRcIik7XHJcbiAgICAgICAgZWxlbWVudC5zdHlsZS5yZW1vdmVQcm9wZXJ0eShcIm1hcmdpbi10b3BcIik7XHJcbiAgICAgICAgZWxlbWVudC5zdHlsZS5yZW1vdmVQcm9wZXJ0eShcIm1hcmdpbi1ib3R0b21cIik7XHJcbiAgICAgICAgZWxlbWVudC5zdHlsZS5yZW1vdmVQcm9wZXJ0eShcIm92ZXJmbG93XCIpO1xyXG4gICAgICAgIGVsZW1lbnQuc3R5bGUucmVtb3ZlUHJvcGVydHkoXCJ0cmFuc2l0aW9uLWR1cmF0aW9uXCIpO1xyXG4gICAgICAgIGVsZW1lbnQuc3R5bGUucmVtb3ZlUHJvcGVydHkoXCJ0cmFuc2l0aW9uLXByb3BlcnR5XCIpO1xyXG4gICAgfSwgZHVyYXRpb24gKyA1MCk7XHJcbn07XHJcblxyXG5leHBvcnQgY29uc3Qgc2xpZGVUb2dnbGUgPSAoZWxlbWVudCwgZHVyYXRpb24pID0+IHtcclxuICAgIHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKGVsZW1lbnQpLmRpc3BsYXkgPT09IFwibm9uZVwiXHJcbiAgICAgICAgPyBzbGlkZURvd24oZWxlbWVudCwgZHVyYXRpb24pXHJcbiAgICAgICAgOiBzbGlkZVVwKGVsZW1lbnQsIGR1cmF0aW9uKTtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBmYWRlSW4gPSAoZWxlbWVudCwgX29wdGlvbnMgPSB7fSkgPT4ge1xyXG4gICAgY29uc3Qgb3B0aW9ucyA9IHtcclxuICAgICAgICBkdXJhdGlvbjogMzAwLFxyXG4gICAgICAgIGRpc3BsYXk6IG51bGwsXHJcbiAgICAgICAgb3BhY2l0eTogMSxcclxuICAgICAgICBjYWxsYmFjazogbnVsbCxcclxuICAgIH07XHJcblxyXG4gICAgT2JqZWN0LmFzc2lnbihvcHRpb25zLCBfb3B0aW9ucyk7XHJcblxyXG4gICAgZWxlbWVudC5zdHlsZS5vcGFjaXR5ID0gMDtcclxuICAgIGVsZW1lbnQuc3R5bGUuZGlzcGxheSA9IG9wdGlvbnMuZGlzcGxheSB8fCBcImJsb2NrXCI7XHJcblxyXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgZWxlbWVudC5zdHlsZS50cmFuc2l0aW9uID0gYCR7b3B0aW9ucy5kdXJhdGlvbn1tcyBvcGFjaXR5IGVhc2VgO1xyXG4gICAgICAgIGVsZW1lbnQuc3R5bGUub3BhY2l0eSA9IG9wdGlvbnMub3BhY2l0eTtcclxuICAgIH0sIDUpO1xyXG5cclxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIGVsZW1lbnQuc3R5bGUucmVtb3ZlUHJvcGVydHkoXCJ0cmFuc2l0aW9uXCIpO1xyXG4gICAgICAgICEhb3B0aW9ucy5jYWxsYmFjayAmJiBvcHRpb25zLmNhbGxiYWNrKCk7XHJcbiAgICB9LCBvcHRpb25zLmR1cmF0aW9uICsgNTApO1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IGZhZGVPdXQgPSAoZWxlbWVudCwgX29wdGlvbnMgPSB7fSkgPT4ge1xyXG4gICAgaWYgKGVsZW1lbnQuc3R5bGUuZGlzcGxheSA9PT0gXCJub25lXCIpIHtcclxuICAgICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3Qgb3B0aW9ucyA9IHtcclxuICAgICAgICBkdXJhdGlvbjogMzAwLFxyXG4gICAgICAgIGRpc3BsYXk6IG51bGwsXHJcbiAgICAgICAgb3BhY2l0eTogMCxcclxuICAgICAgICBjYWxsYmFjazogbnVsbCxcclxuICAgIH07XHJcblxyXG4gICAgT2JqZWN0LmFzc2lnbihvcHRpb25zLCBfb3B0aW9ucyk7XHJcblxyXG4gICAgZWxlbWVudC5zdHlsZS5vcGFjaXR5ID0gMTtcclxuICAgIGVsZW1lbnQuc3R5bGUuZGlzcGxheSA9IG9wdGlvbnMuZGlzcGxheSB8fCBcImJsb2NrXCI7XHJcblxyXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgZWxlbWVudC5zdHlsZS50cmFuc2l0aW9uID0gYCR7b3B0aW9ucy5kdXJhdGlvbn1tcyBvcGFjaXR5IGVhc2VgO1xyXG4gICAgICAgIGVsZW1lbnQuc3R5bGUub3BhY2l0eSA9IG9wdGlvbnMub3BhY2l0eTtcclxuICAgIH0sIDUpO1xyXG5cclxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIGVsZW1lbnQuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xyXG4gICAgICAgIGVsZW1lbnQuc3R5bGUucmVtb3ZlUHJvcGVydHkoXCJ0cmFuc2l0aW9uXCIpO1xyXG4gICAgICAgICEhb3B0aW9ucy5jYWxsYmFjayAmJiBvcHRpb25zLmNhbGxiYWNrKCk7XHJcbiAgICB9LCBvcHRpb25zLmR1cmF0aW9uICsgNTApO1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IGZhZGVUb2dnbGUgPSAoZWxlbWVudCwgb3B0aW9ucykgPT4ge1xyXG4gICAgd2luZG93LmdldENvbXB1dGVkU3R5bGUoZWxlbWVudCkuZGlzcGxheSA9PT0gXCJub25lXCJcclxuICAgICAgICA/IGZhZGVJbihlbGVtZW50LCBvcHRpb25zKVxyXG4gICAgICAgIDogZmFkZU91dChlbGVtZW50LCBvcHRpb25zKTtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBvZmZzZXQgPSBlbGVtZW50ID0+IHtcclxuICAgIGlmICghZWxlbWVudC5nZXRDbGllbnRSZWN0cygpLmxlbmd0aCkge1xyXG4gICAgICAgIHJldHVybiB7IHRvcDogMCwgbGVmdDogMCB9O1xyXG4gICAgfVxyXG5cclxuICAgIC8vIEdldCBkb2N1bWVudC1yZWxhdGl2ZSBwb3NpdGlvbiBieSBhZGRpbmcgdmlld3BvcnQgc2Nyb2xsIHRvIHZpZXdwb3J0LXJlbGF0aXZlIGdCQ1JcclxuICAgIGNvbnN0IHJlY3QgPSBlbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xyXG4gICAgY29uc3Qgd2luID0gZWxlbWVudC5vd25lckRvY3VtZW50LmRlZmF1bHRWaWV3O1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICB0b3A6IHJlY3QudG9wICsgd2luLnBhZ2VZT2Zmc2V0LFxyXG4gICAgICAgIGxlZnQ6IHJlY3QubGVmdCArIHdpbi5wYWdlWE9mZnNldCxcclxuICAgIH07XHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgdmlzaWJsZSA9IGVsZW1lbnQgPT4ge1xyXG4gICAgaWYgKCFlbGVtZW50KSB7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiAhIShcclxuICAgICAgICBlbGVtZW50Lm9mZnNldFdpZHRoIHx8XHJcbiAgICAgICAgZWxlbWVudC5vZmZzZXRIZWlnaHQgfHxcclxuICAgICAgICBlbGVtZW50LmdldENsaWVudFJlY3RzKCkubGVuZ3RoXHJcbiAgICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IGdldFNpYmxpbmdzID0gZSA9PiB7XHJcbiAgICAvLyBmb3IgY29sbGVjdGluZyBzaWJsaW5nc1xyXG4gICAgY29uc3Qgc2libGluZ3MgPSBbXTtcclxuXHJcbiAgICAvLyBpZiBubyBwYXJlbnQsIHJldHVybiBubyBzaWJsaW5nXHJcbiAgICBpZiAoIWUucGFyZW50Tm9kZSkge1xyXG4gICAgICAgIHJldHVybiBzaWJsaW5ncztcclxuICAgIH1cclxuXHJcbiAgICAvLyBmaXJzdCBjaGlsZCBvZiB0aGUgcGFyZW50IG5vZGVcclxuICAgIGxldCBzaWJsaW5nID0gZS5wYXJlbnROb2RlLmZpcnN0Q2hpbGQ7XHJcblxyXG4gICAgLy8gY29sbGVjdGluZyBzaWJsaW5nc1xyXG4gICAgd2hpbGUgKHNpYmxpbmcpIHtcclxuICAgICAgICBpZiAoc2libGluZy5ub2RlVHlwZSA9PT0gMSAmJiBzaWJsaW5nICE9PSBlKSB7XHJcbiAgICAgICAgICAgIHNpYmxpbmdzLnB1c2goc2libGluZyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBzaWJsaW5nID0gc2libGluZy5uZXh0U2libGluZztcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gc2libGluZ3M7XHJcbn07XHJcblxyXG4vLyBSZXR1cm5zIHRydWUgaWYgaXQgaXMgYSBET00gZWxlbWVudFxyXG5leHBvcnQgY29uc3QgaXNFbGVtZW50ID0gbyA9PiB7XHJcbiAgICByZXR1cm4gdHlwZW9mIEhUTUxFbGVtZW50ID09PSBcIm9iamVjdFwiXHJcbiAgICAgICAgPyBvIGluc3RhbmNlb2YgSFRNTEVsZW1lbnQgLy8gRE9NMlxyXG4gICAgICAgIDogbyAmJlxyXG4gICAgICAgICAgICAgIHR5cGVvZiBvID09PSBcIm9iamVjdFwiICYmXHJcbiAgICAgICAgICAgICAgbyAhPT0gbnVsbCAmJlxyXG4gICAgICAgICAgICAgIG8ubm9kZVR5cGUgPT09IDEgJiZcclxuICAgICAgICAgICAgICB0eXBlb2Ygby5ub2RlTmFtZSA9PT0gXCJzdHJpbmdcIjtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBpc1NlbGVjdG9yVmFsaWQgPSAoZHVtbXlFbGVtZW50ID0+IHNlbGVjdG9yID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgICAgZHVtbXlFbGVtZW50LnF1ZXJ5U2VsZWN0b3Ioc2VsZWN0b3IpO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRydWU7XHJcbn0pKGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKSk7XHJcbiIsImNsYXNzIFdvb1JlbW92ZUNhdGVnb3JpZXNDb3VudFBhcmVudGhlc2lzIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgdGhpcy4jc3RhcnQoKTtcbiAgICB9XG5cbiAgICAjc3RhcnQgPSAoKSA9PiB7XG4gICAgICAgIGRvY3VtZW50XG4gICAgICAgICAgICAucXVlcnlTZWxlY3RvckFsbChcIi53aWRnZXRfbGF5ZXJlZF9uYXYgc3Bhbi5jb3VudCwgLndpZGdldF9wcm9kdWN0X2NhdGVnb3JpZXMgc3Bhbi5jb3VudFwiKVxuICAgICAgICAgICAgLmZvckVhY2goKGl0ZW0pID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBjb3VudCA9IGl0ZW0uaW5uZXJIVE1MO1xuICAgICAgICAgICAgICAgIGl0ZW0uaW5uZXJIVE1MID0gY291bnQuc3Vic3RyaW5nKDEsIGNvdW50Lmxlbmd0aCAtIDEpO1xuICAgICAgICAgICAgfSk7XG4gICAgfTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgV29vUmVtb3ZlQ2F0ZWdvcmllc0NvdW50UGFyZW50aGVzaXM7XG4iLCJpbXBvcnQgeyBET00gfSBmcm9tIFwiLi4vLi4vLi4vY29uc3RhbnRzXCI7XG5cbmNsYXNzIFdvb1Jlc2V0VmFyaWF0aW9ucyB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIGlmICghIURPTS53b28ucmVzZXRWYXJpYXRpb25zKSB7XG4gICAgICAgICAgICB0aGlzLiNzZXR1cEV2ZW50TGlzdGVuZXJzKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAjc2V0dXBFdmVudExpc3RlbmVycyA9ICgpID0+IHtcbiAgICAgICAgRE9NLndvby5yZXNldFZhcmlhdGlvbnMuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIChldmVudCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgcmVzZXRWYXJpYXRpb25zID0gZXZlbnQuY3VycmVudFRhcmdldDtcblxuICAgICAgICAgICAgcmVzZXRWYXJpYXRpb25zXG4gICAgICAgICAgICAgICAgLmNsb3Nlc3QoXCIudmFyaWF0aW9uc1wiKVxuICAgICAgICAgICAgICAgIC5xdWVyeVNlbGVjdG9yQWxsKFwic2VsZWN0XCIpXG4gICAgICAgICAgICAgICAgLmZvckVhY2goKHNlbGVjdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdC5uZXh0U2libGluZy5pbm5lckhUTUwgPSBzZWxlY3Qub3B0aW9uc1tzZWxlY3Quc2VsZWN0ZWRJbmRleF0udGV4dDtcbiAgICAgICAgICAgICAgICAgICAgfSwgMTAwKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgV29vUmVzZXRWYXJpYXRpb25zO1xuIiwiaW1wb3J0IENvb2tpZXMgZnJvbSBcImpzLWNvb2tpZVwiO1xuaW1wb3J0IHsgRE9NIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnN0YW50c1wiO1xuaW1wb3J0IHsgZmFkZUluLCBmYWRlT3V0IH0gZnJvbSBcIi4uLy4uLy4uL2xpYi91dGlsc1wiO1xuXG5jbGFzcyBXb29HcmlkTGlzdCB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIGlmIChET00uYm9keS5jbGFzc0xpc3QuY29udGFpbnMoXCJoYXMtZ3JpZC1saXN0XCIpKSB7XG4gICAgICAgICAgICB0aGlzLiNzdGFydCgpO1xuICAgICAgICAgICAgdGhpcy4jc2V0dXBFdmVudExpc3RlbmVycygpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgQ29va2llcy5yZW1vdmUoXCJncmlkY29va2llXCIsIHsgcGF0aDogXCJcIiB9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgICNzdGFydCA9ICgpID0+IHtcbiAgICAgICAgaWYgKCEoRE9NLndvby5ncmlkIHx8IERPTS53b28ubGlzdCkpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChDb29raWVzLmdldChcImdyaWRjb29raWVcIikgPT09IFwiZ3JpZFwiKSB7XG4gICAgICAgICAgICBET00ud29vLmdyaWQ/LmNsYXNzTGlzdC5hZGQoXCJhY3RpdmVcIik7XG4gICAgICAgICAgICBET00ud29vLmxpc3Q/LmNsYXNzTGlzdC5yZW1vdmUoXCJhY3RpdmVcIik7XG5cbiAgICAgICAgICAgIERPTS53b28uYWxsUHJvZHVjdHM/LmZvckVhY2goKHByb2R1Y3RzKSA9PiB7XG4gICAgICAgICAgICAgICAgcHJvZHVjdHMuY2xhc3NMaXN0LmFkZChcImdyaWRcIik7XG4gICAgICAgICAgICAgICAgcHJvZHVjdHMuY2xhc3NMaXN0LnJlbW92ZShcImxpc3RcIik7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChDb29raWVzLmdldChcImdyaWRjb29raWVcIikgPT09IFwibGlzdFwiKSB7XG4gICAgICAgICAgICBET00ud29vLmdyaWQ/LmNsYXNzTGlzdC5yZW1vdmUoXCJhY3RpdmVcIik7XG4gICAgICAgICAgICBET00ud29vLmxpc3Q/LmNsYXNzTGlzdC5hZGQoXCJhY3RpdmVcIik7XG5cbiAgICAgICAgICAgIERPTS53b28uYWxsUHJvZHVjdHM/LmZvckVhY2goKHByb2R1Y3RzKSA9PiB7XG4gICAgICAgICAgICAgICAgcHJvZHVjdHMuY2xhc3NMaXN0LmFkZChcImxpc3RcIik7XG4gICAgICAgICAgICAgICAgcHJvZHVjdHMuY2xhc3NMaXN0LnJlbW92ZShcImdyaWRcIik7XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgdGhpcy4jcHJvZHVjdENhcm91c2VsKCk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgI3NldHVwRXZlbnRMaXN0ZW5lcnMgPSAoKSA9PiB7XG4gICAgICAgIERPTS53b28uZ3JpZD8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIHRoaXMuI29uR3JpZENsaWNrKTtcbiAgICAgICAgRE9NLndvby5saXN0Py5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgdGhpcy4jb25MaXN0Q2xpY2spO1xuICAgIH07XG5cbiAgICAjb25HcmlkQ2xpY2sgPSAoZXZlbnQpID0+IHtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG5cbiAgICAgICAgRE9NLndvby5ncmlkLmNsYXNzTGlzdC5hZGQoXCJhY3RpdmVcIik7XG4gICAgICAgIERPTS53b28ubGlzdC5jbGFzc0xpc3QucmVtb3ZlKFwiYWN0aXZlXCIpO1xuXG4gICAgICAgIENvb2tpZXMuc2V0KFwiZ3JpZGNvb2tpZVwiLCBcImdyaWRcIiwgeyBwYXRoOiBcIlwiIH0pO1xuXG4gICAgICAgIERPTS53b28uYWxsUHJvZHVjdHMuZm9yRWFjaCgocHJvZHVjdHMpID0+IHtcbiAgICAgICAgICAgIGZhZGVPdXQocHJvZHVjdHMsIHtcbiAgICAgICAgICAgICAgICBjYWxsYmFjazogKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBwcm9kdWN0cy5jbGFzc0xpc3QuYWRkKFwiZ3JpZFwiKTtcbiAgICAgICAgICAgICAgICAgICAgcHJvZHVjdHMuY2xhc3NMaXN0LnJlbW92ZShcImxpc3RcIik7XG5cbiAgICAgICAgICAgICAgICAgICAgZmFkZUluKHByb2R1Y3RzKTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy4jcHJvZHVjdENhcm91c2VsKCk7XG4gICAgICAgIH0sIDMwMSk7XG4gICAgfTtcblxuICAgICNvbkxpc3RDbGljayA9IChldmVudCkgPT4ge1xuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcblxuICAgICAgICBET00ud29vLmdyaWQuY2xhc3NMaXN0LnJlbW92ZShcImFjdGl2ZVwiKTtcbiAgICAgICAgRE9NLndvby5saXN0LmNsYXNzTGlzdC5hZGQoXCJhY3RpdmVcIik7XG5cbiAgICAgICAgQ29va2llcy5zZXQoXCJncmlkY29va2llXCIsIFwibGlzdFwiLCB7IHBhdGg6IFwiXCIgfSk7XG5cbiAgICAgICAgRE9NLndvby5hbGxQcm9kdWN0cy5mb3JFYWNoKChwcm9kdWN0cykgPT4ge1xuICAgICAgICAgICAgZmFkZU91dChwcm9kdWN0cywge1xuICAgICAgICAgICAgICAgIGNhbGxiYWNrOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHByb2R1Y3RzLmNsYXNzTGlzdC5hZGQoXCJsaXN0XCIpO1xuICAgICAgICAgICAgICAgICAgICBwcm9kdWN0cy5jbGFzc0xpc3QucmVtb3ZlKFwiZ3JpZFwiKTtcblxuICAgICAgICAgICAgICAgICAgICBmYWRlSW4ocHJvZHVjdHMpO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLiNwcm9kdWN0Q2Fyb3VzZWwoKTtcbiAgICAgICAgfSwgMzAxKTtcbiAgICB9O1xuXG4gICAgI3Byb2R1Y3RDYXJvdXNlbCA9ICgpID0+IHtcbiAgICAgICAgaWYgKFxuICAgICAgICAgICAgIURPTS5ib2R5LmNsYXNzTGlzdC5jb250YWlucyhcIm5vLWNhcm91c2VsXCIpICYmXG4gICAgICAgICAgICAhIWRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIud29vLWVudHJ5LWltYWdlLnByb2R1Y3QtZW50cnktc2xpZGVyXCIpXG4gICAgICAgICkge1xuICAgICAgICAgICAgb2NlYW53cC50aGVtZS5vd1NsaWRlci5mbGlja2l0eT8uZm9yRWFjaCgoZmxpY2tpdHkpID0+IHtcbiAgICAgICAgICAgICAgICBmbGlja2l0eS5kZXN0cm95KCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIG9jZWFud3AudGhlbWUub3dTbGlkZXIuc3RhcnQoKTtcbiAgICB9O1xufVxuXG5leHBvcnQgZGVmYXVsdCBXb29HcmlkTGlzdDtcbiIsImltcG9ydCB7IERPTSB9IGZyb20gXCIuLi8uLi8uLi9jb25zdGFudHNcIjtcbmltcG9ydCB7IGZhZGVJbiwgZmFkZU91dCwgZ2V0U2libGluZ3MgfSBmcm9tIFwiLi4vLi4vLi4vbGliL3V0aWxzXCI7XG5cbmNsYXNzIFdvb0d1ZXN0QWNjb3VudFBhZ2Uge1xuICAgICNsb2dpbkJ0bjtcbiAgICAjcmVnaXN0ZXJCdG47XG4gICAgI2xvZ2luQm94O1xuICAgICNyZWdpc3RlckJveDtcblxuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICAvLyBSZXR1cm4gaWYgcmVnaXN0cmF0aW9uIGRpc2FibGVkXG4gICAgICAgIGlmIChET00ud29vLmd1ZXN0QWNjb3VudFBhZ2VOYXY/LmNsYXNzTGlzdC5jb250YWlucyhcInJlZ2lzdHJhdGlvbi1kaXNhYmxlZFwiKSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy4jc3RhcnQoKTtcbiAgICAgICAgdGhpcy4jc2V0dXBFdmVudExpc3RlbmVycygpO1xuICAgIH1cblxuICAgICNzdGFydCA9ICgpID0+IHtcbiAgICAgICAgdGhpcy4jbG9naW5CdG4gPSBET00ud29vLmd1ZXN0QWNjb3VudFBhZ2VOYXY/LnF1ZXJ5U2VsZWN0b3IoXCIubG9naW4gYVwiKTtcbiAgICAgICAgdGhpcy4jcmVnaXN0ZXJCdG4gPSBET00ud29vLmd1ZXN0QWNjb3VudFBhZ2VOYXY/LnF1ZXJ5U2VsZWN0b3IoXCIucmVnaXN0ZXIgYVwiKTtcbiAgICAgICAgdGhpcy4jbG9naW5Cb3ggPSBET00ud29vLmd1ZXN0QWNjb3VudFBhZ2VCb3g/LnF1ZXJ5U2VsZWN0b3IoXCIuY29sLTFcIik7XG4gICAgICAgIHRoaXMuI3JlZ2lzdGVyQm94ID0gRE9NLndvby5ndWVzdEFjY291bnRQYWdlQm94Py5xdWVyeVNlbGVjdG9yKFwiLmNvbC0yXCIpO1xuICAgIH07XG5cbiAgICAjc2V0dXBFdmVudExpc3RlbmVycyA9ICgpID0+IHtcbiAgICAgICAgdGhpcy4jbG9naW5CdG4/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCB0aGlzLiNvbkxvZ2luQnRuQ2xpY2spO1xuICAgICAgICB0aGlzLiNyZWdpc3RlckJ0bj8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIHRoaXMuI29uUmVnaXN0ZXJCdG5DbGljayk7XG4gICAgfTtcblxuICAgICNvbkxvZ2luQnRuQ2xpY2sgPSAoZXZlbnQpID0+IHtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG5cbiAgICAgICAgdGhpcy4jbG9naW5CdG4uY2xhc3NMaXN0LmFkZChcImN1cnJlbnRcIik7XG4gICAgICAgIHRoaXMuI3JlZ2lzdGVyQnRuLmNsYXNzTGlzdC5yZW1vdmUoXCJjdXJyZW50XCIpO1xuXG4gICAgICAgIGZhZGVPdXQodGhpcy4jcmVnaXN0ZXJCb3gsIHtcbiAgICAgICAgICAgIGNhbGxiYWNrOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgZmFkZUluKHRoaXMuI2xvZ2luQm94KTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH07XG5cbiAgICAjb25SZWdpc3RlckJ0bkNsaWNrID0gKGV2ZW50KSA9PiB7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuXG4gICAgICAgIHRoaXMuI3JlZ2lzdGVyQnRuLmNsYXNzTGlzdC5hZGQoXCJjdXJyZW50XCIpO1xuICAgICAgICB0aGlzLiNsb2dpbkJ0bi5jbGFzc0xpc3QucmVtb3ZlKFwiY3VycmVudFwiKTtcblxuICAgICAgICBmYWRlT3V0KHRoaXMuI2xvZ2luQm94LCB7XG4gICAgICAgICAgICBjYWxsYmFjazogKCkgPT4ge1xuICAgICAgICAgICAgICAgIGZhZGVJbih0aGlzLiNyZWdpc3RlckJveCk7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9O1xufVxuXG5leHBvcnQgZGVmYXVsdCBXb29HdWVzdEFjY291bnRQYWdlO1xuIiwiaW1wb3J0IGRlbGVnYXRlIGZyb20gXCJkZWxlZ2F0ZVwiO1xuaW1wb3J0IHsgRE9NLCBvcHRpb25zIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnN0YW50c1wiO1xuXG5jbGFzcyBXb29RdWFudGl0eUJ1dHRvbnMge1xuICAgICNjaGFuZ2VFdmVudDtcbiAgICAjZmlyc3RUaW1lUnVubmluZztcblxuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICB0aGlzLiNmaXJzdFRpbWVSdW5uaW5nID0gdHJ1ZTtcblxuICAgICAgICB0aGlzLnN0YXJ0KCk7XG4gICAgICAgIHRoaXMuI3NldHVwRXZlbnRMaXN0ZW5lcnMoKTtcbiAgICB9XG5cbiAgICBzdGFydCA9ICgpID0+IHtcbiAgICAgICAgY29uc3QgcXVhbnRpdHlJbnB1dHMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFxuICAgICAgICAgICAgXCIucXVhbnRpdHk6bm90KC5idXR0b25zX2FkZGVkKSAucXR5XCJcbiAgICAgICAgKTtcblxuICAgICAgICBpZiAoISFxdWFudGl0eUlucHV0cykge1xuICAgICAgICAgICAgcXVhbnRpdHlJbnB1dHMuZm9yRWFjaChxdWFudGl0eUlucHV0ID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBpbnB1dFR5cGUgPSBxdWFudGl0eUlucHV0LmdldEF0dHJpYnV0ZShcInR5cGVcIik7XG5cbiAgICAgICAgICAgICAgICBpZiAoIShpbnB1dFR5cGUgPT09IFwiZGF0ZVwiIHx8IGlucHV0VHlwZSA9PT0gXCJoaWRkZW5cIikpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gQWRkIG1pbnVzIGljb25cbiAgICAgICAgICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgIXF1YW50aXR5SW5wdXQucHJldmlvdXNFbGVtZW50U2libGluZz8uY2xhc3NMaXN0LmNvbnRhaW5zKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwibWludXNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHF1YW50aXR5SW5wdXQuaW5zZXJ0QWRqYWNlbnRIVE1MKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiYmVmb3JlYmVnaW5cIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAnPGEgaHJlZj1cImphdmFzY3JpcHQ6dm9pZCgwKVwiIGNsYXNzPVwibWludXNcIj4tPC9hPidcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAvLyBBZGQgcGx1cyBpY29uXG4gICAgICAgICAgICAgICAgICAgIGlmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICFxdWFudGl0eUlucHV0Lm5leHRFbGVtZW50U2libGluZz8uY2xhc3NMaXN0LmNvbnRhaW5zKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwicGx1c1wiXG4gICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcXVhbnRpdHlJbnB1dC5pbnNlcnRBZGphY2VudEhUTUwoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJhZnRlcmVuZFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICc8YSBocmVmPVwiamF2YXNjcmlwdDp2b2lkKDApXCIgY2xhc3M9XCJwbHVzXCI+KzwvYT4nXG4gICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIC8vIENoZWNrIHF1YW50aXR5IGJpZ2dlciB0aGFuIG1pblxuICAgICAgICAgICAgZG9jdW1lbnRcbiAgICAgICAgICAgICAgICAucXVlcnlTZWxlY3RvckFsbChcImlucHV0LnF0eTpub3QoLnByb2R1Y3QtcXVhbnRpdHkgaW5wdXQucXR5KVwiKVxuICAgICAgICAgICAgICAgIC5mb3JFYWNoKHF1YW50aXR5SW5wdXQgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBtaW4gPSBwYXJzZUZsb2F0KHF1YW50aXR5SW5wdXQuZ2V0QXR0cmlidXRlKFwibWluXCIpKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY3VycmVudFZhbHVlID0gcGFyc2VGbG9hdChxdWFudGl0eUlucHV0LnZhbHVlKTtcblxuICAgICAgICAgICAgICAgICAgICBpZiAobWluICYmIG1pbiA+IDAgJiYgY3VycmVudFZhbHVlIDwgbWluKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBxdWFudGl0eUlucHV0LnZhbHVlID0gbWluO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIGlmICh0aGlzLiNmaXJzdFRpbWVSdW5uaW5nKSB7XG4gICAgICAgICAgICAgICAgLy8gQ3JlYXRlIGEgbmV3ICdjaGFuZ2UnIGV2ZW50XG4gICAgICAgICAgICAgICAgdGhpcy4jY2hhbmdlRXZlbnQgPSBuZXcgRXZlbnQoXCJjaGFuZ2VcIiwgeyBidWJibGVzOiB0cnVlIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcblxuICAgICNzZXR1cEV2ZW50TGlzdGVuZXJzID0gKCkgPT4ge1xuICAgICAgICBjb25zdCBxdWFudGl0eUlucHV0cyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXG4gICAgICAgICAgICBcIi5xdWFudGl0eTpub3QoLmJ1dHRvbnNfYWRkZWQpIC5xdHlcIlxuICAgICAgICApO1xuXG4gICAgICAgIC8vIFVwZGF0ZSBmbG9hdGluZyBiYXIgcXVhbnRpdHlcbiAgICAgICAgaWYgKCEhcXVhbnRpdHlJbnB1dHMpIHtcbiAgICAgICAgICAgIGlmIChcbiAgICAgICAgICAgICAgICBET00uYm9keS5jbGFzc0xpc3QuY29udGFpbnMoXCJzaW5nbGUtcHJvZHVjdFwiKSAmJlxuICAgICAgICAgICAgICAgIG9wdGlvbnMuZmxvYXRpbmdfYmFyID09PSBcIm9uXCIgJiZcbiAgICAgICAgICAgICAgICAhQXJyYXkuZnJvbShET00ud29vLnByb2R1Y3RDYXJ0cykuc29tZShcbiAgICAgICAgICAgICAgICAgICAgKHsgY2xhc3NMaXN0IH0pID0+XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc0xpc3QuY29udGFpbnMoXCJncm91cGVkX2Zvcm1cIikgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTGlzdC5jb250YWlucyhcImNhcnRfZ3JvdXBcIilcbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICBxdWFudGl0eUlucHV0cy5mb3JFYWNoKHF1YW50aXR5SW5wdXQgPT4ge1xuICAgICAgICAgICAgICAgICAgICBxdWFudGl0eUlucHV0LmFkZEV2ZW50TGlzdGVuZXIoXG4gICAgICAgICAgICAgICAgICAgICAgICBcImtleXVwXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiNvblF1YW50aXR5SW5wdXRLZXl1cFxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICBxdWFudGl0eUlucHV0LmFkZEV2ZW50TGlzdGVuZXIoXG4gICAgICAgICAgICAgICAgICAgICAgICBcImNoYW5nZVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4jb25RdWFudGl0eUlucHV0S2V5dXBcbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGRlbGVnYXRlKFxuICAgICAgICAgICAgRE9NLmJvZHksXG4gICAgICAgICAgICBcIi5jYXJ0IC5taW51cywgLmNhcnQgLnBsdXMsIC50aW52LXdpc2hsaXN0IC5taW51cywgLnRpbnYtd2lzaGxpc3QgLnBsdXMsIC5xdWFudGl0eSAubWludXMsIC5xdWFudGl0eSAucGx1c1wiLFxuICAgICAgICAgICAgXCJjbGlja1wiLFxuICAgICAgICAgICAgdGhpcy4jb25RdWFudGl0eUJ0bkNsaWNrXG4gICAgICAgICk7XG4gICAgfTtcblxuICAgICNvblF1YW50aXR5SW5wdXRLZXl1cCA9IGV2ZW50ID0+IHtcbiAgICAgICAgY29uc3QgY3VycmVudFF1YW50aXR5SW5wdXQgPSBldmVudC50YXJnZXQ7XG5cbiAgICAgICAgY29uc3QgaW5wdXRUeXBlID0gY3VycmVudFF1YW50aXR5SW5wdXQuZ2V0QXR0cmlidXRlKFwidHlwZVwiKTtcbiAgICAgICAgY29uc3QgcXVhbnRpdHlJbnB1dHMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFxuICAgICAgICAgICAgXCIucXVhbnRpdHk6bm90KC5idXR0b25zX2FkZGVkKSAucXR5XCJcbiAgICAgICAgKTtcblxuICAgICAgICBpZiAoIShpbnB1dFR5cGUgPT09IFwiZGF0ZVwiIHx8IGlucHV0VHlwZSA9PT0gXCJoaWRkZW5cIikpIHtcbiAgICAgICAgICAgIHF1YW50aXR5SW5wdXRzLmZvckVhY2gocXVhbnRpdHlJbnB1dCA9PiB7XG4gICAgICAgICAgICAgICAgcXVhbnRpdHlJbnB1dC52YWx1ZSA9IGN1cnJlbnRRdWFudGl0eUlucHV0LnZhbHVlO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgI29uUXVhbnRpdHlCdG5DbGljayA9IGV2ZW50ID0+IHtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG5cbiAgICAgICAgY29uc3QgcXVhbnRpdHlCdG4gPSBldmVudC5kZWxlZ2F0ZVRhcmdldDtcbiAgICAgICAgY29uc3QgcXVhbnRpdHlJbnB1dCA9IHF1YW50aXR5QnRuXG4gICAgICAgICAgICAuY2xvc2VzdChcIi5xdWFudGl0eVwiKVxuICAgICAgICAgICAgLnF1ZXJ5U2VsZWN0b3IoXCIucXR5XCIpO1xuXG4gICAgICAgIGxldCBjdXJyZW50VmFsdWUgPSBwYXJzZUZsb2F0KHF1YW50aXR5SW5wdXQudmFsdWUpO1xuICAgICAgICBsZXQgbWluID0gcGFyc2VGbG9hdChxdWFudGl0eUlucHV0LmdldEF0dHJpYnV0ZShcIm1pblwiKSk7XG4gICAgICAgIGxldCBtYXggPSBwYXJzZUZsb2F0KHF1YW50aXR5SW5wdXQuZ2V0QXR0cmlidXRlKFwibWF4XCIpKTtcbiAgICAgICAgbGV0IHN0ZXAgPSBxdWFudGl0eUlucHV0LmdldEF0dHJpYnV0ZShcInN0ZXBcIik7XG5cbiAgICAgICAgLy8gRmFsbGJhY2sgZGVmYXVsdCB2YWx1ZXNcbiAgICAgICAgaWYgKFxuICAgICAgICAgICAgIWN1cnJlbnRWYWx1ZSB8fFxuICAgICAgICAgICAgY3VycmVudFZhbHVlID09PSBcIlwiIHx8XG4gICAgICAgICAgICBOdW1iZXIuaXNOYU4oY3VycmVudFZhbHVlKVxuICAgICAgICApIHtcbiAgICAgICAgICAgIGN1cnJlbnRWYWx1ZSA9IDA7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAobWF4ID09PSBcIlwiIHx8IE51bWJlci5pc05hTihtYXgpKSB7XG4gICAgICAgICAgICBtYXggPSBcIlwiO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKG1pbiA9PT0gXCJcIiB8fCBOdW1iZXIuaXNOYU4obWluKSkge1xuICAgICAgICAgICAgbWluID0gMDtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChcbiAgICAgICAgICAgIHN0ZXAgPT09IHVuZGVmaW5lZCB8fFxuICAgICAgICAgICAgc3RlcCA9PT0gXCJcIiB8fFxuICAgICAgICAgICAgc3RlcCA9PT0gXCJhbnlcIiB8fFxuICAgICAgICAgICAgTnVtYmVyLmlzTmFOKHBhcnNlRmxvYXQoc3RlcCkpXG4gICAgICAgICkge1xuICAgICAgICAgICAgc3RlcCA9IDE7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBQbHVzIGJ1dHRvblxuICAgICAgICBpZiAocXVhbnRpdHlCdG4uY2xhc3NMaXN0LmNvbnRhaW5zKFwicGx1c1wiKSkge1xuICAgICAgICAgICAgaWYgKG1heCAmJiAoY3VycmVudFZhbHVlID09PSBtYXggfHwgY3VycmVudFZhbHVlID4gbWF4KSkge1xuICAgICAgICAgICAgICAgIHF1YW50aXR5SW5wdXQudmFsdWUgPSBtYXg7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHF1YW50aXR5SW5wdXQudmFsdWUgPSBjdXJyZW50VmFsdWUgKyBwYXJzZUZsb2F0KHN0ZXApO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBNaW51cyBidXR0b25cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGlmIChtaW4gJiYgKGN1cnJlbnRWYWx1ZSA9PT0gbWluIHx8IGN1cnJlbnRWYWx1ZSA8IG1pbikpIHtcbiAgICAgICAgICAgICAgICBxdWFudGl0eUlucHV0LnZhbHVlID0gbWluO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChjdXJyZW50VmFsdWUgPiAwKSB7XG4gICAgICAgICAgICAgICAgcXVhbnRpdHlJbnB1dC52YWx1ZSA9IGN1cnJlbnRWYWx1ZSAtIHBhcnNlRmxvYXQoc3RlcCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoXG4gICAgICAgICAgICAhIXF1YW50aXR5QnRuLmNsb3Nlc3QoXCJmb3JtXCIpPy5xdWVyeVNlbGVjdG9yKFwiLmFkZF90b19jYXJ0X2J1dHRvblwiKVxuICAgICAgICApIHtcbiAgICAgICAgICAgIHF1YW50aXR5QnRuXG4gICAgICAgICAgICAgICAgLmNsb3Nlc3QoXCJmb3JtXCIpXG4gICAgICAgICAgICAgICAgLnF1ZXJ5U2VsZWN0b3IoXCIuYWRkX3RvX2NhcnRfYnV0dG9uXCIpLmRhdGFzZXQucXVhbnRpdHkgPVxuICAgICAgICAgICAgICAgIHF1YW50aXR5SW5wdXQudmFsdWU7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoXG4gICAgICAgICAgICAhIXF1YW50aXR5QnRuLmNsb3Nlc3QoXCIuY2FydFwiKT8ucXVlcnlTZWxlY3RvcihcIi5hZGRfdG9fY2FydF9idXR0b25cIilcbiAgICAgICAgKSB7XG4gICAgICAgICAgICBxdWFudGl0eUJ0blxuICAgICAgICAgICAgICAgIC5jbG9zZXN0KFwiLmNhcnRcIilcbiAgICAgICAgICAgICAgICAucXVlcnlTZWxlY3RvcihcIi5hZGRfdG9fY2FydF9idXR0b25cIikuZGF0YXNldC5xdWFudGl0eSA9XG4gICAgICAgICAgICAgICAgcXVhbnRpdHlJbnB1dC52YWx1ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFRyaWdnZXIgY2hhbmdlIGV2ZW50XG4gICAgICAgIHF1YW50aXR5SW5wdXQuZGlzcGF0Y2hFdmVudCh0aGlzLiNjaGFuZ2VFdmVudCk7XG4gICAgfTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgV29vUXVhbnRpdHlCdXR0b25zO1xuIiwiaW1wb3J0IHsgRE9NIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnN0YW50c1wiO1xuaW1wb3J0IHsgb2Zmc2V0IH0gZnJvbSBcIi4uLy4uLy4uL2xpYi91dGlsc1wiO1xuXG5jbGFzcyBXb29TY3JvbGxUb1Jldmlld1RhYiB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIGlmICghIURPTS53b28ucHJvZHVjdEN1c3RvbWVyUmV2aWV3TGluaykge1xuICAgICAgICAgICAgdGhpcy4jc2V0dXBFdmVudExpc3RlbmVycygpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgI3NldHVwRXZlbnRMaXN0ZW5lcnMgPSAoKSA9PiB7XG4gICAgICAgIERPTS53b28ucHJvZHVjdEN1c3RvbWVyUmV2aWV3TGluay5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgdGhpcy4jb25DdXN0b21lclJldmlld0xpbmtDbGljayk7XG4gICAgfTtcblxuICAgICNvbkN1c3RvbWVyUmV2aWV3TGlua0NsaWNrID0gKGV2ZW50KSA9PiB7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuXG4gICAgICAgIGlmICghIURPTS53b28ucHJvZHVjdFRhYnMucXVlcnlTZWxlY3RvcihcIi5kZXNjcmlwdGlvbl90YWJcIikpIHtcbiAgICAgICAgICAgIERPTS53b28ucHJvZHVjdFRhYnMucXVlcnlTZWxlY3RvcihcIi5kZXNjcmlwdGlvbl90YWJcIikuY2xhc3NMaXN0LnJlbW92ZShcImFjdGl2ZVwiKTtcbiAgICAgICAgICAgIERPTS53b28ucHJvZHVjdFRhYnMucXVlcnlTZWxlY3RvcihcIiN0YWItZGVzY3JpcHRpb25cIikuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKERPTS53b28ucHJvZHVjdFRhYnMucXVlcnlTZWxlY3RvcihcIi5hZGRpdGlvbmFsX2luZm9ybWF0aW9uX3RhYlwiKSkge1xuICAgICAgICAgICAgRE9NLndvby5wcm9kdWN0VGFicy5xdWVyeVNlbGVjdG9yKFwiLmFkZGl0aW9uYWxfaW5mb3JtYXRpb25fdGFiXCIpLmNsYXNzTGlzdC5yZW1vdmUoXCJhY3RpdmVcIik7XG4gICAgICAgICAgICBET00ud29vLnByb2R1Y3RUYWJzLnF1ZXJ5U2VsZWN0b3IoXCIjdGFiLWFkZGl0aW9uYWxfaW5mb3JtYXRpb25cIikuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgICB9XG5cbiAgICAgICAgRE9NLndvby5wcm9kdWN0VGFicy5xdWVyeVNlbGVjdG9yKFwiLnJldmlld3NfdGFiXCIpLmNsYXNzTGlzdC5hZGQoXCJhY3RpdmVcIik7XG4gICAgICAgIERPTS53b28ucHJvZHVjdFRhYnMucXVlcnlTZWxlY3RvcihcIiN0YWItcmV2aWV3c1wiKS5zdHlsZS5kaXNwbGF5ID0gXCJibG9ja1wiO1xuXG4gICAgICAgIGNvbnN0IHJldmlld1RhYlBvc2l0aW9uVG9wID0gb2Zmc2V0KGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoZXZlbnQuY3VycmVudFRhcmdldC5oYXNoKSkudG9wO1xuXG4gICAgICAgIERPTS5odG1sLnNjcm9sbFRvKHtcbiAgICAgICAgICAgIHRvcDogcmV2aWV3VGFiUG9zaXRpb25Ub3AgLSAxMjAsXG4gICAgICAgICAgICBiZWhhdmlvcjogXCJzbW9vdGhcIixcbiAgICAgICAgfSk7XG4gICAgfTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgV29vU2Nyb2xsVG9SZXZpZXdUYWI7XG4iLCJpbXBvcnQgV29vUmVzZXRWYXJpYXRpb25zIGZyb20gXCIuL2N1c3RvbS1mZWF0dXJlcy9yZXNldC12YXJpYXRpb25zXCI7XG5pbXBvcnQgV29vR3JpZExpc3QgZnJvbSBcIi4vY3VzdG9tLWZlYXR1cmVzL3dvby1ncmlkLWxpc3RcIjtcbmltcG9ydCBXb29HdWVzdEFjY291bnRQYWdlIGZyb20gXCIuL2N1c3RvbS1mZWF0dXJlcy93b28tZ3Vlc3QtYWNjb3VudC1wYWdlXCI7XG5pbXBvcnQgV29vUXVhbnRpdHlCdXR0b25zIGZyb20gXCIuL2N1c3RvbS1mZWF0dXJlcy93b28tcXVhbnRpdHktYnV0dG9uc1wiO1xuaW1wb3J0IFdvb1Njcm9sbFRvUmV2aWV3VGFiIGZyb20gXCIuL2N1c3RvbS1mZWF0dXJlcy93b28tc2Nyb2xsLXRvLXJldmlldy10YWJcIjtcbmltcG9ydCBXb29SZW1vdmVDYXRlZ29yaWVzQ291bnRQYXJlbnRoZXNpcyBmcm9tIFwiLi9jdXN0b20tZmVhdHVyZXMvcmVtb3ZlLWNhdGVnb3JpZXMtY291bnQtcGFyZW50aGVzaXNcIjtcblxuY2xhc3MgV29vQ3VzdG9tRmVhdHVyZXMge1xuICAgIHN0YXJ0ID0gKCkgPT4ge1xuICAgICAgICB0aGlzLnJlc2V0VmFyaWF0aW9ucyA9IG5ldyBXb29SZXNldFZhcmlhdGlvbnMoKTtcbiAgICAgICAgdGhpcy5ncmlkTGlzdCA9IG5ldyBXb29HcmlkTGlzdCgpO1xuICAgICAgICB0aGlzLmd1ZXN0QWNjb3VudFBhZ2UgPSBuZXcgV29vR3Vlc3RBY2NvdW50UGFnZSgpO1xuICAgICAgICB0aGlzLnF1YW50aXR5QnV0dG9ucyA9IG5ldyBXb29RdWFudGl0eUJ1dHRvbnMoKTtcbiAgICAgICAgdGhpcy5yZXZpZXdTY3JvbGwgPSBuZXcgV29vU2Nyb2xsVG9SZXZpZXdUYWIoKTtcbiAgICAgICAgdGhpcy53aWRnZXRzID0gbmV3IFdvb1JlbW92ZUNhdGVnb3JpZXNDb3VudFBhcmVudGhlc2lzKCk7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEJlY2F1c2UgV29vY29tbWVyY2UgcGx1Z2luIHVzZXMgalF1ZXJ5IGN1c3RvbSBldmVudCxcbiAgICAgICAgICogV2UgYWxzbyBoYXZlIHRvIHVzZSBqUXVlcnkgdG8gY3VzdG9taXplIHRoaXMgZXZlbnQuXG4gICAgICAgICAqL1xuICAgICAgICBqUXVlcnkoXCJib2R5XCIpLm9uKFwidXBkYXRlZF9jYXJ0X3RvdGFsc1wiLCAoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnF1YW50aXR5QnV0dG9ucy5zdGFydCgpO1xuICAgICAgICB9KTtcblxuICAgICAgICBqUXVlcnkoIGRvY3VtZW50ICkub24oXCJhcHBlbmQuaW5maW5pdGVTY3JvbGxcIiwgKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5xdWFudGl0eUJ1dHRvbnMuc3RhcnQoKTtcbiAgICAgICAgfSk7XG4gICAgfTtcbn1cblxud2luZG93Lm9jZWFud3BXb29DdXN0b21GZWF0dXJlcyA9IG5ldyBXb29DdXN0b21GZWF0dXJlcygpO1xub2NlYW53cFdvb0N1c3RvbUZlYXR1cmVzLnN0YXJ0KCk7XG4iLCJmdW5jdGlvbiBfY2xhc3NBcHBseURlc2NyaXB0b3JHZXQocmVjZWl2ZXIsIGRlc2NyaXB0b3IpIHtcbiAgaWYgKGRlc2NyaXB0b3IuZ2V0KSB7XG4gICAgcmV0dXJuIGRlc2NyaXB0b3IuZ2V0LmNhbGwocmVjZWl2ZXIpO1xuICB9XG5cbiAgcmV0dXJuIGRlc2NyaXB0b3IudmFsdWU7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX2NsYXNzQXBwbHlEZXNjcmlwdG9yR2V0O1xubW9kdWxlLmV4cG9ydHNbXCJkZWZhdWx0XCJdID0gbW9kdWxlLmV4cG9ydHMsIG1vZHVsZS5leHBvcnRzLl9fZXNNb2R1bGUgPSB0cnVlOyIsImZ1bmN0aW9uIF9jbGFzc0FwcGx5RGVzY3JpcHRvclNldChyZWNlaXZlciwgZGVzY3JpcHRvciwgdmFsdWUpIHtcbiAgaWYgKGRlc2NyaXB0b3Iuc2V0KSB7XG4gICAgZGVzY3JpcHRvci5zZXQuY2FsbChyZWNlaXZlciwgdmFsdWUpO1xuICB9IGVsc2Uge1xuICAgIGlmICghZGVzY3JpcHRvci53cml0YWJsZSkge1xuICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcImF0dGVtcHRlZCB0byBzZXQgcmVhZCBvbmx5IHByaXZhdGUgZmllbGRcIik7XG4gICAgfVxuXG4gICAgZGVzY3JpcHRvci52YWx1ZSA9IHZhbHVlO1xuICB9XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX2NsYXNzQXBwbHlEZXNjcmlwdG9yU2V0O1xubW9kdWxlLmV4cG9ydHNbXCJkZWZhdWx0XCJdID0gbW9kdWxlLmV4cG9ydHMsIG1vZHVsZS5leHBvcnRzLl9fZXNNb2R1bGUgPSB0cnVlOyIsImZ1bmN0aW9uIF9jbGFzc0NhbGxDaGVjayhpbnN0YW5jZSwgQ29uc3RydWN0b3IpIHtcbiAgaWYgKCEoaW5zdGFuY2UgaW5zdGFuY2VvZiBDb25zdHJ1Y3RvcikpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2Fubm90IGNhbGwgYSBjbGFzcyBhcyBhIGZ1bmN0aW9uXCIpO1xuICB9XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX2NsYXNzQ2FsbENoZWNrO1xubW9kdWxlLmV4cG9ydHNbXCJkZWZhdWx0XCJdID0gbW9kdWxlLmV4cG9ydHMsIG1vZHVsZS5leHBvcnRzLl9fZXNNb2R1bGUgPSB0cnVlOyIsImZ1bmN0aW9uIF9jbGFzc0V4dHJhY3RGaWVsZERlc2NyaXB0b3IocmVjZWl2ZXIsIHByaXZhdGVNYXAsIGFjdGlvbikge1xuICBpZiAoIXByaXZhdGVNYXAuaGFzKHJlY2VpdmVyKSkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJhdHRlbXB0ZWQgdG8gXCIgKyBhY3Rpb24gKyBcIiBwcml2YXRlIGZpZWxkIG9uIG5vbi1pbnN0YW5jZVwiKTtcbiAgfVxuXG4gIHJldHVybiBwcml2YXRlTWFwLmdldChyZWNlaXZlcik7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX2NsYXNzRXh0cmFjdEZpZWxkRGVzY3JpcHRvcjtcbm1vZHVsZS5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IG1vZHVsZS5leHBvcnRzLCBtb2R1bGUuZXhwb3J0cy5fX2VzTW9kdWxlID0gdHJ1ZTsiLCJ2YXIgY2xhc3NBcHBseURlc2NyaXB0b3JHZXQgPSByZXF1aXJlKFwiLi9jbGFzc0FwcGx5RGVzY3JpcHRvckdldC5qc1wiKTtcblxudmFyIGNsYXNzRXh0cmFjdEZpZWxkRGVzY3JpcHRvciA9IHJlcXVpcmUoXCIuL2NsYXNzRXh0cmFjdEZpZWxkRGVzY3JpcHRvci5qc1wiKTtcblxuZnVuY3Rpb24gX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHJlY2VpdmVyLCBwcml2YXRlTWFwKSB7XG4gIHZhciBkZXNjcmlwdG9yID0gY2xhc3NFeHRyYWN0RmllbGREZXNjcmlwdG9yKHJlY2VpdmVyLCBwcml2YXRlTWFwLCBcImdldFwiKTtcbiAgcmV0dXJuIGNsYXNzQXBwbHlEZXNjcmlwdG9yR2V0KHJlY2VpdmVyLCBkZXNjcmlwdG9yKTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBfY2xhc3NQcml2YXRlRmllbGRHZXQ7XG5tb2R1bGUuZXhwb3J0c1tcImRlZmF1bHRcIl0gPSBtb2R1bGUuZXhwb3J0cywgbW9kdWxlLmV4cG9ydHMuX19lc01vZHVsZSA9IHRydWU7IiwidmFyIGNsYXNzQXBwbHlEZXNjcmlwdG9yU2V0ID0gcmVxdWlyZShcIi4vY2xhc3NBcHBseURlc2NyaXB0b3JTZXQuanNcIik7XG5cbnZhciBjbGFzc0V4dHJhY3RGaWVsZERlc2NyaXB0b3IgPSByZXF1aXJlKFwiLi9jbGFzc0V4dHJhY3RGaWVsZERlc2NyaXB0b3IuanNcIik7XG5cbmZ1bmN0aW9uIF9jbGFzc1ByaXZhdGVGaWVsZFNldChyZWNlaXZlciwgcHJpdmF0ZU1hcCwgdmFsdWUpIHtcbiAgdmFyIGRlc2NyaXB0b3IgPSBjbGFzc0V4dHJhY3RGaWVsZERlc2NyaXB0b3IocmVjZWl2ZXIsIHByaXZhdGVNYXAsIFwic2V0XCIpO1xuICBjbGFzc0FwcGx5RGVzY3JpcHRvclNldChyZWNlaXZlciwgZGVzY3JpcHRvciwgdmFsdWUpO1xuICByZXR1cm4gdmFsdWU7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX2NsYXNzUHJpdmF0ZUZpZWxkU2V0O1xubW9kdWxlLmV4cG9ydHNbXCJkZWZhdWx0XCJdID0gbW9kdWxlLmV4cG9ydHMsIG1vZHVsZS5leHBvcnRzLl9fZXNNb2R1bGUgPSB0cnVlOyIsImZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0eShvYmosIGtleSwgdmFsdWUpIHtcbiAgaWYgKGtleSBpbiBvYmopIHtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkob2JqLCBrZXksIHtcbiAgICAgIHZhbHVlOiB2YWx1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICB3cml0YWJsZTogdHJ1ZVxuICAgIH0pO1xuICB9IGVsc2Uge1xuICAgIG9ialtrZXldID0gdmFsdWU7XG4gIH1cblxuICByZXR1cm4gb2JqO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IF9kZWZpbmVQcm9wZXJ0eTtcbm1vZHVsZS5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IG1vZHVsZS5leHBvcnRzLCBtb2R1bGUuZXhwb3J0cy5fX2VzTW9kdWxlID0gdHJ1ZTsiLCJmdW5jdGlvbiBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KG9iaikge1xuICByZXR1cm4gb2JqICYmIG9iai5fX2VzTW9kdWxlID8gb2JqIDoge1xuICAgIFwiZGVmYXVsdFwiOiBvYmpcbiAgfTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0O1xubW9kdWxlLmV4cG9ydHNbXCJkZWZhdWx0XCJdID0gbW9kdWxlLmV4cG9ydHMsIG1vZHVsZS5leHBvcnRzLl9fZXNNb2R1bGUgPSB0cnVlOyIsImZ1bmN0aW9uIF90eXBlb2Yob2JqKSB7XG4gIFwiQGJhYmVsL2hlbHBlcnMgLSB0eXBlb2ZcIjtcblxuICBpZiAodHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIHR5cGVvZiBTeW1ib2wuaXRlcmF0b3IgPT09IFwic3ltYm9sXCIpIHtcbiAgICBtb2R1bGUuZXhwb3J0cyA9IF90eXBlb2YgPSBmdW5jdGlvbiBfdHlwZW9mKG9iaikge1xuICAgICAgcmV0dXJuIHR5cGVvZiBvYmo7XG4gICAgfTtcblxuICAgIG1vZHVsZS5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IG1vZHVsZS5leHBvcnRzLCBtb2R1bGUuZXhwb3J0cy5fX2VzTW9kdWxlID0gdHJ1ZTtcbiAgfSBlbHNlIHtcbiAgICBtb2R1bGUuZXhwb3J0cyA9IF90eXBlb2YgPSBmdW5jdGlvbiBfdHlwZW9mKG9iaikge1xuICAgICAgcmV0dXJuIG9iaiAmJiB0eXBlb2YgU3ltYm9sID09PSBcImZ1bmN0aW9uXCIgJiYgb2JqLmNvbnN0cnVjdG9yID09PSBTeW1ib2wgJiYgb2JqICE9PSBTeW1ib2wucHJvdG90eXBlID8gXCJzeW1ib2xcIiA6IHR5cGVvZiBvYmo7XG4gICAgfTtcblxuICAgIG1vZHVsZS5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IG1vZHVsZS5leHBvcnRzLCBtb2R1bGUuZXhwb3J0cy5fX2VzTW9kdWxlID0gdHJ1ZTtcbiAgfVxuXG4gIHJldHVybiBfdHlwZW9mKG9iaik7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX3R5cGVvZjtcbm1vZHVsZS5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IG1vZHVsZS5leHBvcnRzLCBtb2R1bGUuZXhwb3J0cy5fX2VzTW9kdWxlID0gdHJ1ZTsiLCJ2YXIgRE9DVU1FTlRfTk9ERV9UWVBFID0gOTtcblxuLyoqXG4gKiBBIHBvbHlmaWxsIGZvciBFbGVtZW50Lm1hdGNoZXMoKVxuICovXG5pZiAodHlwZW9mIEVsZW1lbnQgIT09ICd1bmRlZmluZWQnICYmICFFbGVtZW50LnByb3RvdHlwZS5tYXRjaGVzKSB7XG4gICAgdmFyIHByb3RvID0gRWxlbWVudC5wcm90b3R5cGU7XG5cbiAgICBwcm90by5tYXRjaGVzID0gcHJvdG8ubWF0Y2hlc1NlbGVjdG9yIHx8XG4gICAgICAgICAgICAgICAgICAgIHByb3RvLm1vek1hdGNoZXNTZWxlY3RvciB8fFxuICAgICAgICAgICAgICAgICAgICBwcm90by5tc01hdGNoZXNTZWxlY3RvciB8fFxuICAgICAgICAgICAgICAgICAgICBwcm90by5vTWF0Y2hlc1NlbGVjdG9yIHx8XG4gICAgICAgICAgICAgICAgICAgIHByb3RvLndlYmtpdE1hdGNoZXNTZWxlY3Rvcjtcbn1cblxuLyoqXG4gKiBGaW5kcyB0aGUgY2xvc2VzdCBwYXJlbnQgdGhhdCBtYXRjaGVzIGEgc2VsZWN0b3IuXG4gKlxuICogQHBhcmFtIHtFbGVtZW50fSBlbGVtZW50XG4gKiBAcGFyYW0ge1N0cmluZ30gc2VsZWN0b3JcbiAqIEByZXR1cm4ge0Z1bmN0aW9ufVxuICovXG5mdW5jdGlvbiBjbG9zZXN0IChlbGVtZW50LCBzZWxlY3Rvcikge1xuICAgIHdoaWxlIChlbGVtZW50ICYmIGVsZW1lbnQubm9kZVR5cGUgIT09IERPQ1VNRU5UX05PREVfVFlQRSkge1xuICAgICAgICBpZiAodHlwZW9mIGVsZW1lbnQubWF0Y2hlcyA9PT0gJ2Z1bmN0aW9uJyAmJlxuICAgICAgICAgICAgZWxlbWVudC5tYXRjaGVzKHNlbGVjdG9yKSkge1xuICAgICAgICAgIHJldHVybiBlbGVtZW50O1xuICAgICAgICB9XG4gICAgICAgIGVsZW1lbnQgPSBlbGVtZW50LnBhcmVudE5vZGU7XG4gICAgfVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IGNsb3Nlc3Q7XG4iLCJ2YXIgY2xvc2VzdCA9IHJlcXVpcmUoJy4vY2xvc2VzdCcpO1xuXG4vKipcbiAqIERlbGVnYXRlcyBldmVudCB0byBhIHNlbGVjdG9yLlxuICpcbiAqIEBwYXJhbSB7RWxlbWVudH0gZWxlbWVudFxuICogQHBhcmFtIHtTdHJpbmd9IHNlbGVjdG9yXG4gKiBAcGFyYW0ge1N0cmluZ30gdHlwZVxuICogQHBhcmFtIHtGdW5jdGlvbn0gY2FsbGJhY2tcbiAqIEBwYXJhbSB7Qm9vbGVhbn0gdXNlQ2FwdHVyZVxuICogQHJldHVybiB7T2JqZWN0fVxuICovXG5mdW5jdGlvbiBfZGVsZWdhdGUoZWxlbWVudCwgc2VsZWN0b3IsIHR5cGUsIGNhbGxiYWNrLCB1c2VDYXB0dXJlKSB7XG4gICAgdmFyIGxpc3RlbmVyRm4gPSBsaXN0ZW5lci5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuXG4gICAgZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKHR5cGUsIGxpc3RlbmVyRm4sIHVzZUNhcHR1cmUpO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgICAgZGVzdHJveTogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICBlbGVtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIodHlwZSwgbGlzdGVuZXJGbiwgdXNlQ2FwdHVyZSk7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi8qKlxuICogRGVsZWdhdGVzIGV2ZW50IHRvIGEgc2VsZWN0b3IuXG4gKlxuICogQHBhcmFtIHtFbGVtZW50fFN0cmluZ3xBcnJheX0gW2VsZW1lbnRzXVxuICogQHBhcmFtIHtTdHJpbmd9IHNlbGVjdG9yXG4gKiBAcGFyYW0ge1N0cmluZ30gdHlwZVxuICogQHBhcmFtIHtGdW5jdGlvbn0gY2FsbGJhY2tcbiAqIEBwYXJhbSB7Qm9vbGVhbn0gdXNlQ2FwdHVyZVxuICogQHJldHVybiB7T2JqZWN0fVxuICovXG5mdW5jdGlvbiBkZWxlZ2F0ZShlbGVtZW50cywgc2VsZWN0b3IsIHR5cGUsIGNhbGxiYWNrLCB1c2VDYXB0dXJlKSB7XG4gICAgLy8gSGFuZGxlIHRoZSByZWd1bGFyIEVsZW1lbnQgdXNhZ2VcbiAgICBpZiAodHlwZW9mIGVsZW1lbnRzLmFkZEV2ZW50TGlzdGVuZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgcmV0dXJuIF9kZWxlZ2F0ZS5hcHBseShudWxsLCBhcmd1bWVudHMpO1xuICAgIH1cblxuICAgIC8vIEhhbmRsZSBFbGVtZW50LWxlc3MgdXNhZ2UsIGl0IGRlZmF1bHRzIHRvIGdsb2JhbCBkZWxlZ2F0aW9uXG4gICAgaWYgKHR5cGVvZiB0eXBlID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIC8vIFVzZSBgZG9jdW1lbnRgIGFzIHRoZSBmaXJzdCBwYXJhbWV0ZXIsIHRoZW4gYXBwbHkgYXJndW1lbnRzXG4gICAgICAgIC8vIFRoaXMgaXMgYSBzaG9ydCB3YXkgdG8gLnVuc2hpZnQgYGFyZ3VtZW50c2Agd2l0aG91dCBydW5uaW5nIGludG8gZGVvcHRpbWl6YXRpb25zXG4gICAgICAgIHJldHVybiBfZGVsZWdhdGUuYmluZChudWxsLCBkb2N1bWVudCkuYXBwbHkobnVsbCwgYXJndW1lbnRzKTtcbiAgICB9XG5cbiAgICAvLyBIYW5kbGUgU2VsZWN0b3ItYmFzZWQgdXNhZ2VcbiAgICBpZiAodHlwZW9mIGVsZW1lbnRzID09PSAnc3RyaW5nJykge1xuICAgICAgICBlbGVtZW50cyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoZWxlbWVudHMpO1xuICAgIH1cblxuICAgIC8vIEhhbmRsZSBBcnJheS1saWtlIGJhc2VkIHVzYWdlXG4gICAgcmV0dXJuIEFycmF5LnByb3RvdHlwZS5tYXAuY2FsbChlbGVtZW50cywgZnVuY3Rpb24gKGVsZW1lbnQpIHtcbiAgICAgICAgcmV0dXJuIF9kZWxlZ2F0ZShlbGVtZW50LCBzZWxlY3RvciwgdHlwZSwgY2FsbGJhY2ssIHVzZUNhcHR1cmUpO1xuICAgIH0pO1xufVxuXG4vKipcbiAqIEZpbmRzIGNsb3Nlc3QgbWF0Y2ggYW5kIGludm9rZXMgY2FsbGJhY2suXG4gKlxuICogQHBhcmFtIHtFbGVtZW50fSBlbGVtZW50XG4gKiBAcGFyYW0ge1N0cmluZ30gc2VsZWN0b3JcbiAqIEBwYXJhbSB7U3RyaW5nfSB0eXBlXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYWxsYmFja1xuICogQHJldHVybiB7RnVuY3Rpb259XG4gKi9cbmZ1bmN0aW9uIGxpc3RlbmVyKGVsZW1lbnQsIHNlbGVjdG9yLCB0eXBlLCBjYWxsYmFjaykge1xuICAgIHJldHVybiBmdW5jdGlvbihlKSB7XG4gICAgICAgIGUuZGVsZWdhdGVUYXJnZXQgPSBjbG9zZXN0KGUudGFyZ2V0LCBzZWxlY3Rvcik7XG5cbiAgICAgICAgaWYgKGUuZGVsZWdhdGVUYXJnZXQpIHtcbiAgICAgICAgICAgIGNhbGxiYWNrLmNhbGwoZWxlbWVudCwgZSk7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbm1vZHVsZS5leHBvcnRzID0gZGVsZWdhdGU7XG4iLCIvKiFcbiAqIEphdmFTY3JpcHQgQ29va2llIHYyLjIuMVxuICogaHR0cHM6Ly9naXRodWIuY29tL2pzLWNvb2tpZS9qcy1jb29raWVcbiAqXG4gKiBDb3B5cmlnaHQgMjAwNiwgMjAxNSBLbGF1cyBIYXJ0bCAmIEZhZ25lciBCcmFja1xuICogUmVsZWFzZWQgdW5kZXIgdGhlIE1JVCBsaWNlbnNlXG4gKi9cbjsoZnVuY3Rpb24gKGZhY3RvcnkpIHtcblx0dmFyIHJlZ2lzdGVyZWRJbk1vZHVsZUxvYWRlcjtcblx0aWYgKHR5cGVvZiBkZWZpbmUgPT09ICdmdW5jdGlvbicgJiYgZGVmaW5lLmFtZCkge1xuXHRcdGRlZmluZShmYWN0b3J5KTtcblx0XHRyZWdpc3RlcmVkSW5Nb2R1bGVMb2FkZXIgPSB0cnVlO1xuXHR9XG5cdGlmICh0eXBlb2YgZXhwb3J0cyA9PT0gJ29iamVjdCcpIHtcblx0XHRtb2R1bGUuZXhwb3J0cyA9IGZhY3RvcnkoKTtcblx0XHRyZWdpc3RlcmVkSW5Nb2R1bGVMb2FkZXIgPSB0cnVlO1xuXHR9XG5cdGlmICghcmVnaXN0ZXJlZEluTW9kdWxlTG9hZGVyKSB7XG5cdFx0dmFyIE9sZENvb2tpZXMgPSB3aW5kb3cuQ29va2llcztcblx0XHR2YXIgYXBpID0gd2luZG93LkNvb2tpZXMgPSBmYWN0b3J5KCk7XG5cdFx0YXBpLm5vQ29uZmxpY3QgPSBmdW5jdGlvbiAoKSB7XG5cdFx0XHR3aW5kb3cuQ29va2llcyA9IE9sZENvb2tpZXM7XG5cdFx0XHRyZXR1cm4gYXBpO1xuXHRcdH07XG5cdH1cbn0oZnVuY3Rpb24gKCkge1xuXHRmdW5jdGlvbiBleHRlbmQgKCkge1xuXHRcdHZhciBpID0gMDtcblx0XHR2YXIgcmVzdWx0ID0ge307XG5cdFx0Zm9yICg7IGkgPCBhcmd1bWVudHMubGVuZ3RoOyBpKyspIHtcblx0XHRcdHZhciBhdHRyaWJ1dGVzID0gYXJndW1lbnRzWyBpIF07XG5cdFx0XHRmb3IgKHZhciBrZXkgaW4gYXR0cmlidXRlcykge1xuXHRcdFx0XHRyZXN1bHRba2V5XSA9IGF0dHJpYnV0ZXNba2V5XTtcblx0XHRcdH1cblx0XHR9XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fVxuXG5cdGZ1bmN0aW9uIGRlY29kZSAocykge1xuXHRcdHJldHVybiBzLnJlcGxhY2UoLyglWzAtOUEtWl17Mn0pKy9nLCBkZWNvZGVVUklDb21wb25lbnQpO1xuXHR9XG5cblx0ZnVuY3Rpb24gaW5pdCAoY29udmVydGVyKSB7XG5cdFx0ZnVuY3Rpb24gYXBpKCkge31cblxuXHRcdGZ1bmN0aW9uIHNldCAoa2V5LCB2YWx1ZSwgYXR0cmlidXRlcykge1xuXHRcdFx0aWYgKHR5cGVvZiBkb2N1bWVudCA9PT0gJ3VuZGVmaW5lZCcpIHtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXG5cdFx0XHRhdHRyaWJ1dGVzID0gZXh0ZW5kKHtcblx0XHRcdFx0cGF0aDogJy8nXG5cdFx0XHR9LCBhcGkuZGVmYXVsdHMsIGF0dHJpYnV0ZXMpO1xuXG5cdFx0XHRpZiAodHlwZW9mIGF0dHJpYnV0ZXMuZXhwaXJlcyA9PT0gJ251bWJlcicpIHtcblx0XHRcdFx0YXR0cmlidXRlcy5leHBpcmVzID0gbmV3IERhdGUobmV3IERhdGUoKSAqIDEgKyBhdHRyaWJ1dGVzLmV4cGlyZXMgKiA4NjRlKzUpO1xuXHRcdFx0fVxuXG5cdFx0XHQvLyBXZSdyZSB1c2luZyBcImV4cGlyZXNcIiBiZWNhdXNlIFwibWF4LWFnZVwiIGlzIG5vdCBzdXBwb3J0ZWQgYnkgSUVcblx0XHRcdGF0dHJpYnV0ZXMuZXhwaXJlcyA9IGF0dHJpYnV0ZXMuZXhwaXJlcyA/IGF0dHJpYnV0ZXMuZXhwaXJlcy50b1VUQ1N0cmluZygpIDogJyc7XG5cblx0XHRcdHRyeSB7XG5cdFx0XHRcdHZhciByZXN1bHQgPSBKU09OLnN0cmluZ2lmeSh2YWx1ZSk7XG5cdFx0XHRcdGlmICgvXltcXHtcXFtdLy50ZXN0KHJlc3VsdCkpIHtcblx0XHRcdFx0XHR2YWx1ZSA9IHJlc3VsdDtcblx0XHRcdFx0fVxuXHRcdFx0fSBjYXRjaCAoZSkge31cblxuXHRcdFx0dmFsdWUgPSBjb252ZXJ0ZXIud3JpdGUgP1xuXHRcdFx0XHRjb252ZXJ0ZXIud3JpdGUodmFsdWUsIGtleSkgOlxuXHRcdFx0XHRlbmNvZGVVUklDb21wb25lbnQoU3RyaW5nKHZhbHVlKSlcblx0XHRcdFx0XHQucmVwbGFjZSgvJSgyM3wyNHwyNnwyQnwzQXwzQ3wzRXwzRHwyRnwzRnw0MHw1Qnw1RHw1RXw2MHw3Qnw3RHw3QykvZywgZGVjb2RlVVJJQ29tcG9uZW50KTtcblxuXHRcdFx0a2V5ID0gZW5jb2RlVVJJQ29tcG9uZW50KFN0cmluZyhrZXkpKVxuXHRcdFx0XHQucmVwbGFjZSgvJSgyM3wyNHwyNnwyQnw1RXw2MHw3QykvZywgZGVjb2RlVVJJQ29tcG9uZW50KVxuXHRcdFx0XHQucmVwbGFjZSgvW1xcKFxcKV0vZywgZXNjYXBlKTtcblxuXHRcdFx0dmFyIHN0cmluZ2lmaWVkQXR0cmlidXRlcyA9ICcnO1xuXHRcdFx0Zm9yICh2YXIgYXR0cmlidXRlTmFtZSBpbiBhdHRyaWJ1dGVzKSB7XG5cdFx0XHRcdGlmICghYXR0cmlidXRlc1thdHRyaWJ1dGVOYW1lXSkge1xuXHRcdFx0XHRcdGNvbnRpbnVlO1xuXHRcdFx0XHR9XG5cdFx0XHRcdHN0cmluZ2lmaWVkQXR0cmlidXRlcyArPSAnOyAnICsgYXR0cmlidXRlTmFtZTtcblx0XHRcdFx0aWYgKGF0dHJpYnV0ZXNbYXR0cmlidXRlTmFtZV0gPT09IHRydWUpIHtcblx0XHRcdFx0XHRjb250aW51ZTtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdC8vIENvbnNpZGVycyBSRkMgNjI2NSBzZWN0aW9uIDUuMjpcblx0XHRcdFx0Ly8gLi4uXG5cdFx0XHRcdC8vIDMuICBJZiB0aGUgcmVtYWluaW5nIHVucGFyc2VkLWF0dHJpYnV0ZXMgY29udGFpbnMgYSAleDNCIChcIjtcIilcblx0XHRcdFx0Ly8gICAgIGNoYXJhY3Rlcjpcblx0XHRcdFx0Ly8gQ29uc3VtZSB0aGUgY2hhcmFjdGVycyBvZiB0aGUgdW5wYXJzZWQtYXR0cmlidXRlcyB1cCB0byxcblx0XHRcdFx0Ly8gbm90IGluY2x1ZGluZywgdGhlIGZpcnN0ICV4M0IgKFwiO1wiKSBjaGFyYWN0ZXIuXG5cdFx0XHRcdC8vIC4uLlxuXHRcdFx0XHRzdHJpbmdpZmllZEF0dHJpYnV0ZXMgKz0gJz0nICsgYXR0cmlidXRlc1thdHRyaWJ1dGVOYW1lXS5zcGxpdCgnOycpWzBdO1xuXHRcdFx0fVxuXG5cdFx0XHRyZXR1cm4gKGRvY3VtZW50LmNvb2tpZSA9IGtleSArICc9JyArIHZhbHVlICsgc3RyaW5naWZpZWRBdHRyaWJ1dGVzKTtcblx0XHR9XG5cblx0XHRmdW5jdGlvbiBnZXQgKGtleSwganNvbikge1xuXHRcdFx0aWYgKHR5cGVvZiBkb2N1bWVudCA9PT0gJ3VuZGVmaW5lZCcpIHtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXG5cdFx0XHR2YXIgamFyID0ge307XG5cdFx0XHQvLyBUbyBwcmV2ZW50IHRoZSBmb3IgbG9vcCBpbiB0aGUgZmlyc3QgcGxhY2UgYXNzaWduIGFuIGVtcHR5IGFycmF5XG5cdFx0XHQvLyBpbiBjYXNlIHRoZXJlIGFyZSBubyBjb29raWVzIGF0IGFsbC5cblx0XHRcdHZhciBjb29raWVzID0gZG9jdW1lbnQuY29va2llID8gZG9jdW1lbnQuY29va2llLnNwbGl0KCc7ICcpIDogW107XG5cdFx0XHR2YXIgaSA9IDA7XG5cblx0XHRcdGZvciAoOyBpIDwgY29va2llcy5sZW5ndGg7IGkrKykge1xuXHRcdFx0XHR2YXIgcGFydHMgPSBjb29raWVzW2ldLnNwbGl0KCc9Jyk7XG5cdFx0XHRcdHZhciBjb29raWUgPSBwYXJ0cy5zbGljZSgxKS5qb2luKCc9Jyk7XG5cblx0XHRcdFx0aWYgKCFqc29uICYmIGNvb2tpZS5jaGFyQXQoMCkgPT09ICdcIicpIHtcblx0XHRcdFx0XHRjb29raWUgPSBjb29raWUuc2xpY2UoMSwgLTEpO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHR2YXIgbmFtZSA9IGRlY29kZShwYXJ0c1swXSk7XG5cdFx0XHRcdFx0Y29va2llID0gKGNvbnZlcnRlci5yZWFkIHx8IGNvbnZlcnRlcikoY29va2llLCBuYW1lKSB8fFxuXHRcdFx0XHRcdFx0ZGVjb2RlKGNvb2tpZSk7XG5cblx0XHRcdFx0XHRpZiAoanNvbikge1xuXHRcdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdFx0Y29va2llID0gSlNPTi5wYXJzZShjb29raWUpO1xuXHRcdFx0XHRcdFx0fSBjYXRjaCAoZSkge31cblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHRqYXJbbmFtZV0gPSBjb29raWU7XG5cblx0XHRcdFx0XHRpZiAoa2V5ID09PSBuYW1lKSB7XG5cdFx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0gY2F0Y2ggKGUpIHt9XG5cdFx0XHR9XG5cblx0XHRcdHJldHVybiBrZXkgPyBqYXJba2V5XSA6IGphcjtcblx0XHR9XG5cblx0XHRhcGkuc2V0ID0gc2V0O1xuXHRcdGFwaS5nZXQgPSBmdW5jdGlvbiAoa2V5KSB7XG5cdFx0XHRyZXR1cm4gZ2V0KGtleSwgZmFsc2UgLyogcmVhZCBhcyByYXcgKi8pO1xuXHRcdH07XG5cdFx0YXBpLmdldEpTT04gPSBmdW5jdGlvbiAoa2V5KSB7XG5cdFx0XHRyZXR1cm4gZ2V0KGtleSwgdHJ1ZSAvKiByZWFkIGFzIGpzb24gKi8pO1xuXHRcdH07XG5cdFx0YXBpLnJlbW92ZSA9IGZ1bmN0aW9uIChrZXksIGF0dHJpYnV0ZXMpIHtcblx0XHRcdHNldChrZXksICcnLCBleHRlbmQoYXR0cmlidXRlcywge1xuXHRcdFx0XHRleHBpcmVzOiAtMVxuXHRcdFx0fSkpO1xuXHRcdH07XG5cblx0XHRhcGkuZGVmYXVsdHMgPSB7fTtcblxuXHRcdGFwaS53aXRoQ29udmVydGVyID0gaW5pdDtcblxuXHRcdHJldHVybiBhcGk7XG5cdH1cblxuXHRyZXR1cm4gaW5pdChmdW5jdGlvbiAoKSB7fSk7XG59KSk7XG4iXX0=
